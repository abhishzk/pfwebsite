
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// .netlify/server/chunks/index-server.js
import * as devalue from "devalue";
import { clsx } from "clsx";
function run(fn) {
  return fn();
}
function run_all(arr) {
  for (var i = 0; i < arr.length; i++) arr[i]();
}
function deferred() {
  var resolve2;
  var reject;
  return {
    promise: new Promise((res, rej) => {
      resolve2 = res;
      reject = rej;
    }),
    resolve: resolve2,
    reject
  };
}
function fallback(value, fallback2, lazy = false) {
  return value === void 0 ? lazy ? fallback2() : fallback2 : value;
}
function equals(value) {
  return value === this.v;
}
function safe_not_equal(a, b) {
  return a != a ? b == b : a !== b || a !== null && typeof a === "object" || typeof a === "function";
}
function safe_equals(value) {
  return !safe_not_equal(value, this.v);
}
function derived_inert() {
  console.warn(`https://svelte.dev/e/derived_inert`);
}
function hydration_mismatch(location) {
  console.warn(`https://svelte.dev/e/hydration_mismatch`);
}
function svelte_boundary_reset_noop() {
  console.warn(`https://svelte.dev/e/svelte_boundary_reset_noop`);
}
function set_hydrating(value) {
  hydrating = value;
}
function set_hydrate_node(node) {
  if (node === null) {
    hydration_mismatch();
    throw HYDRATION_ERROR;
  }
  return hydrate_node = node;
}
function hydrate_next() {
  return set_hydrate_node(/* @__PURE__ */ get_next_sibling(hydrate_node));
}
function next(count = 1) {
  if (hydrating) {
    var i = count;
    var node = hydrate_node;
    while (i--) node = /* @__PURE__ */ get_next_sibling(node);
    hydrate_node = node;
  }
}
function skip_nodes(remove = true) {
  var depth = 0;
  var node = hydrate_node;
  while (true) {
    if (node.nodeType === 8) {
      var data = node.data;
      if (data === "]") {
        if (depth === 0) return node;
        depth -= 1;
      } else if (data === "[" || data === "[!" || data[0] === "[" && !isNaN(Number(data.slice(1)))) depth += 1;
    }
    var next2 = /* @__PURE__ */ get_next_sibling(node);
    if (remove) node.remove();
    node = next2;
  }
}
function experimental_async_required(name) {
  throw new Error(`https://svelte.dev/e/experimental_async_required`);
}
function lifecycle_outside_component(name) {
  throw new Error(`https://svelte.dev/e/lifecycle_outside_component`);
}
function missing_context() {
  throw new Error(`https://svelte.dev/e/missing_context`);
}
function effect_update_depth_exceeded() {
  throw new Error(`https://svelte.dev/e/effect_update_depth_exceeded`);
}
function hydration_failed() {
  throw new Error(`https://svelte.dev/e/hydration_failed`);
}
function state_descriptors_fixed() {
  throw new Error(`https://svelte.dev/e/state_descriptors_fixed`);
}
function state_prototype_fixed() {
  throw new Error(`https://svelte.dev/e/state_prototype_fixed`);
}
function state_unsafe_mutation() {
  throw new Error(`https://svelte.dev/e/state_unsafe_mutation`);
}
function svelte_boundary_reset_onerror() {
  throw new Error(`https://svelte.dev/e/svelte_boundary_reset_onerror`);
}
function create_context(get_context, set_context, has_context) {
  const key2 = {};
  return [
    () => {
      if (!has_context(key2)) missing_context();
      return get_context(key2);
    },
    (context2) => set_context(key2, context2),
    () => has_context(key2)
  ];
}
function get_parent_context(context2) {
  let parent = context2.p;
  while (parent !== null && parent.c === null) parent = parent.p;
  return parent?.c ?? null;
}
function get_or_init_context_map(context2, name) {
  if (context2 === null) lifecycle_outside_component(name);
  return context2.c ??= new Map(get_parent_context(context2) || void 0);
}
function set_component_context(context2) {
  component_context = context2;
}
function push$1(props, runes = false, fn) {
  component_context = {
    p: component_context,
    i: false,
    c: null,
    e: null,
    s: props,
    x: null,
    r: active_effect,
    l: legacy_mode_flag && !runes ? {
      s: null,
      u: null,
      $: []
    } : null
  };
}
function pop$1(component7) {
  var context2 = component_context;
  var effects = context2.e;
  if (effects !== null) {
    context2.e = null;
    for (var fn of effects) create_user_effect(fn);
  }
  if (component7 !== void 0) context2.x = component7;
  context2.i = true;
  component_context = context2.p;
  return mark_as_component(component7);
}
function mark_as_component(component7 = {}) {
  define_property(component7, COMPONENT_SYMBOL, { value: true });
  return component7;
}
function is_runes() {
  return !legacy_mode_flag || component_context !== null && component_context.l === null;
}
function run_micro_tasks() {
  var tasks = micro_tasks;
  micro_tasks = [];
  run_all(tasks);
}
function queue_micro_task(fn) {
  if (micro_tasks.length === 0 && !is_flushing_sync) {
    var tasks = micro_tasks;
    queueMicrotask(() => {
      if (tasks === micro_tasks) run_micro_tasks();
    });
  }
  micro_tasks.push(fn);
}
function flush_tasks() {
  while (micro_tasks.length > 0) run_micro_tasks();
}
function set_signal_status(signal, status) {
  signal.f = signal.f & STATUS_MASK | status;
}
function update_derived_status(derived2) {
  if ((derived2.f & 512) !== 0 || derived2.deps === null) set_signal_status(derived2, CLEAN);
  else set_signal_status(derived2, MAYBE_DIRTY);
}
function clear_marked(deps) {
  if (deps === null) return;
  for (const dep of deps) {
    if ((dep.f & 2) === 0 || (dep.f & 65536) === 0) continue;
    dep.f ^= WAS_MARKED;
    clear_marked(
      /** @type {Derived} */
      dep.deps
    );
  }
}
function defer_effect(effect, dirty_effects, maybe_dirty_effects) {
  if ((effect.f & 2048) !== 0) dirty_effects.add(effect);
  else if ((effect.f & 4096) !== 0) maybe_dirty_effects.add(effect);
  clear_marked(effect.deps);
  set_signal_status(effect, CLEAN);
}
function without_reactive_context(fn) {
  var previous_reaction = active_reaction;
  var previous_effect = active_effect;
  set_active_reaction(null);
  set_active_effect(null);
  try {
    return fn();
  } finally {
    set_active_reaction(previous_reaction);
    set_active_effect(previous_effect);
  }
}
function destroy_derived_effects(derived2) {
  var effects = derived2.effects;
  if (effects !== null) {
    derived2.effects = null;
    for (var i = 0; i < effects.length; i += 1) destroy_effect(effects[i]);
  }
}
function execute_derived(derived2) {
  var value;
  var prev_active_effect = active_effect;
  var parent = derived2.parent;
  if (!is_destroying_effect && parent !== null && derived2.v !== UNINITIALIZED && (parent.f & 24576) !== 0) {
    derived_inert();
    return derived2.v;
  }
  set_active_effect(parent);
  try {
    derived2.f &= ~WAS_MARKED;
    destroy_derived_effects(derived2);
    value = update_reaction(derived2);
  } finally {
    set_active_effect(prev_active_effect);
  }
  return value;
}
function update_derived(derived2) {
  var value = execute_derived(derived2);
  if (!derived2.equals(value)) {
    derived2.wv = increment_write_version();
    if (!current_batch?.is_fork || derived2.deps === null) {
      if (current_batch !== null) {
        current_batch.capture(derived2, value, true);
        previous_batch?.capture(derived2, value, true);
      } else derived2.v = value;
      if (derived2.deps === null) {
        set_signal_status(derived2, CLEAN);
        return;
      }
    }
  }
  if (is_destroying_effect) return;
  if (batch_values !== null) {
    if (effect_tracking() || current_batch?.is_fork) batch_values.set(derived2, value);
  } else update_derived_status(derived2);
}
function freeze_derived_effects(derived2) {
  if (derived2.effects === null) return;
  for (const e of derived2.effects) if (e.teardown || e.ac) {
    e.teardown?.();
    if (e.ac !== null) without_reactive_context(() => {
      e.ac.abort(STALE_REACTION);
      e.ac = null;
    });
    if (e.fn !== null) e.teardown = noop;
    remove_reactions(e, 0);
    destroy_effect_children(e);
  }
}
function unfreeze_derived_effects(derived2) {
  if (derived2.effects === null) return;
  for (const e of derived2.effects) if (e.teardown && e.fn !== null) update_effect(e);
}
function flushSync(fn) {
  var was_flushing_sync = is_flushing_sync;
  is_flushing_sync = true;
  try {
    var result;
    if (fn) {
      if (current_batch !== null && !current_batch.is_fork) current_batch.flush();
      result = fn();
    }
    while (true) {
      flush_tasks();
      if (current_batch === null) return result;
      current_batch.flush();
    }
  } finally {
    is_flushing_sync = was_flushing_sync;
  }
}
function infinite_loop_guard() {
  try {
    effect_update_depth_exceeded();
  } catch (error2) {
    invoke_error_boundary(error2, last_scheduled_effect);
  }
}
function flush_queued_effects(effects) {
  var length = effects.length;
  if (length === 0) return;
  var i = 0;
  while (i < length) {
    var effect = effects[i++];
    if ((effect.f & 24576) === 0 && is_dirty(effect)) {
      eager_block_effects = /* @__PURE__ */ new Set();
      update_effect(effect);
      if (effect.deps === null && effect.first === null && effect.nodes === null && effect.teardown === null && effect.ac === null) unlink_effect(effect);
      if (eager_block_effects?.size > 0) {
        old_values.clear();
        for (const e of eager_block_effects) {
          if ((e.f & 24576) !== 0) continue;
          const ordered_effects = [e];
          let ancestor = e.parent;
          while (ancestor !== null) {
            if (eager_block_effects.has(ancestor)) {
              eager_block_effects.delete(ancestor);
              ordered_effects.push(ancestor);
            }
            ancestor = ancestor.parent;
          }
          for (let j = ordered_effects.length - 1; j >= 0; j--) {
            const e2 = ordered_effects[j];
            if ((e2.f & 24576) !== 0) continue;
            update_effect(e2);
          }
        }
        eager_block_effects.clear();
      }
    }
  }
  eager_block_effects = null;
}
function mark_effects(value, sources, marked, checked) {
  if (marked.has(value)) return;
  marked.add(value);
  if (value.reactions !== null) for (const reaction of value.reactions) {
    const flags2 = reaction.f;
    if ((flags2 & 2) !== 0) mark_effects(reaction, sources, marked, checked);
    else if ((flags2 & 4194320) !== 0 && (flags2 & 2048) === 0 && depends_on(reaction, sources, checked)) {
      set_signal_status(reaction, DIRTY);
      schedule_effect(reaction);
    }
  }
}
function depends_on(reaction, sources, checked) {
  const depends = checked.get(reaction);
  if (depends !== void 0) return depends;
  if (reaction.deps !== null) for (const dep of reaction.deps) {
    if (includes.call(sources, dep)) return true;
    if ((dep.f & 2) !== 0 && depends_on(dep, sources, checked)) {
      checked.set(dep, true);
      return true;
    }
  }
  checked.set(reaction, false);
  return false;
}
function schedule_effect(effect) {
  current_batch.schedule(effect);
}
function reset_branch(effect, tracked) {
  if ((effect.f & 32) !== 0 && (effect.f & 1024) !== 0) return;
  if ((effect.f & 2048) !== 0) tracked.d.push(effect);
  else if ((effect.f & 4096) !== 0) tracked.m.push(effect);
  set_signal_status(effect, CLEAN);
  var e = effect.first;
  while (e !== null) {
    reset_branch(e, tracked);
    e = e.next;
  }
}
function reset_all(effect) {
  set_signal_status(effect, CLEAN);
  var e = effect.first;
  while (e !== null) {
    reset_all(e);
    e = e.next;
  }
}
function source(v, stack) {
  return {
    f: 0,
    v,
    reactions: null,
    equals,
    rv: 0,
    wv: 0
  };
}
// @__NO_SIDE_EFFECTS__
function state(v, stack) {
  const s2 = source(v, stack);
  push_reaction_value(s2);
  return s2;
}
// @__NO_SIDE_EFFECTS__
function mutable_source(initial_value, immutable = false, trackable = true) {
  const s2 = source(initial_value);
  if (!immutable) s2.equals = safe_equals;
  if (legacy_mode_flag && trackable && component_context !== null && component_context.l !== null) (component_context.l.s ??= []).push(s2);
  return s2;
}
function set(source2, value, should_proxy = false) {
  if (active_reaction !== null && (!untracking || (active_reaction.f & 131072) !== 0) && is_runes() && (active_reaction.f & 4325394) !== 0 && (current_sources === null || !current_sources.has(source2))) state_unsafe_mutation();
  return internal_set(source2, should_proxy ? proxy(value) : value, legacy_updates);
}
function internal_set(source2, value, updated_during_traversal = null) {
  if (!source2.equals(value)) {
    if (is_destroying_effect) old_values.set(source2, value);
    else if (!old_values.has(source2)) old_values.set(source2, source2.v);
    var batch = Batch.ensure();
    batch.capture(source2, value);
    if ((source2.f & 2) !== 0) {
      const derived2 = source2;
      if ((source2.f & 2048) !== 0) execute_derived(derived2);
      if (batch_values === null) update_derived_status(derived2);
    }
    source2.wv = increment_write_version();
    mark_reactions(source2, DIRTY, updated_during_traversal);
    if (is_runes() && active_effect !== null && (active_effect.f & 1024) !== 0 && (active_effect.f & 96) === 0) {
      if (untracked_writes === null) set_untracked_writes([source2]);
      else untracked_writes.push(source2);
    }
    if (!batch.is_fork && eager_effects.size > 0 && !eager_effects_deferred) flush_eager_effects();
  }
  return value;
}
function flush_eager_effects() {
  eager_effects_deferred = false;
  for (const effect of eager_effects) {
    if ((effect.f & 1024) !== 0) set_signal_status(effect, MAYBE_DIRTY);
    let dirty;
    try {
      dirty = is_dirty(effect);
    } catch {
      dirty = true;
    }
    if (dirty) update_effect(effect);
  }
  eager_effects.clear();
}
function increment(source2) {
  set(source2, source2.v + 1);
}
function mark_reactions(signal, status, updated_during_traversal) {
  var reactions = signal.reactions;
  if (reactions === null) return;
  var runes = is_runes();
  var length = reactions.length;
  for (var i = 0; i < length; i++) {
    var reaction = reactions[i];
    var flags2 = reaction.f;
    if (!runes && reaction === active_effect) continue;
    var not_dirty = (flags2 & DIRTY) === 0;
    if (not_dirty) set_signal_status(reaction, status);
    if ((flags2 & 131072) !== 0) eager_effects.add(reaction);
    else if ((flags2 & 2) !== 0) {
      var derived2 = reaction;
      batch_values?.delete(derived2);
      if ((flags2 & 65536) === 0) {
        if (flags2 & 512 && (active_effect === null || (active_effect.f & 2097152) === 0)) reaction.f |= WAS_MARKED;
        mark_reactions(derived2, MAYBE_DIRTY, updated_during_traversal);
      }
    } else if (not_dirty) {
      var effect = reaction;
      if ((flags2 & 16) !== 0 && eager_block_effects !== null) eager_block_effects.add(effect);
      if (updated_during_traversal !== null) updated_during_traversal.push(effect);
      else schedule_effect(effect);
    }
  }
}
function proxy(value) {
  if (typeof value !== "object" || value === null || STATE_SYMBOL in value || COMPONENT_SYMBOL in value) return value;
  const prototype = get_prototype_of(value);
  if (prototype !== object_prototype && prototype !== array_prototype) return value;
  var sources = /* @__PURE__ */ new Map();
  var is_proxied_array = is_array(value);
  var version = /* @__PURE__ */ state(0);
  var stack = null;
  var parent_version = update_version;
  var with_parent = (fn) => {
    if (update_version === parent_version) return fn();
    var reaction = active_reaction;
    var version2 = update_version;
    set_active_reaction(null);
    set_update_version(parent_version);
    var result = fn();
    set_active_reaction(reaction);
    set_update_version(version2);
    return result;
  };
  if (is_proxied_array) sources.set("length", /* @__PURE__ */ state(
    /** @type {any[]} */
    value.length,
    stack
  ));
  return new Proxy(value, {
    defineProperty(_, prop, descriptor) {
      if (!("value" in descriptor) || descriptor.configurable === false || descriptor.enumerable === false || descriptor.writable === false) state_descriptors_fixed();
      var s2 = sources.get(prop);
      if (s2 === void 0) with_parent(() => {
        var s3 = /* @__PURE__ */ state(descriptor.value, stack);
        sources.set(prop, s3);
        return s3;
      });
      else set(s2, descriptor.value, true);
      return true;
    },
    deleteProperty(target, prop) {
      var s2 = sources.get(prop);
      if (s2 === void 0) {
        if (prop in target) {
          const s3 = with_parent(() => /* @__PURE__ */ state(UNINITIALIZED, stack));
          sources.set(prop, s3);
          increment(version);
        }
      } else {
        set(s2, UNINITIALIZED);
        increment(version);
      }
      return true;
    },
    get(target, prop, receiver) {
      if (prop === STATE_SYMBOL) return value;
      var s2 = sources.get(prop);
      var exists = prop in target;
      if (s2 === void 0 && (!exists || get_descriptor(target, prop)?.writable)) {
        s2 = with_parent(() => {
          return /* @__PURE__ */ state(proxy(exists ? target[prop] : UNINITIALIZED), stack);
        });
        sources.set(prop, s2);
      }
      if (s2 !== void 0) {
        var v = get(s2);
        return v === UNINITIALIZED ? void 0 : v;
      }
      return Reflect.get(target, prop, receiver);
    },
    getOwnPropertyDescriptor(target, prop) {
      var descriptor = Reflect.getOwnPropertyDescriptor(target, prop);
      if (descriptor && "value" in descriptor) {
        var s2 = sources.get(prop);
        if (s2) descriptor.value = get(s2);
      } else if (descriptor === void 0) {
        var source2 = sources.get(prop);
        var value2 = source2?.v;
        if (source2 !== void 0 && value2 !== UNINITIALIZED) return {
          enumerable: true,
          configurable: true,
          value: value2,
          writable: true
        };
      }
      return descriptor;
    },
    has(target, prop) {
      if (prop === STATE_SYMBOL) return true;
      var s2 = sources.get(prop);
      var has = s2 !== void 0 && s2.v !== UNINITIALIZED || Reflect.has(target, prop);
      if (s2 !== void 0 || active_effect !== null && (!has || get_descriptor(target, prop)?.writable)) {
        if (s2 === void 0) {
          s2 = with_parent(() => {
            return /* @__PURE__ */ state(has ? proxy(target[prop]) : UNINITIALIZED, stack);
          });
          sources.set(prop, s2);
        }
        if (get(s2) === UNINITIALIZED) return false;
      }
      return has;
    },
    set(target, prop, value2, receiver) {
      var s2 = sources.get(prop);
      var has = prop in target;
      if (is_proxied_array && prop === "length") for (var i = value2; i < s2.v; i += 1) {
        var other_s = sources.get(i + "");
        if (other_s !== void 0) set(other_s, UNINITIALIZED);
        else if (i in target) {
          other_s = with_parent(() => /* @__PURE__ */ state(UNINITIALIZED, stack));
          sources.set(i + "", other_s);
        }
      }
      if (s2 === void 0) {
        if (!has || get_descriptor(target, prop)?.writable) {
          s2 = with_parent(() => /* @__PURE__ */ state(void 0, stack));
          set(s2, proxy(value2));
          sources.set(prop, s2);
        }
      } else {
        has = s2.v !== UNINITIALIZED;
        var p = with_parent(() => proxy(value2));
        set(s2, p);
      }
      var descriptor = Reflect.getOwnPropertyDescriptor(target, prop);
      if (descriptor?.set) descriptor.set.call(receiver, value2);
      if (!has) {
        if (is_proxied_array && typeof prop === "string") {
          var ls = sources.get("length");
          var n = Number(prop);
          if (Number.isInteger(n) && n >= ls.v) set(ls, n + 1);
        }
        increment(version);
      }
      return true;
    },
    ownKeys(target) {
      get(version);
      var own_keys = Reflect.ownKeys(target).filter((key3) => {
        var source3 = sources.get(key3);
        return source3 === void 0 || source3.v !== UNINITIALIZED;
      });
      for (var [key2, source2] of sources) if (source2.v !== UNINITIALIZED && !(key2 in target)) own_keys.push(key2);
      return own_keys;
    },
    setPrototypeOf() {
      state_prototype_fixed();
    }
  });
}
function init_operations() {
  if ($window !== void 0) return;
  $window = window;
  /Firefox/.test(navigator.userAgent);
  var element_prototype = Element.prototype;
  var node_prototype = Node.prototype;
  var text_prototype = Text.prototype;
  first_child_getter = get_descriptor(node_prototype, "firstChild").get;
  next_sibling_getter = get_descriptor(node_prototype, "nextSibling").get;
  if (is_extensible(element_prototype)) {
    element_prototype[CLASS_CACHE] = void 0;
    element_prototype[ATTRIBUTES_CACHE] = null;
    element_prototype[STYLE_CACHE] = void 0;
    element_prototype.__e = void 0;
  }
  if (is_extensible(text_prototype))
    text_prototype[TEXT_CACHE] = void 0;
}
function create_text(value = "") {
  return document.createTextNode(value);
}
// @__NO_SIDE_EFFECTS__
function get_first_child(node) {
  return first_child_getter.call(node);
}
// @__NO_SIDE_EFFECTS__
function get_next_sibling(node) {
  return next_sibling_getter.call(node);
}
function clear_text_content(node) {
  node.textContent = "";
}
function handle_error(error2) {
  var effect = active_effect;
  if (effect === null) {
    active_reaction.f |= ERROR_VALUE;
    return error2;
  }
  if ((effect.f & 32768) === 0 && (effect.f & 4) === 0) throw error2;
  invoke_error_boundary(error2, effect);
}
function invoke_error_boundary(error2, effect) {
  if (effect !== null && (effect.f & 16384) !== 0) return;
  while (effect !== null) {
    if ((effect.f & 128) !== 0 && (effect.f & 33570816) === 0) {
      if ((effect.f & 32768) === 0) throw error2;
      try {
        effect.b.error(error2);
        return;
      } catch (e) {
        error2 = e;
      }
    }
    effect = effect.parent;
  }
  throw error2;
}
function push_effect(effect, parent_effect) {
  var parent_last = parent_effect.last;
  if (parent_last === null) parent_effect.last = parent_effect.first = effect;
  else {
    parent_last.next = effect;
    effect.prev = parent_last;
    parent_effect.last = effect;
  }
}
function create_effect(type, fn) {
  var parent = active_effect;
  if (parent !== null && (parent.f & 8192) !== 0) type |= INERT;
  var effect = {
    ctx: component_context,
    deps: null,
    nodes: null,
    f: type | DIRTY | 512,
    first: null,
    fn,
    last: null,
    next: null,
    parent,
    b: parent && parent.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  current_batch?.register_created_effect(effect);
  var e = effect;
  if ((type & 4) !== 0) {
    if (collected_effects !== null) collected_effects.push(effect);
    else Batch.ensure().schedule(effect);
  } else if (fn !== null) {
    try {
      update_effect(effect);
    } catch (e2) {
      destroy_effect(effect);
      throw e2;
    }
    if (e.deps === null && e.teardown === null && e.nodes === null && e.first === e.last && (e.f & 524288) === 0) {
      e = e.first;
      if ((type & 16) !== 0 && (type & 65536) !== 0 && e !== null) e.f |= EFFECT_TRANSPARENT;
    }
  }
  if (e !== null) {
    e.parent = parent;
    if (parent !== null) push_effect(e, parent);
    if (active_reaction !== null && (active_reaction.f & 2) !== 0 && (type & 64) === 0) {
      var derived2 = active_reaction;
      (derived2.effects ??= []).push(e);
    }
  }
  return effect;
}
function effect_tracking() {
  return active_reaction !== null && !untracking;
}
function create_user_effect(fn) {
  return create_effect(4 | USER_EFFECT, fn);
}
function component_root(fn) {
  Batch.ensure();
  const effect = create_effect(64 | EFFECT_PRESERVED, fn);
  return (options2 = {}) => {
    return new Promise((fulfil) => {
      if (options2.outro) pause_effect(effect, () => {
        destroy_effect(effect);
        fulfil(void 0);
      });
      else {
        destroy_effect(effect);
        fulfil(void 0);
      }
    });
  };
}
function render_effect(fn, flags2 = 0) {
  return create_effect(8 | flags2, fn);
}
function block(fn, flags2 = 0) {
  return create_effect(16 | flags2, fn);
}
function branch(fn) {
  return create_effect(32 | EFFECT_PRESERVED, fn);
}
function execute_effect_teardown(effect) {
  var teardown = effect.teardown;
  if (teardown !== null) {
    const previously_destroying_effect = is_destroying_effect;
    const previous_reaction = active_reaction;
    set_is_destroying_effect(true);
    set_active_reaction(null);
    try {
      teardown.call(null);
    } catch (error2) {
      invoke_error_boundary(error2, effect.parent);
    } finally {
      set_is_destroying_effect(previously_destroying_effect);
      set_active_reaction(previous_reaction);
    }
  }
}
function destroy_effect_children(signal, remove_dom = false) {
  var effect = signal.first;
  signal.first = signal.last = null;
  while (effect !== null) {
    const controller = effect.ac;
    if (controller !== null) without_reactive_context(() => {
      controller.abort(STALE_REACTION);
    });
    var next2 = effect.next;
    if ((effect.f & 64) !== 0) effect.parent = null;
    else destroy_effect(effect, remove_dom);
    effect = next2;
  }
}
function destroy_block_effect_children(signal) {
  var effect = signal.first;
  while (effect !== null) {
    var next2 = effect.next;
    if ((effect.f & 32) === 0) destroy_effect(effect);
    effect = next2;
  }
}
function destroy_effect(effect, remove_dom = true) {
  var removed = false;
  if ((remove_dom || (effect.f & 262144) !== 0) && effect.nodes !== null && effect.nodes.end !== null) {
    remove_effect_dom(effect.nodes.start, effect.nodes.end);
    removed = true;
  }
  effect.f |= DESTROYING;
  destroy_effect_children(effect, remove_dom && !removed);
  remove_reactions(effect, 0);
  var transitions = effect.nodes && effect.nodes.t;
  if (transitions !== null) for (const transition of transitions) transition.stop();
  execute_effect_teardown(effect);
  effect.f ^= DESTROYING;
  effect.f |= DESTROYED;
  var parent = effect.parent;
  if (parent !== null && parent.first !== null) unlink_effect(effect);
  effect.next = effect.prev = effect.teardown = effect.ctx = effect.deps = effect.fn = effect.nodes = effect.ac = effect.b = null;
}
function remove_effect_dom(node, end) {
  while (node !== null) {
    var next2 = node === end ? null : /* @__PURE__ */ get_next_sibling(node);
    node.remove();
    node = next2;
  }
}
function unlink_effect(effect) {
  var parent = effect.parent;
  var prev = effect.prev;
  var next2 = effect.next;
  if (prev !== null) prev.next = next2;
  if (next2 !== null) next2.prev = prev;
  if (parent !== null) {
    if (parent.first === effect) parent.first = next2;
    if (parent.last === effect) parent.last = prev;
  }
}
function pause_effect(effect, callback, destroy = true) {
  var transitions = [];
  effect.f |= 256;
  pause_children(effect, transitions, true);
  var fn = () => {
    if (destroy) destroy_effect(effect);
    if (callback) callback();
  };
  var remaining = transitions.length;
  if (remaining > 0) {
    var check = () => --remaining || fn();
    for (var transition of transitions) transition.out(check);
  } else fn();
}
function pause_children(effect, transitions, local) {
  if ((effect.f & 8192) !== 0) return;
  effect.f ^= INERT;
  var t = effect.nodes && effect.nodes.t;
  if (t !== null) {
    for (const transition of t) if (transition.is_global || local) transitions.push(transition);
  }
  var child = effect.first;
  while (child !== null) {
    var sibling = child.next;
    if ((child.f & 64) === 0) {
      var transparent = (child.f & 65536) !== 0 || (child.f & 32) !== 0 && (effect.f & 16) !== 0;
      pause_children(child, transitions, transparent ? local : false);
    }
    child = sibling;
  }
}
function move_effect(effect, fragment) {
  if (!effect.nodes) return;
  var node = effect.nodes.start;
  var end = effect.nodes.end;
  while (node !== null) {
    var next2 = node === end ? null : /* @__PURE__ */ get_next_sibling(node);
    fragment.append(node);
    node = next2;
  }
}
function set_is_destroying_effect(value) {
  is_destroying_effect = value;
}
function set_active_reaction(reaction) {
  active_reaction = reaction;
}
function set_active_effect(effect) {
  active_effect = effect;
}
function push_reaction_value(value) {
  if (active_reaction !== null && (!async_mode_flag || (active_reaction.f & 2) !== 0)) (current_sources ??= /* @__PURE__ */ new Set()).add(value);
}
function set_untracked_writes(value) {
  untracked_writes = value;
}
function set_update_version(value) {
  update_version = value;
}
function increment_write_version() {
  return ++write_version;
}
function is_dirty(reaction) {
  var flags2 = reaction.f;
  if ((flags2 & 2048) !== 0) return true;
  if (flags2 & 2) reaction.f &= ~WAS_MARKED;
  if ((flags2 & 4096) !== 0) {
    var dependencies = reaction.deps;
    var length = dependencies.length;
    for (var i = 0; i < length; i++) {
      var dependency = dependencies[i];
      if (is_dirty(dependency)) update_derived(dependency);
      if (dependency.wv > reaction.wv) return true;
    }
    if ((flags2 & 512) !== 0 && batch_values === null) set_signal_status(reaction, CLEAN);
  }
  return false;
}
function schedule_possible_effect_self_invalidation(signal, effect, root = true) {
  var reactions = signal.reactions;
  if (reactions === null) return;
  if (!async_mode_flag && current_sources !== null && current_sources.has(signal)) return;
  for (var i = 0; i < reactions.length; i++) {
    var reaction = reactions[i];
    if ((reaction.f & 2) !== 0) schedule_possible_effect_self_invalidation(reaction, effect, false);
    else if (effect === reaction) {
      if (root) set_signal_status(reaction, DIRTY);
      else if ((reaction.f & 1024) !== 0) set_signal_status(reaction, MAYBE_DIRTY);
      schedule_effect(reaction);
    }
  }
}
function update_reaction(reaction) {
  var previous_deps = new_deps;
  var previous_skipped_deps = skipped_deps;
  var previous_untracked_writes = untracked_writes;
  var previous_reaction = active_reaction;
  var previous_sources = current_sources;
  var previous_component_context = component_context;
  var previous_untracking = untracking;
  var previous_update_version = update_version;
  var flags2 = reaction.f;
  new_deps = null;
  skipped_deps = 0;
  untracked_writes = null;
  active_reaction = (flags2 & 96) === 0 ? reaction : null;
  current_sources = null;
  set_component_context(reaction.ctx);
  untracking = false;
  update_version = ++read_version;
  if (reaction.ac !== null) {
    without_reactive_context(() => {
      reaction.ac.abort(STALE_REACTION);
    });
    reaction.ac = null;
  }
  try {
    reaction.f |= REACTION_IS_UPDATING;
    var fn = reaction.fn;
    var result = fn();
    reaction.f |= REACTION_RAN;
    var deps = update_dependencies(reaction);
    if (is_runes() && untracked_writes !== null && !untracking && deps !== null && (reaction.f & 6146) === 0) for (var i = 0; i < untracked_writes.length; i++) schedule_possible_effect_self_invalidation(untracked_writes[i], reaction);
    if (previous_reaction !== null && previous_reaction !== reaction) {
      read_version++;
      if (previous_reaction.deps !== null) for (let i2 = 0; i2 < previous_skipped_deps; i2 += 1) previous_reaction.deps[i2].rv = read_version;
      if (previous_deps !== null) for (const dep of previous_deps) dep.rv = read_version;
      if (untracked_writes !== null) {
        if (previous_untracked_writes === null) previous_untracked_writes = untracked_writes;
        else previous_untracked_writes.push(...untracked_writes);
      }
    }
    if ((reaction.f & 8388608) !== 0) reaction.f ^= ERROR_VALUE;
    return result;
  } catch (error2) {
    update_dependencies(reaction);
    return handle_error(error2);
  } finally {
    reaction.f ^= REACTION_IS_UPDATING;
    new_deps = previous_deps;
    skipped_deps = previous_skipped_deps;
    untracked_writes = previous_untracked_writes;
    active_reaction = previous_reaction;
    current_sources = previous_sources;
    set_component_context(previous_component_context);
    untracking = previous_untracking;
    update_version = previous_update_version;
  }
}
function update_dependencies(reaction) {
  var deps = reaction.deps;
  var is_fork = current_batch?.is_fork;
  if (new_deps !== null) {
    var i;
    if (!is_fork) remove_reactions(reaction, skipped_deps);
    if (deps !== null && skipped_deps > 0) {
      deps.length = skipped_deps + new_deps.length;
      for (i = 0; i < new_deps.length; i++) deps[skipped_deps + i] = new_deps[i];
    } else reaction.deps = deps = new_deps;
    if (effect_tracking() && (reaction.f & 512) !== 0) for (i = skipped_deps; i < deps.length; i++) (deps[i].reactions ??= []).push(reaction);
  } else if (!is_fork && deps !== null && skipped_deps < deps.length) {
    remove_reactions(reaction, skipped_deps);
    deps.length = skipped_deps;
  }
  return deps;
}
function remove_reaction(signal, dependency) {
  let reactions = dependency.reactions;
  if (reactions !== null) {
    var index7 = index_of.call(reactions, signal);
    if (index7 !== -1) {
      var new_length = reactions.length - 1;
      if (new_length === 0) reactions = dependency.reactions = null;
      else {
        reactions[index7] = reactions[new_length];
        reactions.pop();
      }
    }
  }
  if (reactions === null && (dependency.f & 2) !== 0 && (new_deps === null || !includes.call(new_deps, dependency))) {
    var derived2 = dependency;
    if ((derived2.f & 512) !== 0) {
      derived2.f ^= 512;
      derived2.f &= ~WAS_MARKED;
    }
    if (derived2.v !== UNINITIALIZED) update_derived_status(derived2);
    if (derived2.ac !== null) without_reactive_context(() => {
      derived2.ac.abort(STALE_REACTION);
      derived2.ac = null;
      set_signal_status(derived2, DIRTY);
    });
    freeze_derived_effects(derived2);
    remove_reactions(derived2, 0);
  }
}
function remove_reactions(signal, start_index) {
  var dependencies = signal.deps;
  if (dependencies === null) return;
  for (var i = start_index; i < dependencies.length; i++) remove_reaction(signal, dependencies[i]);
}
function update_effect(effect) {
  var flags2 = effect.f;
  if ((flags2 & 16384) !== 0) return;
  set_signal_status(effect, CLEAN);
  var previous_effect = active_effect;
  var was_updating_effect = is_updating_effect;
  active_effect = effect;
  is_updating_effect = (flags2 & 96) === 0;
  try {
    if ((flags2 & 16777232) !== 0) destroy_block_effect_children(effect);
    else destroy_effect_children(effect);
    execute_effect_teardown(effect);
    var teardown = update_reaction(effect);
    effect.teardown = typeof teardown === "function" ? teardown : null;
    effect.wv = write_version;
  } finally {
    is_updating_effect = was_updating_effect;
    active_effect = previous_effect;
  }
}
function get(signal) {
  var is_derived = (signal.f & 2) !== 0;
  captured_signals?.add(signal);
  if (active_reaction !== null && !untracking) {
    if (!(active_effect !== null && (active_effect.f & 16384) !== 0) && (current_sources === null || !current_sources.has(signal))) {
      var deps = active_reaction.deps;
      if ((active_reaction.f & 2097152) !== 0) {
        if (signal.rv < read_version) {
          signal.rv = read_version;
          if (new_deps === null && deps !== null && deps[skipped_deps] === signal) skipped_deps++;
          else if (new_deps === null) new_deps = [signal];
          else new_deps.push(signal);
        }
      } else {
        active_reaction.deps ??= [];
        if (!includes.call(active_reaction.deps, signal)) active_reaction.deps.push(signal);
        var reactions = signal.reactions;
        if (reactions === null) signal.reactions = [active_reaction];
        else if (!includes.call(reactions, active_reaction)) reactions.push(active_reaction);
      }
    }
  }
  if (is_destroying_effect && old_values.has(signal)) return old_values.get(signal);
  if (is_derived) {
    var derived2 = signal;
    if (is_destroying_effect) {
      var value = derived2.v;
      if ((derived2.f & 1024) === 0 && derived2.reactions !== null || depends_on_old_values(derived2)) value = execute_derived(derived2);
      old_values.set(derived2, value);
      return value;
    }
    var should_connect = (derived2.f & 512) === 0 && !untracking && active_reaction !== null && (is_updating_effect || (active_reaction.f & 512) !== 0);
    var is_new = (derived2.f & REACTION_RAN) === 0;
    if (is_dirty(derived2)) {
      if (should_connect) derived2.f |= 512;
      update_derived(derived2);
    }
    if (should_connect && !is_new) {
      unfreeze_derived_effects(derived2);
      reconnect(derived2);
    }
  }
  if (batch_values?.has(signal)) return batch_values.get(signal);
  if ((signal.f & 8388608) !== 0) throw signal.v;
  return signal.v;
}
function reconnect(derived2) {
  derived2.f |= 512;
  if (derived2.deps === null) return;
  for (const dep of derived2.deps) {
    (dep.reactions ??= []).push(derived2);
    if ((dep.f & 2) !== 0 && (dep.f & 512) === 0) {
      unfreeze_derived_effects(dep);
      reconnect(dep);
    }
  }
}
function depends_on_old_values(derived2) {
  if (derived2.v === UNINITIALIZED) return true;
  if (derived2.deps === null) return false;
  for (const dep of derived2.deps) {
    if (old_values.has(dep)) return true;
    if ((dep.f & 2) !== 0 && depends_on_old_values(dep)) return true;
  }
  return false;
}
function untrack(fn) {
  var previous_untracking = untracking;
  try {
    untracking = true;
    return fn();
  } finally {
    untracking = previous_untracking;
  }
}
function subscribe_to_store(store, run2, invalidate) {
  if (store == null) {
    run2(void 0);
    if (invalidate) invalidate(void 0);
    return noop;
  }
  const unsub = untrack(() => store.subscribe(run2, invalidate));
  return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
}
function readable(value, start) {
  return { subscribe: writable(value, start).subscribe };
}
function writable(value, start = noop) {
  let stop = null;
  const subscribers = /* @__PURE__ */ new Set();
  function set2(new_value) {
    if (safe_not_equal(value, new_value)) {
      value = new_value;
      if (stop) {
        const run_queue = !subscriber_queue.length;
        for (const subscriber of subscribers) {
          subscriber[1]();
          subscriber_queue.push(subscriber, value);
        }
        if (run_queue) {
          for (let i = 0; i < subscriber_queue.length; i += 2) subscriber_queue[i][0](subscriber_queue[i + 1]);
          subscriber_queue.length = 0;
        }
      }
    }
  }
  function update(fn) {
    set2(fn(value));
  }
  function subscribe(run2, invalidate = noop) {
    const subscriber = [run2, invalidate];
    subscribers.add(subscriber);
    if (subscribers.size === 1) stop = start(set2, update) || noop;
    run2(value);
    return () => {
      subscribers.delete(subscriber);
      if (subscribers.size === 0 && stop) {
        stop();
        stop = null;
      }
    };
  }
  return {
    set: set2,
    update,
    subscribe
  };
}
function is_boolean_attribute(name) {
  return DOM_BOOLEAN_ATTRIBUTES.includes(name);
}
function is_passive_event(name) {
  return PASSIVE_EVENTS.includes(name);
}
function escape_html(value, is_attr) {
  const str = String(value ?? "");
  const pattern2 = is_attr ? ATTR_REGEX : CONTENT_REGEX;
  pattern2.lastIndex = 0;
  let escaped = "";
  let last = 0;
  while (pattern2.test(str)) {
    const i = pattern2.lastIndex - 1;
    const ch = str[i];
    escaped += str.substring(last, i) + (ch === "&" ? "&amp;" : ch === '"' ? "&quot;" : "&lt;");
    last = i + 1;
  }
  return escaped + str.substring(last);
}
function attr(name, value, is_boolean = false) {
  if (name === "hidden" && value !== "until-found") is_boolean = true;
  if (value == null || is_boolean && !value && value !== "") return "";
  const normalized = has_own_property.call(replacements, name) && replacements[name].get(value) || value;
  return ` ${name}${is_boolean ? `=""` : `="${escape_html(normalized, true)}"`}`;
}
function clsx$1(value) {
  if (typeof value === "object") return clsx(value);
  else return value ?? "";
}
function to_class(value, hash2, directives) {
  var classname = value == null ? "" : "" + value;
  if (hash2) classname = classname ? classname + " " + hash2 : hash2;
  if (directives) {
    for (var key2 of Object.keys(directives)) if (directives[key2]) classname = classname ? classname + " " + key2 : key2;
    else if (classname.length) {
      var len = key2.length;
      var a = 0;
      while ((a = classname.indexOf(key2, a)) >= 0) {
        var b = a + len;
        if ((a === 0 || whitespace.includes(classname[a - 1])) && (b === classname.length || whitespace.includes(classname[b]))) classname = (a === 0 ? "" : classname.substring(0, a)) + classname.substring(b + 1);
        else a = b;
      }
    }
  }
  return classname === "" ? null : classname;
}
function append_styles(styles, important = false) {
  var separator = important ? " !important;" : ";";
  var css = "";
  for (var key2 of Object.keys(styles)) {
    var value = styles[key2];
    if (value != null && value !== "") css += " " + key2 + ": " + value + separator;
  }
  return css;
}
function to_css_name(name) {
  if (name[0] !== "-" || name[1] !== "-") return name.toLowerCase();
  return name;
}
function to_style(value, styles) {
  if (styles) {
    var new_style = "";
    var normal_styles;
    var important_styles;
    if (Array.isArray(styles)) {
      normal_styles = styles[0];
      important_styles = styles[1];
    } else normal_styles = styles;
    if (value) {
      value = String(value).replaceAll(/\/\*.*?\*\//g, "").trim();
      var in_str = false;
      var in_apo = 0;
      var in_comment = false;
      var reserved_names = [];
      if (normal_styles) reserved_names.push(...Object.keys(normal_styles).map(to_css_name));
      if (important_styles) reserved_names.push(...Object.keys(important_styles).map(to_css_name));
      var start_index = 0;
      var name_index = -1;
      const len = value.length;
      for (var i = 0; i < len; i++) {
        var c = value[i];
        if (in_comment) {
          if (c === "/" && value[i - 1] === "*") in_comment = false;
        } else if (in_str) {
          if (in_str === c) in_str = false;
        } else if (c === "/" && value[i + 1] === "*") in_comment = true;
        else if (c === '"' || c === "'") in_str = c;
        else if (c === "(") in_apo++;
        else if (c === ")") in_apo--;
        if (!in_comment && in_str === false && in_apo === 0) {
          if (c === ":" && name_index === -1) name_index = i;
          else if (c === ";" || i === len - 1) {
            if (name_index !== -1) {
              var name = to_css_name(value.substring(start_index, name_index).trim());
              if (!reserved_names.includes(name)) {
                if (c !== ";") i++;
                var property = value.substring(start_index, i).trim();
                new_style += " " + property + ";";
              }
            }
            start_index = i + 1;
            name_index = -1;
          }
        }
      }
    }
    if (normal_styles) new_style += append_styles(normal_styles);
    if (important_styles) new_style += append_styles(important_styles, true);
    new_style = new_style.trim();
    return new_style === "" ? null : new_style;
  }
  return value == null ? null : String(value);
}
function set_ssr_context(v) {
  ssr_context = v;
}
function createContext() {
  return create_context(getContext, setContext, hasContext);
}
function getContext(key2) {
  return get_or_init_context_map(ssr_context, "getContext").get(key2);
}
function setContext(key2, context2) {
  get_or_init_context_map(ssr_context, "setContext").set(key2, context2);
  return context2;
}
function hasContext(key2) {
  return get_or_init_context_map(ssr_context, "hasContext").has(key2);
}
function getAllContexts() {
  return get_or_init_context_map(ssr_context, "getAllContexts");
}
function push(fn) {
  ssr_context = {
    p: ssr_context,
    c: null,
    r: null
  };
}
function pop() {
  ssr_context = ssr_context.p;
}
function async_local_storage_unavailable() {
  const error2 = /* @__PURE__ */ new Error(`async_local_storage_unavailable
The node API \`AsyncLocalStorage\` is not available, but is required to use async server rendering.
https://svelte.dev/e/async_local_storage_unavailable`);
  error2.name = "Svelte error";
  throw error2;
}
function await_invalid() {
  const error2 = /* @__PURE__ */ new Error(`await_invalid
Encountered asynchronous work while rendering synchronously.
https://svelte.dev/e/await_invalid`);
  error2.name = "Svelte error";
  throw error2;
}
function html_deprecated() {
  const error2 = /* @__PURE__ */ new Error(`html_deprecated
The \`html\` property of server render results has been deprecated. Use \`body\` instead.
https://svelte.dev/e/html_deprecated`);
  error2.name = "Svelte error";
  throw error2;
}
function hydratable_serialization_failed(key2, stack) {
  const error2 = /* @__PURE__ */ new Error(`hydratable_serialization_failed
Failed to serialize \`hydratable\` data for key \`${key2}\`.

\`hydratable\` can serialize anything [\`uneval\` from \`devalue\`](https://npmjs.com/package/uneval) can, plus Promises.

Cause:
${stack}
https://svelte.dev/e/hydratable_serialization_failed`);
  error2.name = "Svelte error";
  throw error2;
}
function invalid_csp() {
  const error2 = /* @__PURE__ */ new Error(`invalid_csp
\`csp.nonce\` was set while \`csp.hash\` was \`true\`. These options cannot be used simultaneously.
https://svelte.dev/e/invalid_csp`);
  error2.name = "Svelte error";
  throw error2;
}
function invalid_id_prefix() {
  const error2 = /* @__PURE__ */ new Error(`invalid_id_prefix
The \`idPrefix\` option cannot include \`--\`.
https://svelte.dev/e/invalid_id_prefix`);
  error2.name = "Svelte error";
  throw error2;
}
function lifecycle_function_unavailable(name) {
  const error2 = /* @__PURE__ */ new Error(`lifecycle_function_unavailable
\`${name}(...)\` is not available on the server
https://svelte.dev/e/lifecycle_function_unavailable`);
  error2.name = "Svelte error";
  throw error2;
}
function server_context_required() {
  const error2 = /* @__PURE__ */ new Error(`server_context_required
Could not resolve \`render\` context.
https://svelte.dev/e/server_context_required`);
  error2.name = "Svelte error";
  throw error2;
}
function unresolved_hydratable(key2, stack) {
  console.warn(`https://svelte.dev/e/unresolved_hydratable`);
}
function get_render_context() {
  const store = context ?? als?.getStore();
  if (!store) server_context_required();
  return store;
}
async function with_render_context(fn) {
  context = { hydratable: {
    lookup: /* @__PURE__ */ new Map(),
    comparisons: [],
    unresolved_promises: /* @__PURE__ */ new Map()
  } };
  if (in_webcontainer()) {
    const { promise, resolve: resolve2 } = deferred();
    const previous_render = current_render;
    current_render = promise;
    await previous_render;
    return fn().finally(resolve2);
  }
  try {
    if (als === null) async_local_storage_unavailable();
    return als.run(context, fn);
  } finally {
    context = null;
  }
}
function init_render_context() {
  als_import ??= import("node:async_hooks").then((hooks) => {
    als = new hooks.AsyncLocalStorage();
  }).then(noop, noop);
  return als_import;
}
function in_webcontainer() {
  return !!globalThis.process?.versions?.webcontainer;
}
async function sha256(data) {
  text_encoder ??= new TextEncoder();
  crypto2 ??= globalThis.crypto?.subtle?.digest ? globalThis.crypto : (await obfuscated_import("node:crypto")).webcrypto;
  return base64_encode(await crypto2.subtle.digest("SHA-256", text_encoder.encode(data)));
}
function base64_encode(bytes) {
  if (globalThis.Buffer) return globalThis.Buffer.from(bytes).toString("base64");
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
function html(value) {
  return "<!---->" + String(value ?? "") + "<!---->";
}
function render(component7, options2 = {}) {
  if (options2.csp?.hash && options2.csp.nonce) invalid_csp();
  return Renderer.render(component7, options2);
}
function head(hash2, renderer, fn) {
  renderer.head((renderer2) => {
    renderer2.push(`<!--${hash2}-->`);
    renderer2.child(fn);
    renderer2.push(EMPTY_COMMENT);
  });
}
function attributes(attrs, css_hash, classes, styles, flags2 = 0) {
  if (styles) attrs.style = to_style(attrs.style, styles);
  if (attrs.class) attrs.class = clsx$1(attrs.class);
  if (css_hash || classes) attrs.class = to_class(attrs.class, css_hash, classes);
  let attr_str = "";
  let name;
  const is_html = (flags2 & 1) === 0;
  const lowercase = (flags2 & 2) === 0;
  const is_input = (flags2 & 4) !== 0;
  for (name of Object.keys(attrs)) {
    if (typeof attrs[name] === "function") continue;
    if (name[0] === "$" && name[1] === "$") continue;
    if (name === "" || INVALID_ATTR_NAME_CHAR_REGEX.test(name)) continue;
    var value = attrs[name];
    var lower = name.toLowerCase();
    if (lowercase) name = lower;
    if (lower.length > 2 && lower.startsWith("on")) continue;
    if (is_input) {
      if (name === "defaultvalue" || name === "defaultchecked") {
        name = name === "defaultvalue" ? "value" : "checked";
        if (attrs[name]) continue;
      }
    }
    attr_str += attr(name, value, is_html && is_boolean_attribute(name));
  }
  return attr_str;
}
function stringify(value) {
  return typeof value === "string" ? value : value == null ? "" : value + "";
}
function attr_class(value, hash2, directives) {
  var result = to_class(value, hash2, directives);
  return result ? ` class="${escape_html(result, true)}"` : "";
}
function store_get(store_values, store_name, store) {
  if (store_name in store_values && store_values[store_name][0] === store) return store_values[store_name][2];
  store_values[store_name]?.[1]();
  store_values[store_name] = [
    store,
    null,
    void 0
  ];
  const unsub = subscribe_to_store(
    store,
    /** @param {any} v */
    (v) => store_values[store_name][2] = v
  );
  store_values[store_name][1] = unsub;
  return store_values[store_name][2];
}
function unsubscribe_stores(store_values) {
  for (const store_name of Object.keys(store_values)) store_values[store_name][1]();
}
function slot(renderer, $$props, name, slot_props, fallback_fn) {
  var slot_fn = $$props.$$slots?.[name];
  if (slot_fn === true) slot_fn = $$props[name === "default" ? "children" : name];
  if (slot_fn !== void 0) slot_fn(renderer, slot_props);
  else fallback_fn?.();
}
function bind_props(props_parent, props_now) {
  for (const key2 of Object.keys(props_now)) {
    const initial_value = props_parent[key2];
    const value = props_now[key2];
    if (initial_value === void 0 && value !== void 0 && Object.getOwnPropertyDescriptor(props_parent, key2)?.set) props_parent[key2] = value;
  }
}
function ensure_array_like(array_like_or_iterator) {
  if (array_like_or_iterator) return array_like_or_iterator.length !== void 0 ? array_like_or_iterator : Array.from(array_like_or_iterator);
  return [];
}
function once(get_value) {
  let value = UNINITIALIZED;
  return () => {
    if (value === UNINITIALIZED) value = get_value();
    return value;
  };
}
function derived(fn) {
  const get_value = ssr_context === null ? fn : once(fn);
  let updated_value;
  return function(new_value) {
    if (arguments.length === 0) return updated_value ?? get_value();
    updated_value = new_value;
    return updated_value;
  };
}
function getAbortSignal() {
  let context2 = ssr_context;
  while (context2 !== null) {
    if (context2.r !== null) return context2.r.global.get_abort_signal();
    context2 = context2.p;
  }
  return new AbortController().signal;
}
function hydratable(key2, fn) {
  if (!async_mode_flag) experimental_async_required("hydratable");
  const { hydratable: hydratable2 } = get_render_context();
  let entry = hydratable2.lookup.get(key2);
  if (entry !== void 0) return entry.value;
  const value = fn();
  entry = encode(key2, value, hydratable2.unresolved_promises);
  hydratable2.lookup.set(key2, entry);
  return value;
}
function encode(key2, value, unresolved) {
  const entry = {
    value,
    serialized: ""
  };
  let uid2 = 1;
  entry.serialized = devalue.uneval(entry.value, (value2, uneval4) => {
    if (is_promise(value2)) {
      const placeholder = `"${uid2++}"`;
      const p = value2.then((v) => {
        entry.serialized = entry.serialized.replace(placeholder, () => `r(${uneval4(v)})`);
      }).catch((devalue_error) => hydratable_serialization_failed(key2, serialization_stack(entry.stack, devalue_error?.stack)));
      unresolved?.set(p, key2);
      p.catch(() => {
      }).finally(() => unresolved?.delete(p));
      (entry.promises ??= []).push(p);
      return placeholder;
    }
  });
  return entry;
}
function is_promise(value) {
  return Object.prototype.toString.call(value) === "[object Promise]";
}
function serialization_stack(root_stack, uneval_stack) {
  let out = "";
  if (root_stack) out += root_stack + "\n";
  if (uneval_stack) out += "Caused by:\n" + uneval_stack + "\n";
  return out || "<missing stack trace>";
}
function createRawSnippet(fn) {
  return (renderer, ...args) => {
    var getters = args.map((value) => () => value);
    renderer.push(fn(...getters).render().trim());
  };
}
function onDestroy(fn) {
  ssr_context.r.on_destroy(fn);
}
function createEventDispatcher() {
  return noop;
}
function mount() {
  lifecycle_function_unavailable("mount");
}
function hydrate() {
  lifecycle_function_unavailable("hydrate");
}
function unmount() {
  lifecycle_function_unavailable("unmount");
}
function fork() {
  lifecycle_function_unavailable("fork");
}
async function tick() {
}
async function settled() {
}
var __defProp2, __exportAll, is_array, index_of, includes, array_from, define_property, get_descriptor, object_prototype, array_prototype, get_prototype_of, is_extensible, has_own_property, noop, CLEAN, DIRTY, MAYBE_DIRTY, INERT, DESTROYED, REACTION_RAN, DESTROYING, EFFECT_TRANSPARENT, EFFECT_PRESERVED, USER_EFFECT, WAS_MARKED, REACTION_IS_UPDATING, ERROR_VALUE, STATE_SYMBOL, COMPONENT_SYMBOL, LEGACY_PROPS, ATTRIBUTES_CACHE, CLASS_CACHE, STYLE_CACHE, TEXT_CACHE, STALE_REACTION, HYDRATION_ERROR, UNINITIALIZED, hydrating, hydrate_node, async_mode_flag, legacy_mode_flag, component_context, micro_tasks, STATUS_MASK, legacy_is_updating_store, OBSOLETE, first_batch, last_batch, current_batch, previous_batch, batch_values, last_scheduled_effect, is_flushing_sync, is_processing, collected_effects, legacy_updates, flush_count, uid, Batch, eager_block_effects, eager_effects, old_values, eager_effects_deferred, $window, first_child_getter, next_sibling_getter, captured_signals, is_updating_effect, is_destroying_effect, active_reaction, untracking, active_effect, current_sources, new_deps, skipped_deps, untracked_writes, write_version, read_version, update_version, subscriber_queue, DOM_BOOLEAN_ATTRIBUTES, PASSIVE_EVENTS, ATTR_REGEX, CONTENT_REGEX, replacements, whitespace, BLOCK_OPEN, BLOCK_CLOSE, EMPTY_COMMENT, ssr_context, current_render, context, als, als_import, text_encoder, crypto2, obfuscated_import, Renderer, SSRState, INVALID_ATTR_NAME_CHAR_REGEX, index_server_exports;
var init_index_server = __esm({
  ".netlify/server/chunks/index-server.js"() {
    "use strict";
    __defProp2 = Object.defineProperty;
    __exportAll = (all, no_symbols) => {
      let target = {};
      for (var name in all) __defProp2(target, name, {
        get: all[name],
        enumerable: true
      });
      if (!no_symbols) __defProp2(target, Symbol.toStringTag, { value: "Module" });
      return target;
    };
    is_array = Array.isArray;
    index_of = Array.prototype.indexOf;
    includes = Array.prototype.includes;
    array_from = Array.from;
    define_property = Object.defineProperty;
    get_descriptor = Object.getOwnPropertyDescriptor;
    object_prototype = Object.prototype;
    array_prototype = Array.prototype;
    get_prototype_of = Object.getPrototypeOf;
    is_extensible = Object.isExtensible;
    has_own_property = Object.prototype.hasOwnProperty;
    noop = () => {
    };
    CLEAN = 1024;
    DIRTY = 2048;
    MAYBE_DIRTY = 4096;
    INERT = 8192;
    DESTROYED = 16384;
    REACTION_RAN = 32768;
    DESTROYING = 1 << 25;
    EFFECT_TRANSPARENT = 65536;
    EFFECT_PRESERVED = 1 << 19;
    USER_EFFECT = 1 << 20;
    WAS_MARKED = 65536;
    REACTION_IS_UPDATING = 1 << 21;
    ERROR_VALUE = 1 << 23;
    STATE_SYMBOL = /* @__PURE__ */ Symbol("$state");
    COMPONENT_SYMBOL = /* @__PURE__ */ Symbol("component");
    LEGACY_PROPS = /* @__PURE__ */ Symbol("legacy props");
    ATTRIBUTES_CACHE = /* @__PURE__ */ Symbol("attributes");
    CLASS_CACHE = /* @__PURE__ */ Symbol("class");
    STYLE_CACHE = /* @__PURE__ */ Symbol("style");
    TEXT_CACHE = /* @__PURE__ */ Symbol("text");
    STALE_REACTION = new class StaleReactionError extends Error {
      name = "StaleReactionError";
      message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
    }();
    globalThis.document?.contentType;
    HYDRATION_ERROR = {};
    UNINITIALIZED = /* @__PURE__ */ Symbol("uninitialized");
    hydrating = false;
    async_mode_flag = false;
    legacy_mode_flag = false;
    component_context = null;
    micro_tasks = [];
    STATUS_MASK = ~(DIRTY | MAYBE_DIRTY | CLEAN);
    legacy_is_updating_store = false;
    OBSOLETE = /* @__PURE__ */ Symbol("obsolete");
    first_batch = null;
    last_batch = null;
    current_batch = null;
    previous_batch = null;
    batch_values = null;
    last_scheduled_effect = null;
    is_flushing_sync = false;
    is_processing = false;
    collected_effects = null;
    legacy_updates = null;
    flush_count = 0;
    uid = 1;
    Batch = class Batch2 {
      id = uid++;
      /** True as soon as `#process` was called */
      #started = false;
      linked = true;
      /** @type {Batch | null} */
      #prev = null;
      /** @type {Batch | null} */
      #next = null;
      /** @type {Map<Effect, ReturnType<typeof deferred<any>>>} */
      async_deriveds = /* @__PURE__ */ new Map();
      /**
      * The current values of any signals that are updated in this batch.
      * Tuple format: [value, is_derived] (note: is_derived is false for deriveds, too, if they were overridden via assignment)
      * They keys of this map are identical to `this.#previous`
      * @type {Map<Value, [any, boolean]>}
      */
      current = /* @__PURE__ */ new Map();
      /**
      * The values of any signals (sources and deriveds) that are updated in this batch _before_ those updates took place.
      * They keys of this map are identical to `this.#current`
      * @type {Map<Value, any>}
      */
      previous = /* @__PURE__ */ new Map();
      /**
      * When the batch is committed (and the DOM is updated), we need to remove old branches
      * and append new ones by calling the functions added inside (if/each/key/etc) blocks
      * @type {Set<(batch: Batch) => void>}
      */
      #commit_callbacks = /* @__PURE__ */ new Set();
      /**
      * If a fork is discarded, we need to destroy any effects that are no longer needed
      * @type {Set<(batch: Batch) => void>}
      */
      #discard_callbacks = /* @__PURE__ */ new Set();
      /**
      * The number of async effects that are currently in flight
      */
      #pending = 0;
      /**
      * Async effects that are currently in flight, _not_ inside a pending boundary
      * @type {Map<Effect, number>}
      */
      #blocking_pending = /* @__PURE__ */ new Map();
      /**
      * A deferred that resolves when the batch is committed, used with `settled()`
      * TODO replace with Promise.withResolvers once supported widely enough
      * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
      */
      #deferred = null;
      /**
      * The root effects that need to be flushed
      * @type {Effect[]}
      */
      #roots = [];
      /**
      * Effects created while this batch was active.
      * @type {Effect[]}
      */
      #new_effects = [];
      /**
      * Deferred effects (which run after async work has completed) that are DIRTY
      * @type {Set<Effect>}
      */
      #dirty_effects = /* @__PURE__ */ new Set();
      /**
      * Deferred effects that are MAYBE_DIRTY
      * @type {Set<Effect>}
      */
      #maybe_dirty_effects = /* @__PURE__ */ new Set();
      /**
      * A map of branches that still exist, but will be destroyed when this batch
      * is committed — we skip over these during `process`.
      * The value contains child effects that were dirty/maybe_dirty before being reset,
      * so they can be rescheduled if the branch survives.
      * @type {Map<Effect, { d: Effect[], m: Effect[] }>}
      */
      #skipped_branches = /* @__PURE__ */ new Map();
      /**
      * Inverse of #skipped_branches which we need to tell prior batches to unskip them when committing
      * @type {Set<Effect>}
      */
      #unskipped_branches = /* @__PURE__ */ new Set();
      is_fork = false;
      #decrement_queued = false;
      constructor() {
        if (last_batch === null) first_batch = last_batch = this;
        else {
          last_batch.#next = this;
          this.#prev = last_batch;
        }
        last_batch = this;
      }
      #is_deferred() {
        if (this.is_fork) return true;
        for (const effect of this.#blocking_pending.keys()) {
          var e = effect;
          var skipped = false;
          while (e.parent !== null) {
            if (this.#skipped_branches.has(e)) {
              skipped = true;
              break;
            }
            e = e.parent;
          }
          if (!skipped) return true;
        }
        return false;
      }
      /**
      * Add an effect to the #skipped_branches map and reset its children
      * @param {Effect} effect
      */
      skip_effect(effect) {
        if (!this.#skipped_branches.has(effect)) this.#skipped_branches.set(effect, {
          d: [],
          m: []
        });
        this.#unskipped_branches.delete(effect);
      }
      /**
      * Remove an effect from the #skipped_branches map and reschedule
      * any tracked dirty/maybe_dirty child effects
      * @param {Effect} effect
      * @param {(e: Effect) => void} callback
      */
      unskip_effect(effect, callback = (e) => this.schedule(e)) {
        var tracked = this.#skipped_branches.get(effect);
        if (tracked) {
          this.#skipped_branches.delete(effect);
          for (var e of tracked.d) {
            set_signal_status(e, DIRTY);
            callback(e);
          }
          for (e of tracked.m) {
            set_signal_status(e, MAYBE_DIRTY);
            callback(e);
          }
        }
        this.#unskipped_branches.add(effect);
      }
      #process() {
        this.#started = true;
        if (flush_count++ > 1e3) {
          this.#unlink();
          infinite_loop_guard();
        }
        for (const e of this.#dirty_effects) {
          this.#maybe_dirty_effects.delete(e);
          set_signal_status(e, DIRTY);
          this.schedule(e);
        }
        for (const e of this.#maybe_dirty_effects) {
          set_signal_status(e, MAYBE_DIRTY);
          this.schedule(e);
        }
        const roots = this.#roots;
        this.#roots = [];
        this.apply();
        var effects = collected_effects = [];
        var render_effects = [];
        var updates = legacy_updates = [];
        for (const root of roots) try {
          this.#traverse(root, effects, render_effects);
        } catch (e) {
          reset_all(root);
          if (!this.#is_deferred()) this.discard();
          throw e;
        }
        current_batch = null;
        if (updates.length > 0) {
          var batch = Batch2.ensure();
          for (const e of updates) batch.schedule(e);
        }
        collected_effects = null;
        legacy_updates = null;
        if (this.#is_deferred()) {
          this.#defer_effects(render_effects);
          this.#defer_effects(effects);
          for (const [e, t] of this.#skipped_branches) reset_branch(e, t);
          if (updates.length > 0)
            current_batch.#process();
          return;
        }
        const earlier_batch = this.#find_earlier_batch();
        if (earlier_batch) {
          this.#defer_effects(render_effects);
          this.#defer_effects(effects);
          earlier_batch.#merge(this);
          return;
        }
        this.#dirty_effects.clear();
        this.#maybe_dirty_effects.clear();
        for (const fn of this.#commit_callbacks) fn(this);
        this.#commit_callbacks.clear();
        previous_batch = this;
        flush_queued_effects(render_effects);
        flush_queued_effects(effects);
        previous_batch = null;
        this.#deferred?.resolve();
        var next_batch = current_batch;
        if (this.#pending === 0 && (this.#roots.length === 0 || next_batch !== null)) {
          this.#unlink();
          if (async_mode_flag) {
            this.#commit();
            current_batch = next_batch;
          }
        }
        if (this.#roots.length > 0) {
          if (next_batch !== null) {
            const batch2 = next_batch;
            batch2.#roots.push(...this.#roots.filter((r) => !batch2.#roots.includes(r)));
          } else next_batch = this;
        }
        if (next_batch !== null) {
          old_values.clear();
          next_batch.#process();
        }
      }
      /**
      * Traverse the effect tree, executing effects or stashing
      * them for later execution as appropriate
      * @param {Effect} root
      * @param {Effect[]} effects
      * @param {Effect[]} render_effects
      */
      #traverse(root, effects, render_effects) {
        root.f ^= CLEAN;
        var effect = root.first;
        while (effect !== null) {
          var flags2 = effect.f;
          var is_branch = (flags2 & 96) !== 0;
          if (!(is_branch && (flags2 & 1024) !== 0 || (flags2 & 8192) !== 0 || this.#skipped_branches.has(effect)) && effect.fn !== null) {
            if (is_branch) effect.f ^= CLEAN;
            else if ((flags2 & 4) !== 0) effects.push(effect);
            else if (async_mode_flag && (flags2 & 16777224) !== 0) render_effects.push(effect);
            else if (is_dirty(effect)) {
              if ((flags2 & 16) !== 0) this.#maybe_dirty_effects.add(effect);
              update_effect(effect);
            }
            var child = effect.first;
            if (child !== null) {
              effect = child;
              continue;
            }
          }
          while (effect !== null) {
            var next2 = effect.next;
            if (next2 !== null) {
              effect = next2;
              break;
            }
            effect = effect.parent;
          }
        }
      }
      #find_earlier_batch() {
        var batch = this.#prev;
        while (batch !== null) {
          if (!batch.is_fork) {
            for (const [value, [, is_derived]] of this.current) if (batch.current.has(value) && !is_derived) return batch;
          }
          batch = batch.#prev;
        }
        return null;
      }
      /**
      * @param {Batch} batch
      */
      #merge(batch) {
        for (const [source2, value] of batch.current) {
          if (!this.previous.has(source2) && batch.previous.has(source2)) this.previous.set(source2, batch.previous.get(source2));
          this.current.set(source2, value);
        }
        for (const [effect, deferred2] of batch.async_deriveds) {
          const d = this.async_deriveds.get(effect);
          if (d) deferred2.promise.then(d.resolve).catch(d.reject);
        }
        batch.async_deriveds.clear();
        this.transfer_effects(batch.#dirty_effects, batch.#maybe_dirty_effects);
        const mark = (value) => {
          var reactions = value.reactions;
          if (reactions === null) return;
          if ((value.f & 2) !== 0 && (value.f & 6144) === 0) return;
          for (const reaction of reactions) {
            var flags2 = reaction.f;
            if ((flags2 & 2) !== 0) mark(reaction);
            else {
              var effect = reaction;
              if (flags2 & 4194320 && !this.async_deriveds.has(effect)) {
                this.#maybe_dirty_effects.delete(effect);
                set_signal_status(effect, DIRTY);
                this.schedule(effect);
              }
            }
          }
        };
        for (const source2 of this.current.keys()) mark(source2);
        this.oncommit(() => batch.discard());
        batch.#unlink();
        current_batch = this;
        this.#process();
      }
      /**
      * @param {Effect[]} effects
      */
      #defer_effects(effects) {
        for (var i = 0; i < effects.length; i += 1) defer_effect(effects[i], this.#dirty_effects, this.#maybe_dirty_effects);
      }
      /**
      * Associate a change to a given source with the current
      * batch, noting its previous and current values
      * @param {Value} source
      * @param {any} value
      * @param {boolean} [is_derived]
      */
      capture(source2, value, is_derived = false) {
        if (source2.v !== UNINITIALIZED && !this.previous.has(source2)) this.previous.set(source2, source2.v);
        if ((source2.f & 8388608) === 0) {
          this.current.set(source2, [value, is_derived]);
          batch_values?.set(source2, value);
        }
        if (!this.is_fork) source2.v = value;
      }
      activate() {
        current_batch = this;
      }
      deactivate() {
        current_batch = null;
        batch_values = null;
      }
      flush() {
        try {
          is_processing = true;
          current_batch = this;
          this.#process();
        } finally {
          flush_count = 0;
          last_scheduled_effect = null;
          collected_effects = null;
          legacy_updates = null;
          is_processing = false;
          current_batch = null;
          batch_values = null;
          old_values.clear();
        }
      }
      discard() {
        for (const fn of this.#discard_callbacks) fn(this);
        this.#discard_callbacks.clear();
        for (const deferred2 of this.async_deriveds.values()) deferred2.reject(OBSOLETE);
        this.#unlink();
        this.#deferred?.resolve();
      }
      /**
      * @param {Effect} effect
      */
      register_created_effect(effect) {
        this.#new_effects.push(effect);
      }
      #commit() {
        for (let batch = first_batch; batch !== null; batch = batch.#next) {
          var is_earlier = batch.id < this.id;
          var sources = [];
          for (const [source3, [value, is_derived]] of this.current) {
            if (batch.current.has(source3)) {
              var batch_value = batch.current.get(source3)[0];
              if (is_earlier && value !== batch_value) batch.current.set(source3, [value, is_derived]);
              else continue;
            }
            sources.push(source3);
          }
          if (is_earlier) for (const [effect, deferred2] of this.async_deriveds) {
            const d = batch.async_deriveds.get(effect);
            if (d) deferred2.promise.then(d.resolve).catch(d.reject);
          }
          var current2 = [...batch.current.keys()].filter((source3) => !batch.current.get(source3)[1]);
          if (!batch.#started || current2.length === 0) continue;
          var others = current2.filter((source3) => !this.current.has(source3));
          if (others.length === 0) {
            if (is_earlier) batch.discard();
          } else if (sources.length > 0) {
            if (is_earlier) for (const unskipped of this.#unskipped_branches) batch.unskip_effect(unskipped, (e) => {
              if ((e.f & 4194320) !== 0) batch.schedule(e);
              else batch.#defer_effects([e]);
            });
            batch.activate();
            var marked = /* @__PURE__ */ new Set();
            var checked = /* @__PURE__ */ new Map();
            for (var source2 of sources) mark_effects(source2, others, marked, checked);
            checked = /* @__PURE__ */ new Map();
            var current_unequal = [...batch.current].filter(([c, v1]) => {
              const v2 = this.current.get(c);
              if (!v2) return true;
              return v2[0] !== v1[0] || v2[1] !== v1[1];
            }).map(([c]) => c);
            if (current_unequal.length > 0) {
              for (const effect of this.#new_effects) if ((effect.f & 155648) === 0 && depends_on(effect, current_unequal, checked)) {
                if ((effect.f & 4194320) !== 0) {
                  set_signal_status(effect, DIRTY);
                  batch.schedule(effect);
                } else batch.#dirty_effects.add(effect);
              }
            }
            if (batch.#roots.length > 0 && !batch.#decrement_queued) {
              batch.apply();
              for (var root of batch.#roots) batch.#traverse(root, [], []);
              batch.#roots = [];
            }
            batch.deactivate();
          }
        }
      }
      /**
      * @param {boolean} blocking
      * @param {Effect} effect
      */
      increment(blocking, effect) {
        this.#pending += 1;
        if (blocking) {
          let blocking_pending_count = this.#blocking_pending.get(effect) ?? 0;
          this.#blocking_pending.set(effect, blocking_pending_count + 1);
        }
      }
      /**
      * @param {boolean} blocking
      * @param {Effect} effect
      */
      decrement(blocking, effect) {
        this.#pending -= 1;
        if (blocking) {
          let blocking_pending_count = this.#blocking_pending.get(effect) ?? 0;
          if (blocking_pending_count === 1) this.#blocking_pending.delete(effect);
          else this.#blocking_pending.set(effect, blocking_pending_count - 1);
        }
        if (this.#decrement_queued) return;
        this.#decrement_queued = true;
        queue_micro_task(() => {
          this.#decrement_queued = false;
          if (this.linked) this.flush();
        });
      }
      /**
      * @param {Set<Effect>} dirty_effects
      * @param {Set<Effect>} maybe_dirty_effects
      */
      transfer_effects(dirty_effects, maybe_dirty_effects) {
        for (const e of dirty_effects) this.#dirty_effects.add(e);
        for (const e of maybe_dirty_effects) this.#maybe_dirty_effects.add(e);
        dirty_effects.clear();
        maybe_dirty_effects.clear();
      }
      /** @param {(batch: Batch) => void} fn */
      oncommit(fn) {
        this.#commit_callbacks.add(fn);
      }
      /** @param {(batch: Batch) => void} fn */
      ondiscard(fn) {
        this.#discard_callbacks.add(fn);
      }
      settled() {
        return (this.#deferred ??= deferred()).promise;
      }
      static ensure() {
        if (current_batch === null) {
          const batch = current_batch = new Batch2();
          if (!is_processing && !is_flushing_sync) queue_micro_task(() => {
            if (!batch.#started) batch.flush();
          });
        }
        return current_batch;
      }
      apply() {
        if (!async_mode_flag || !this.is_fork && this.#prev === null && this.#next === null) {
          batch_values = null;
          return;
        }
        batch_values = /* @__PURE__ */ new Map();
        for (const [source2, [value]] of this.current) batch_values.set(source2, value);
        for (let batch = first_batch; batch !== null; batch = batch.#next) {
          if (batch === this || batch.is_fork) continue;
          var intersects = false;
          if (batch.id < this.id) for (const [source2, [, is_derived]] of batch.current) {
            if (is_derived) continue;
            if (this.current.has(source2)) {
              intersects = true;
              break;
            }
          }
          if (!intersects) {
            for (const [source2, previous] of batch.previous) if (!batch_values.has(source2)) batch_values.set(source2, previous);
          }
        }
      }
      /**
      *
      * @param {Effect} effect
      */
      schedule(effect) {
        last_scheduled_effect = effect;
        if (effect.b?.is_pending && (effect.f & 16777228) !== 0 && (effect.f & 32768) === 0) {
          effect.b.defer_effect(effect);
          return;
        }
        var e = effect;
        while (e.parent !== null) {
          e = e.parent;
          var flags2 = e.f;
          if (collected_effects !== null && e === active_effect) {
            if (async_mode_flag) return;
            if ((active_reaction === null || (active_reaction.f & 2) === 0) && !legacy_is_updating_store) return;
          }
          if ((flags2 & 96) !== 0) {
            if ((flags2 & 1024) === 0) return;
            e.f ^= CLEAN;
          }
        }
        this.#roots.push(e);
      }
      #unlink() {
        if (!this.linked) return;
        var prev = this.#prev;
        var next2 = this.#next;
        if (prev === null) first_batch = next2;
        else prev.#next = next2;
        if (next2 === null) last_batch = prev;
        else next2.#prev = prev;
        this.linked = false;
      }
    };
    eager_block_effects = null;
    eager_effects = /* @__PURE__ */ new Set();
    old_values = /* @__PURE__ */ new Map();
    eager_effects_deferred = false;
    captured_signals = null;
    is_updating_effect = false;
    is_destroying_effect = false;
    active_reaction = null;
    untracking = false;
    active_effect = null;
    current_sources = null;
    new_deps = null;
    skipped_deps = 0;
    untracked_writes = null;
    write_version = 1;
    read_version = 0;
    update_version = read_version;
    subscriber_queue = [];
    DOM_BOOLEAN_ATTRIBUTES = [
      "allowfullscreen",
      "async",
      "autofocus",
      "autoplay",
      "checked",
      "controls",
      "default",
      "disabled",
      "formnovalidate",
      "indeterminate",
      "inert",
      "ismap",
      "loop",
      "multiple",
      "muted",
      "nomodule",
      "novalidate",
      "open",
      "playsinline",
      "readonly",
      "required",
      "reversed",
      "seamless",
      "selected",
      "webkitdirectory",
      "defer",
      "disablepictureinpicture",
      "disableremoteplayback"
    ];
    [...DOM_BOOLEAN_ATTRIBUTES];
    PASSIVE_EVENTS = ["touchstart", "touchmove"];
    ATTR_REGEX = /[&"<]/g;
    CONTENT_REGEX = /[&<]/g;
    replacements = { translate: /* @__PURE__ */ new Map([[true, "yes"], [false, "no"]]) };
    whitespace = [..." 	\n\r\f\xA0\v\uFEFF"];
    BLOCK_OPEN = `<!--[-->`;
    BLOCK_CLOSE = `<!--]-->`;
    EMPTY_COMMENT = `<!---->`;
    ssr_context = null;
    current_render = null;
    context = null;
    als = null;
    als_import = null;
    obfuscated_import = (module_name) => import(
      /* @vite-ignore */
      module_name
    );
    Renderer = class Renderer2 {
      /**
      * The contents of the renderer.
      * @type {RendererItem[]}
      */
      #out = [];
      /**
      * Any `onDestroy` callbacks registered during execution of this renderer.
      * @type {(() => void)[] | undefined}
      */
      #on_destroy = void 0;
      /**
      * Whether this renderer is a component body.
      * @type {boolean}
      */
      #is_component_body = false;
      /**
      * If set, this renderer is an error boundary. When async collection
      * of the children fails, the failed snippet is rendered instead.
      * @type {{
      * 	failed: (renderer: Renderer, error: unknown, reset: () => void) => void;
      * 	transformError: (error: unknown) => unknown;
      * 	context: SSRContext | null;
      * } | null}
      */
      #boundary = null;
      /**
      * The type of string content that this renderer is accumulating.
      * @type {RendererType}
      */
      type;
      /** @type {Renderer | undefined} */
      #parent;
      /**
      * Asynchronous work associated with this renderer
      * @type {Promise<void> | undefined}
      */
      promise = void 0;
      /**
      * State which is associated with the content tree as a whole.
      * It will be re-exposed, uncopied, on all children.
      * @type {SSRState}
      * @readonly
      */
      global;
      /**
      * State that is local to the branch it is declared in.
      * It will be shallow-copied to all children.
      *
      * @type {{ select_value: any, multiple: boolean }}
      */
      local;
      /**
      * @param {SSRState} global
      * @param {Renderer | undefined} [parent]
      */
      constructor(global, parent) {
        this.#parent = parent;
        this.global = global;
        this.local = parent ? { ...parent.local } : {
          select_value: void 0,
          multiple: false
        };
        this.type = parent ? parent.type : "body";
      }
      /**
      * @param {(renderer: Renderer) => void} fn
      */
      head(fn) {
        const head2 = new Renderer2(this.global, this);
        head2.type = "head";
        this.#out.push(head2);
        head2.child(fn);
      }
      /**
      * @param {Array<Promise<void>>} blockers
      * @param {(renderer: Renderer) => void} fn
      */
      async_block(blockers, fn) {
        this.#out.push(BLOCK_OPEN);
        this.async(blockers, fn);
        this.#out.push(BLOCK_CLOSE);
      }
      /**
      * @param {Array<Promise<void>>} blockers
      * @param {(renderer: Renderer) => void} fn
      */
      async(blockers, fn) {
        let callback = fn;
        if (blockers.length > 0) {
          const context2 = ssr_context;
          callback = (renderer) => {
            return Promise.all(blockers).then(() => {
              const previous_context = ssr_context;
              try {
                set_ssr_context(context2);
                return fn(renderer);
              } finally {
                set_ssr_context(previous_context);
              }
            });
          };
        }
        this.child(callback);
      }
      /**
      * @param {Array<() => void>} thunks
      */
      run(thunks) {
        const context2 = ssr_context;
        let promise = Promise.resolve(thunks[0]());
        const promises = [promise];
        for (const fn of thunks.slice(1)) {
          promise = promise.then(() => {
            const previous_context = ssr_context;
            set_ssr_context(context2);
            try {
              return fn();
            } finally {
              set_ssr_context(previous_context);
            }
          });
          promises.push(promise);
        }
        promise.catch(noop);
        this.promise = this.global.track(promise);
        return promises;
      }
      /**
      * @param {(renderer: Renderer) => MaybePromise<void>} fn
      */
      child_block(fn) {
        this.#out.push(BLOCK_OPEN);
        this.child(fn);
        this.#out.push(BLOCK_CLOSE);
      }
      /**
      * Create a child renderer. The child renderer inherits the state from the parent,
      * but has its own content.
      * @param {(renderer: Renderer) => MaybePromise<void>} fn
      */
      child(fn) {
        const child = new Renderer2(this.global, this);
        this.#out.push(child);
        const parent = ssr_context;
        set_ssr_context({
          ...ssr_context,
          p: parent,
          c: null,
          r: child
        });
        const result = fn(child);
        set_ssr_context(parent);
        if (result instanceof Promise) {
          result.catch(noop);
          result.finally(() => set_ssr_context(null)).catch(noop);
          if (child.global.mode === "sync") await_invalid();
          child.promise = child.global.track(result);
        }
        return child;
      }
      /**
      * Render children inside an error boundary. If the children throw and the API-level
      * `transformError` transform handles the error (doesn't re-throw), the `failed` snippet is
      * rendered instead. Otherwise the error propagates.
      *
      * @param {{ failed?: (renderer: Renderer, error: unknown, reset: () => void) => void }} props
      * @param {(renderer: Renderer) => MaybePromise<void>} children_fn
      */
      boundary(props, children_fn) {
        const child = new Renderer2(this.global, this);
        this.#out.push(child);
        const parent_context = ssr_context;
        if (props.failed) child.#boundary = {
          failed: props.failed,
          transformError: this.global.transformError,
          context: parent_context
        };
        set_ssr_context({
          ...ssr_context,
          p: parent_context,
          c: null,
          r: child
        });
        try {
          const result = children_fn(child);
          set_ssr_context(parent_context);
          if (result instanceof Promise) {
            if (child.global.mode === "sync") await_invalid();
            result.catch(noop);
            child.promise = child.global.track(result);
          }
        } catch (error2) {
          set_ssr_context(parent_context);
          const failed_snippet = props.failed;
          if (!failed_snippet) throw error2;
          const result = this.global.transformError(error2);
          child.#out.length = 0;
          child.#boundary = null;
          if (result instanceof Promise) {
            if (this.global.mode === "sync") await_invalid();
            child.promise = child.global.track(
              /** @type {Promise<unknown>} */
              result.then((transformed) => {
                set_ssr_context(parent_context);
                child.#out.push(Renderer2.#serialize_failed_boundary(transformed));
                failed_snippet(child, transformed, noop);
                child.#out.push(BLOCK_CLOSE);
              })
            );
            child.promise.catch(noop);
          } else {
            child.#out.push(Renderer2.#serialize_failed_boundary(result));
            failed_snippet(child, result, noop);
            child.#out.push(BLOCK_CLOSE);
          }
        }
      }
      /**
      * Create a component renderer. The component renderer inherits the state from the parent,
      * but has its own content. It is treated as an ordering boundary for ondestroy callbacks.
      * @param {(renderer: Renderer) => MaybePromise<void>} fn
      * @param {Function} [component_fn]
      * @returns {void}
      */
      component(fn, component_fn) {
        push(component_fn);
        this.child((renderer) => {
          renderer.#is_component_body = true;
          return fn(renderer);
        });
        pop();
      }
      /**
      * @param {Record<string, any>} attrs
      * @param {(renderer: Renderer) => void} fn
      * @param {string | undefined} [css_hash]
      * @param {Record<string, boolean> | undefined} [classes]
      * @param {Record<string, string> | undefined} [styles]
      * @param {number | undefined} [flags]
      * @param {boolean | undefined} [is_rich]
      * @returns {void}
      */
      select(attrs, fn, css_hash, classes, styles, flags2, is_rich) {
        const { value, defaultValue, ...select_attrs } = attrs;
        if (select_attrs.multiple === "") select_attrs.multiple = true;
        this.push(`<select${attributes(select_attrs, css_hash, classes, styles, flags2)}>`);
        this.child((renderer) => {
          renderer.local.select_value = value === void 0 ? defaultValue : value;
          renderer.local.multiple = !!select_attrs.multiple;
          fn(renderer);
        });
        this.push(`${is_rich ? "<!>" : ""}</select>`);
      }
      /**
      * @param {Record<string, any>} attrs
      * @param {string | number | boolean | ((renderer: Renderer) => void)} body
      * @param {string | undefined} [css_hash]
      * @param {Record<string, boolean> | undefined} [classes]
      * @param {Record<string, string> | undefined} [styles]
      * @param {number | undefined} [flags]
      * @param {boolean | undefined} [is_rich]
      */
      option(attrs, body, css_hash, classes, styles, flags2, is_rich) {
        this.#out.push(`<option${attributes(attrs, css_hash, classes, styles, flags2)}`);
        const close = (renderer, value, { head: head2, body: body2 }) => {
          if (has_own_property.call(attrs, "value")) value = attrs.value;
          var select_value = this.local.select_value;
          if (this.local.multiple && is_array(select_value) ? select_value.includes(value) : value === select_value) renderer.#out.push(' selected=""');
          renderer.#out.push(`>${body2}${is_rich ? "<!>" : ""}</option>`);
          if (head2) renderer.head((child) => child.push(head2));
        };
        if (typeof body === "function") this.child((renderer) => {
          const r = new Renderer2(this.global, this);
          body(r);
          if (this.global.mode === "async") return r.#collect_content_async().then((content) => {
            close(renderer, content.body.replaceAll("<!---->", ""), content);
          });
          else {
            const content = r.#collect_content();
            close(renderer, content.body.replaceAll("<!---->", ""), content);
          }
        });
        else close(this, body, { body: escape_html(body) });
      }
      /**
      * @param {(renderer: Renderer) => void} fn
      */
      title(fn) {
        const path = this.get_path();
        const close = (head2) => {
          this.global.set_title(head2, path);
        };
        this.child((renderer) => {
          const r = new Renderer2(renderer.global, renderer);
          fn(r);
          if (renderer.global.mode === "async") return r.#collect_content_async().then((content) => {
            close(content.head);
          });
          else {
            const content = r.#collect_content();
            close(content.head);
          }
        });
      }
      /**
      * @param {string | (() => Promise<string>)} content
      */
      push(content) {
        if (typeof content === "function") this.child(async (renderer) => renderer.push(await content()));
        else this.#out.push(content);
      }
      /**
      * @param {() => void} fn
      */
      on_destroy(fn) {
        (this.#on_destroy ??= []).push(fn);
      }
      /**
      * @returns {number[]}
      */
      get_path() {
        return this.#parent ? [...this.#parent.get_path(), this.#parent.#out.indexOf(this)] : [];
      }
      /**
      * @deprecated this is needed for legacy component bindings
      */
      copy() {
        const copy = new Renderer2(this.global, this.#parent);
        copy.type = this.type;
        copy.#out = this.#out.map((item) => item instanceof Renderer2 ? item.copy() : item);
        copy.promise = this.promise;
        return copy;
      }
      /**
      * @param {Renderer} other
      * @deprecated this is needed for legacy component bindings
      */
      subsume(other) {
        if (this.global.mode !== other.global.mode) throw new Error("invariant: A renderer cannot switch modes. If you're seeing this, there's a compiler bug. File an issue!");
        this.local = other.local;
        this.#out = other.#out.map((item, i) => {
          const current2 = this.#out[i];
          if (current2 instanceof Renderer2 && item instanceof Renderer2) {
            current2.subsume(item);
            return current2;
          }
          return item;
        });
        this.promise = other.promise;
        this.type = other.type;
      }
      get length() {
        return this.#out.length;
      }
      /**
      * Creates the hydration comment that marks the start of a failed boundary.
      * The error is JSON-serialized and embedded inside an HTML comment for the client
      * to parse during hydration. The JSON is escaped to prevent `-->` or `<!--` sequences
      * from breaking out of the comment (XSS). Uses unicode escapes which `JSON.parse()`
      * handles transparently.
      * @param {unknown} error
      * @returns {string}
      */
      static #serialize_failed_boundary(error2) {
        return `<!--[?${JSON.stringify(error2).replace(/>/g, "\\u003e").replace(/</g, "\\u003c")}-->`;
      }
      /**
      * Only available on the server and when compiling with the `server` option.
      * Takes a component and returns an object with `body` and `head` properties on it, which you can use to populate the HTML when server-rendering your app.
      * @template {Record<string, any>} Props
      * @param {Component<Props>} component
      * @param {{ props?: Omit<Props, '$$slots' | '$$events'>; context?: Map<any, any>; idPrefix?: string; csp?: Csp }} [options]
      * @returns {RenderOutput}
      */
      static render(component7, options2 = {}) {
        let sync;
        let async;
        const result = {};
        Object.defineProperties(result, {
          html: { get: () => {
            return (sync ??= Renderer2.#render(component7, options2)).body;
          } },
          head: { get: () => {
            return (sync ??= Renderer2.#render(component7, options2)).head;
          } },
          body: { get: () => {
            return (sync ??= Renderer2.#render(component7, options2)).body;
          } },
          hashes: { value: { script: "" } },
          then: { value: (
            /**
            * this is not type-safe, but honestly it's the best I can do right now, and it's a straightforward function.
            *
            * @template TResult1
            * @template [TResult2=never]
            * @param { (value: SyncRenderOutput) => TResult1 } onfulfilled
            * @param { (reason: unknown) => TResult2 } onrejected
            */
            (onfulfilled, onrejected) => {
              if (!async_mode_flag) {
                const result2 = sync ??= Renderer2.#render(component7, options2);
                const user_result = onfulfilled({
                  head: result2.head,
                  body: result2.body,
                  html: result2.body,
                  hashes: { script: [] }
                });
                return Promise.resolve(user_result);
              }
              async ??= init_render_context().then(() => with_render_context(() => Renderer2.#render_async(component7, options2)));
              return async.then((result2) => {
                Object.defineProperty(result2, "html", { get: () => {
                  html_deprecated();
                } });
                return onfulfilled(result2);
              }, onrejected);
            }
          ) }
        });
        return result;
      }
      /**
      * Collect all of the `onDestroy` callbacks registered during rendering. In an async context, this is only safe to call
      * after awaiting `collect_async`.
      *
      * Child renderers are "porous" and don't affect execution order, but component body renderers
      * create ordering boundaries. Within a renderer, callbacks run in order until hitting a component boundary.
      * @returns {Iterable<() => void>}
      */
      *#collect_on_destroy() {
        for (const component7 of this.#traverse_components()) yield* component7.#collect_ondestroy();
      }
      /**
      * Performs a depth-first search of renderers, yielding the deepest components first, then additional components as we backtrack up the tree.
      * @returns {Iterable<Renderer>}
      */
      *#traverse_components() {
        for (const child of this.#out) if (typeof child !== "string") yield* child.#traverse_components();
        if (this.#is_component_body) yield this;
      }
      /**
      * @returns {Iterable<() => void>}
      */
      *#collect_ondestroy() {
        if (this.#on_destroy) for (const fn of this.#on_destroy) yield fn;
        for (const child of this.#out) if (child instanceof Renderer2 && !child.#is_component_body) yield* child.#collect_ondestroy();
      }
      /**
      * Runs every `onDestroy` callback in this renderer tree. On a failed render,
      * cleanup errors are suppressed so they do not mask the render error.
      * @param {boolean} suppress_errors
      */
      #run_on_destroy(suppress_errors) {
        let first_error;
        let has_error = false;
        for (const cleanup of this.#collect_on_destroy()) try {
          cleanup();
        } catch (error2) {
          if (!suppress_errors && !has_error) {
            first_error = error2;
            has_error = true;
          }
        }
        if (has_error) throw first_error;
      }
      /**
      * @param {'sync' | 'async'} mode
      * @param {{ idPrefix?: string; csp?: Csp; transformError?: (error: unknown) => unknown }} options
      * @returns {Renderer}
      */
      static #create(mode, options2) {
        if (options2.idPrefix?.includes("--")) invalid_id_prefix();
        return new Renderer2(new SSRState(mode, options2.idPrefix ? options2.idPrefix + "-" : "", options2.csp, options2.transformError));
      }
      /**
      * Render a component. Throws if any of the children are performing asynchronous work.
      *
      * @template {Record<string, any>} Props
      * @param {Component<Props>} component
      * @param {{ props?: Omit<Props, '$$slots' | '$$events'>; context?: Map<any, any>; idPrefix?: string }} options
      * @returns {AccumulatedContent}
      */
      static #render(component7, options2) {
        var previous_context = ssr_context;
        const renderer = Renderer2.#create("sync", options2);
        let result;
        let render_error;
        let failed = false;
        try {
          try {
            Renderer2.#open_render(renderer, component7, options2);
            result = Renderer2.#close_render(renderer.#collect_content(), renderer);
          } catch (error2) {
            render_error = error2;
            failed = true;
          }
          renderer.#run_on_destroy(failed);
          if (failed) throw render_error;
          return result;
        } finally {
          renderer.global.abort();
          set_ssr_context(previous_context);
        }
      }
      /**
      * Render a component.
      *
      * @template {Record<string, any>} Props
      * @param {Component<Props>} component
      * @param {{ props?: Omit<Props, '$$slots' | '$$events'>; context?: Map<any, any>; idPrefix?: string; csp?: Csp }} options
      * @returns {Promise<AccumulatedContent & { hashes: { script: Sha256Source[] } }>}
      */
      static async #render_async(component7, options2) {
        const previous_context = ssr_context;
        const renderer = Renderer2.#create("async", options2);
        let result;
        let render_error;
        let failed = false;
        try {
          try {
            Renderer2.#open_render(renderer, component7, options2);
            const content = await renderer.#collect_content_async();
            const hydratables = await renderer.#collect_hydratables();
            if (hydratables !== null) content.head = hydratables + content.head;
            result = Renderer2.#close_render(content, renderer);
          } catch (error2) {
            render_error = error2;
            failed = true;
            renderer.global.abort();
            await renderer.global.settle();
          }
          renderer.#run_on_destroy(failed);
          if (failed) throw render_error;
          return result;
        } finally {
          set_ssr_context(previous_context);
          renderer.global.abort();
        }
      }
      /**
      * Collect all of the code from the `out` array and return it as a string, or a promise resolving to a string.
      * @param {AccumulatedContent} content
      * @returns {AccumulatedContent}
      */
      #collect_content(content = {
        head: "",
        body: ""
      }) {
        for (const item of this.#out) if (typeof item === "string") content[this.type] += item;
        else if (item instanceof Renderer2) item.#collect_content(content);
        return content;
      }
      /**
      * Collect all of the code from the `out` array and return it as a string.
      * @param {AccumulatedContent} content
      * @returns {Promise<AccumulatedContent>}
      */
      async #collect_content_async(content = {
        head: "",
        body: ""
      }) {
        await this.promise;
        for (const item of this.#out) if (typeof item === "string") content[this.type] += item;
        else if (item instanceof Renderer2) {
          if (item.#boundary) {
            const boundary_content = {
              head: "",
              body: ""
            };
            try {
              await item.#collect_content_async(boundary_content);
              content.head += boundary_content.head;
              content.body += boundary_content.body;
            } catch (error2) {
              const { context: context2, failed, transformError } = item.#boundary;
              set_ssr_context(context2);
              let promise = transformError(error2);
              set_ssr_context(null);
              let transformed = await promise;
              set_ssr_context(context2);
              const failed_renderer = new Renderer2(item.global, item);
              failed_renderer.type = item.type;
              failed_renderer.#out.push(Renderer2.#serialize_failed_boundary(transformed));
              failed(failed_renderer, transformed, noop);
              failed_renderer.#out.push(BLOCK_CLOSE);
              await failed_renderer.#collect_content_async(content);
            }
          } else await item.#collect_content_async(content);
        }
        return content;
      }
      async #collect_hydratables() {
        const ctx = get_render_context().hydratable;
        for (const [_, key2] of ctx.unresolved_promises) unresolved_hydratable(key2, ctx.lookup.get(key2)?.stack ?? "<missing stack trace>");
        for (const comparison of ctx.comparisons) await comparison;
        return await this.#hydratable_block(ctx);
      }
      /**
      * @template {Record<string, any>} Props
      * @param {Renderer} renderer
      * @param {import('svelte').Component<Props>} component
      * @param {{ props?: Omit<Props, '$$slots' | '$$events'>; context?: Map<any, any>; idPrefix?: string; csp?: Csp; transformError?: (error: unknown) => unknown }} options
      * @returns {void}
      */
      static #open_render(renderer, component7, options2) {
        var previous_context = ssr_context;
        try {
          set_ssr_context({
            p: null,
            c: options2.context ?? null,
            r: renderer
          });
          renderer.push(BLOCK_OPEN);
          component7(renderer, options2.props ?? {});
          renderer.push(BLOCK_CLOSE);
        } finally {
          set_ssr_context(previous_context);
        }
      }
      /**
      * @param {AccumulatedContent} content
      * @param {Renderer} renderer
      * @returns {AccumulatedContent & { hashes: { script: Sha256Source[] } }}
      */
      static #close_render(content, renderer) {
        let head2 = content.head + renderer.global.get_title();
        let body = content.body;
        for (const { hash: hash2, code } of renderer.global.css) head2 += `<style id="${hash2}">${code}</style>`;
        return {
          head: head2,
          body,
          hashes: { script: renderer.global.csp.script_hashes }
        };
      }
      /**
      * @param {HydratableContext} ctx
      */
      async #hydratable_block(ctx) {
        if (ctx.lookup.size === 0) return null;
        let entries = [];
        let has_promises = false;
        for (const [k, v] of ctx.lookup) {
          if (v.promises) {
            has_promises = true;
            for (const p of v.promises) await p;
          }
          entries.push(`[${devalue.uneval(k)},${v.serialized}]`);
        }
        let prelude = `const h = (window.__svelte ??= {}).h ??= new Map();`;
        if (has_promises) prelude = `const r = (v) => Promise.resolve(v);
				${prelude}`;
        const body = `
			{
				${prelude}

				for (const [k, v] of [
					${entries.join(",\n					")}
				]) {
					h.set(k, v);
				}
			}
		`;
        let csp_attr = "";
        if (this.global.csp.nonce) csp_attr = ` nonce="${this.global.csp.nonce}"`;
        else if (this.global.csp.hash) {
          const hash2 = await sha256(body);
          this.global.csp.script_hashes.push(`sha256-${hash2}`);
        }
        return `
		<script${csp_attr}>${body}</script>`;
      }
    };
    SSRState = class {
      /** @readonly @type {Csp & { script_hashes: Sha256Source[] }} */
      csp;
      /** @readonly @type {'sync' | 'async'} */
      mode;
      /** @readonly @type {() => string} */
      uid;
      /** @readonly @type {Set<{ hash: string; code: string }>} */
      css = /* @__PURE__ */ new Set();
      /** @type {Set<Promise<unknown>>} */
      #pending = /* @__PURE__ */ new Set();
      /** @type {AbortController | null} */
      #controller = null;
      #aborted = false;
      /**
      * `transformError` passed to `render`. Called when an error boundary catches an error.
      * Throws by default if unset in `render`.
      * @type {(error: unknown) => unknown}
      */
      transformError;
      /** @type {{ path: number[], value: string }} */
      #title = {
        path: [],
        value: ""
      };
      /**
      * @param {'sync' | 'async'} mode
      * @param {string} id_prefix
      * @param {Csp} csp
      * @param {((error: unknown) => unknown) | undefined} [transformError]
      */
      constructor(mode, id_prefix = "", csp = { hash: false }, transformError) {
        this.mode = mode;
        this.csp = {
          ...csp,
          script_hashes: []
        };
        this.transformError = transformError ?? ((error2) => {
          throw error2;
        });
        let uid2 = 1;
        this.uid = () => `${id_prefix}s${uid2++}`;
      }
      /**
      * @template T
      * @param {Promise<T>} promise
      * @returns {Promise<T>}
      */
      track(promise) {
        this.#pending.add(promise);
        promise.then(() => this.#pending.delete(promise), () => this.#pending.delete(promise));
        return promise;
      }
      async settle() {
        while (this.#pending.size > 0) await Promise.allSettled([...this.#pending]);
      }
      abort() {
        if (this.#aborted) return;
        this.#aborted = true;
        this.#controller?.abort(STALE_REACTION);
      }
      get_abort_signal() {
        const controller = this.#controller ??= new AbortController();
        if (this.#aborted) controller.abort(STALE_REACTION);
        return controller.signal;
      }
      get_title() {
        return this.#title.value;
      }
      /**
      * Performs a depth-first (lexicographic) comparison using the path. Rejects sets
      * from earlier than or equal to the current value.
      * @param {string} value
      * @param {number[]} path
      */
      set_title(value, path) {
        const current2 = this.#title.path;
        let i = 0;
        let l = Math.min(path.length, current2.length);
        while (i < l && path[i] === current2[i]) i += 1;
        if (path[i] === void 0) return;
        if (current2[i] === void 0 || path[i] > current2[i]) {
          this.#title.path = path;
          this.#title.value = value;
        }
      }
    };
    INVALID_ATTR_NAME_CHAR_REGEX = /[\s'">/=\u{FDD0}-\u{FDEF}\u{FFFE}\u{FFFF}\u{1FFFE}\u{1FFFF}\u{2FFFE}\u{2FFFF}\u{3FFFE}\u{3FFFF}\u{4FFFE}\u{4FFFF}\u{5FFFE}\u{5FFFF}\u{6FFFE}\u{6FFFF}\u{7FFFE}\u{7FFFF}\u{8FFFE}\u{8FFFF}\u{9FFFE}\u{9FFFF}\u{AFFFE}\u{AFFFF}\u{BFFFE}\u{BFFFF}\u{CFFFE}\u{CFFFF}\u{DFFFE}\u{DFFFF}\u{EFFFE}\u{EFFFF}\u{FFFFE}\u{FFFFF}\u{10FFFE}\u{10FFFF}]/u;
    index_server_exports = /* @__PURE__ */ __exportAll({
      afterUpdate: () => noop,
      beforeUpdate: () => noop,
      createContext: () => createContext,
      createEventDispatcher: () => createEventDispatcher,
      createRawSnippet: () => createRawSnippet,
      flushSync: () => noop,
      fork: () => fork,
      getAbortSignal: () => getAbortSignal,
      getAllContexts: () => getAllContexts,
      getContext: () => getContext,
      hasContext: () => hasContext,
      hydratable: () => hydratable,
      hydrate: () => hydrate,
      mount: () => mount,
      onDestroy: () => onDestroy,
      onMount: () => noop,
      setContext: () => setContext,
      settled: () => settled,
      tick: () => tick,
      unmount: () => unmount,
      untrack: () => run
    });
  }
});

// .netlify/server/chunks/shared.js
import { HttpError, SvelteKitError } from "@sveltejs/kit/internal";
import * as devalue2 from "devalue";
function noop2() {
}
function once2(fn) {
  let done = false;
  let result;
  return () => {
    if (done) return result;
    done = true;
    return result = fn();
  };
}
function get_relative_path(from, to) {
  const from_parts = from.split(/[/\\]/);
  const to_parts = to.split(/[/\\]/);
  from_parts.pop();
  while (from_parts[0] === to_parts[0]) {
    from_parts.shift();
    to_parts.shift();
  }
  let i = from_parts.length;
  while (i--) from_parts[i] = "..";
  return from_parts.concat(to_parts).join("/");
}
function base64_encode2(bytes) {
  if (globalThis.Buffer) return globalThis.Buffer.from(bytes).toString("base64");
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
function base64_decode(encoded) {
  if (globalThis.Buffer) {
    const buffer2 = globalThis.Buffer.from(encoded, "base64");
    return new Uint8Array(buffer2);
  }
  const binary = atob(encoded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}
function coalesce_to_error(err) {
  return err instanceof Error || err && err.name && err.message ? err : new Error(JSON.stringify(err));
}
function normalize_error(error2) {
  return error2;
}
function get_status(error2) {
  return error2 instanceof HttpError || error2 instanceof SvelteKitError ? error2.status : 500;
}
function get_message(error2) {
  return error2 instanceof SvelteKitError ? error2.text : "Internal Error";
}
function stringify3(data, transport) {
  const encoders = Object.fromEntries(Object.entries(transport).map(([k, v]) => [k, v.encode]));
  return devalue2.stringify(data, encoders);
}
function create_remote_arg_revivers(transport) {
  const remote_fns_revivers = {
    /** @type {(value: unknown) => unknown} */
    [remote_object]: (value) => value,
    /** @type {(value: unknown) => Map<unknown, unknown>} */
    [remote_map]: (value) => {
      if (!Array.isArray(value)) throw new Error("Invalid data for Map reviver");
      const map = /* @__PURE__ */ new Map();
      for (const item of value) {
        if (!Array.isArray(item) || item.length !== 2 || typeof item[0] !== "string" || typeof item[1] !== "string") throw new Error("Invalid data for Map reviver");
        const [key2, val] = item;
        map.set(parse3(key2), parse3(val));
      }
      return map;
    },
    /** @type {(value: unknown) => Set<unknown>} */
    [remote_set]: (value) => {
      if (!Array.isArray(value)) throw new Error("Invalid data for Set reviver");
      const set2 = /* @__PURE__ */ new Set();
      for (const item of value) {
        if (typeof item !== "string") throw new Error("Invalid data for Set reviver");
        set2.add(parse3(item));
      }
      return set2;
    },
    /** @type {(value: any) => File} */
    [remote_file]: (value) => {
      if (!value || typeof value !== "object" || typeof value.name !== "string" || typeof value.type !== "string" || typeof value.size !== "number" || typeof value.lastModified !== "number" || !(value.data instanceof ArrayBuffer)) throw new Error("Invalid data for File reviver");
      const { data, name, ...meta } = value;
      return new File([data], name, meta);
    }
  };
  const all_revivers = {
    ...Object.fromEntries(Object.entries(transport).map(([k, v]) => [k, v.decode])),
    ...remote_fns_revivers
  };
  const parse3 = (data) => devalue2.parse(data, all_revivers);
  return all_revivers;
}
function parse_remote_arg(string, transport) {
  if (!string) return void 0;
  const json_string = new TextDecoder().decode(base64_decode(string.replaceAll("-", "+").replaceAll("_", "/")));
  return devalue2.parse(json_string, create_remote_arg_revivers(transport));
}
function create_remote_key(id, payload2) {
  return id + "/" + payload2;
}
function split_remote_key(key2) {
  const i = key2.lastIndexOf("/");
  if (i === -1) throw new Error(`Invalid remote key: ${key2}`);
  return {
    id: key2.slice(0, i),
    payload: key2.slice(i + 1)
  };
}
var text_encoder2, INVALIDATED_PARAM, TRAILING_SLASH_PARAM, remote_object, remote_map, remote_set, remote_file, remote_arg_marker;
var init_shared = __esm({
  ".netlify/server/chunks/shared.js"() {
    "use strict";
    text_encoder2 = new TextEncoder();
    INVALIDATED_PARAM = "x-sveltekit-invalidated";
    TRAILING_SLASH_PARAM = "x-sveltekit-trailing-slash";
    remote_object = "__skrao";
    remote_map = "__skram";
    remote_set = "__skras";
    remote_file = "__skraf";
    remote_arg_marker = Symbol(remote_object);
  }
});

// .netlify/server/chunks/internal.js
function override(paths) {
  base = paths.base;
  assets = paths.assets;
}
function reset() {
  base = initial.base;
  assets = initial.assets;
}
var base, assets, app_dir, initial;
var init_internal = __esm({
  ".netlify/server/chunks/internal.js"() {
    "use strict";
    base = "";
    assets = base;
    app_dir = "_app";
    initial = {
      base,
      assets
    };
    initial.base;
  }
});

// .netlify/server/entries/hooks.server.js
var hooks_server_exports = {};
__export(hooks_server_exports, {
  handle: () => handle
});
import { redirect } from "@sveltejs/kit";
var legacyRedirects, handle;
var init_hooks_server = __esm({
  ".netlify/server/entries/hooks.server.js"() {
    "use strict";
    legacyRedirects = {
      "/casestudies/bill-reader-v3.html": "/work/bill-reader",
      "/casestudies/bill-reader-v3": "/work/bill-reader",
      "/casestudies/platform-delivery.html": "/work/platform-delivery",
      "/casestudies/platform-delivery": "/work/platform-delivery"
    };
    handle = async ({ event, resolve: resolve2 }) => {
      const destination = legacyRedirects[event.url.pathname];
      if (destination) redirect(301, destination);
      return resolve2(event);
    };
  }
});

// .netlify/server/chunks/internal2.js
function set_private_env(environment) {
}
function set_public_env(environment) {
  public_env = environment;
}
function set_read_implementation(fn) {
  read_implementation = fn;
}
function set_manifest(_) {
}
function handle_event_propagation(event) {
  var handler_element = this;
  var owner_document = handler_element.ownerDocument;
  var event_name = event.type;
  var path = event.composedPath?.() || [];
  var current_target = path[0] || event.target;
  last_propagated_event = event;
  if (!last_propagated_event_clear_scheduled) {
    last_propagated_event_clear_scheduled = true;
    setTimeout(() => {
      last_propagated_event_clear_scheduled = false;
      last_propagated_event = null;
    });
  }
  var path_idx = 0;
  var handled_at = last_propagated_event === event && event[event_symbol];
  if (handled_at) {
    var at_idx = path.indexOf(handled_at);
    if (at_idx !== -1 && (handler_element === document || handler_element === window)) {
      event[event_symbol] = handler_element;
      return;
    }
    var handler_idx = path.indexOf(handler_element);
    if (handler_idx === -1) return;
    if (at_idx <= handler_idx) path_idx = at_idx;
  }
  current_target = path[path_idx] || event.target;
  if (current_target === handler_element) return;
  define_property(event, "currentTarget", {
    configurable: true,
    get() {
      return current_target || owner_document;
    }
  });
  var previous_reaction = active_reaction;
  var previous_effect = active_effect;
  set_active_reaction(null);
  set_active_effect(null);
  try {
    var throw_error;
    var other_errors = [];
    while (current_target !== null) {
      if (current_target === handler_element) break;
      try {
        var delegated = current_target[event_symbol]?.[event_name];
        if (delegated != null && (!current_target.disabled || event.target === current_target)) delegated.call(current_target, event);
      } catch (error2) {
        if (throw_error) other_errors.push(error2);
        else throw_error = error2;
      }
      if (event.cancelBubble) break;
      path_idx++;
      current_target = path_idx < path.length ? path[path_idx] : null;
    }
    if (throw_error) {
      for (let error2 of other_errors) queueMicrotask(() => {
        throw error2;
      });
      throw throw_error;
    }
  } finally {
    event[event_symbol] = handler_element;
    delete event.currentTarget;
    set_active_reaction(previous_reaction);
    set_active_effect(previous_effect);
  }
}
function assign_nodes(start, end) {
  var effect = active_effect;
  if (effect.nodes === null) effect.nodes = {
    start,
    end,
    a: null,
    t: null
  };
}
function createSubscriber(start) {
  let subscribers = 0;
  let version = source(0);
  let stop;
  return () => {
    if (effect_tracking()) {
      get(version);
      render_effect(() => {
        if (subscribers === 0) stop = untrack(() => start(() => increment(version)));
        subscribers += 1;
        return () => {
          queue_micro_task(() => {
            subscribers -= 1;
            if (subscribers === 0) {
              stop?.();
              stop = void 0;
              increment(version);
            }
          });
        };
      });
    }
  };
}
function boundary(node, props, children, transform_error) {
  new Boundary(node, props, children, transform_error);
}
function mount2(component7, options2) {
  return _mount(component7, options2);
}
function hydrate2(component7, options2) {
  init_operations();
  options2.intro = options2.intro ?? false;
  const target = options2.target;
  const was_hydrating = hydrating;
  const previous_hydrate_node = hydrate_node;
  try {
    var anchor = /* @__PURE__ */ get_first_child(target);
    while (anchor && (anchor.nodeType !== 8 || anchor.data !== "[")) anchor = /* @__PURE__ */ get_next_sibling(anchor);
    if (!anchor) throw HYDRATION_ERROR;
    set_hydrating(true);
    set_hydrate_node(anchor);
    const instance = _mount(component7, {
      ...options2,
      anchor
    });
    set_hydrating(false);
    return instance;
  } catch (error2) {
    if (error2 instanceof Error && error2.message.split("\n").some((line) => line.startsWith("https://svelte.dev/e/"))) throw error2;
    if (error2 !== HYDRATION_ERROR) console.warn("Failed to hydrate: ", error2);
    if (options2.recover === false) hydration_failed();
    init_operations();
    clear_text_content(target);
    set_hydrating(false);
    return mount2(component7, options2);
  } finally {
    set_hydrating(was_hydrating);
    set_hydrate_node(previous_hydrate_node);
  }
}
function _mount(Component, { target, anchor, props = {}, events, context: context2, intro = true, transformError }) {
  init_operations();
  var component7 = void 0;
  var unmount3 = component_root(() => {
    var anchor_node = anchor ?? target.appendChild(create_text());
    boundary(anchor_node, { pending: () => {
    } }, (anchor_node2) => {
      push$1({});
      var ctx = component_context;
      if (context2) ctx.c = context2;
      if (events)
        props.$$events = events;
      if (hydrating) assign_nodes(anchor_node2, null);
      component7 = Component(anchor_node2, props) || mark_as_component();
      if (hydrating) {
        active_effect.nodes.end = hydrate_node;
        if (hydrate_node === null || hydrate_node.nodeType !== 8 || hydrate_node.data !== "]") {
          hydration_mismatch();
          throw HYDRATION_ERROR;
        }
      }
      pop$1();
    }, transformError);
    var registered_events = /* @__PURE__ */ new Set();
    var event_handle = (events2) => {
      for (var i = 0; i < events2.length; i++) {
        var event_name = events2[i];
        if (registered_events.has(event_name)) continue;
        registered_events.add(event_name);
        var passive = is_passive_event(event_name);
        for (const node of [target, document]) {
          var counts = listeners.get(node);
          if (counts === void 0) {
            counts = /* @__PURE__ */ new Map();
            listeners.set(node, counts);
          }
          var count = counts.get(event_name);
          if (count === void 0) {
            node.addEventListener(event_name, handle_event_propagation, { passive });
            counts.set(event_name, 1);
          } else counts.set(event_name, count + 1);
        }
      }
    };
    event_handle(array_from(all_registered_events));
    root_event_handles.add(event_handle);
    return () => {
      for (var event_name of registered_events) for (const node of [target, document]) {
        var counts = listeners.get(node);
        var count = counts.get(event_name);
        if (--count == 0) {
          node.removeEventListener(event_name, handle_event_propagation);
          counts.delete(event_name);
          if (counts.size === 0) listeners.delete(node);
        } else counts.set(event_name, count);
      }
      root_event_handles.delete(event_handle);
      if (anchor_node !== anchor) anchor_node.parentNode?.removeChild(anchor_node);
    };
  });
  mounted_components.set(component7, unmount3);
  return component7;
}
function unmount2(component7, options2) {
  const fn = mounted_components.get(component7);
  if (fn) {
    mounted_components.delete(component7);
    return fn(options2);
  }
  return Promise.resolve();
}
function asClassComponent$1(component7) {
  return class extends Svelte4Component {
    /** @param {any} options */
    constructor(options2) {
      super({
        component: component7,
        ...options2
      });
    }
  };
}
function asClassComponent(component7) {
  const component_constructor = asClassComponent$1(component7);
  const _render = (props, { context: context2, csp, transformError } = {}) => {
    const result = render(component7, {
      props,
      context: context2,
      csp,
      transformError
    });
    const munged = Object.defineProperties({}, {
      css: { value: {
        code: "",
        map: null
      } },
      head: { get: () => result.head },
      html: { get: () => result.body },
      then: {
        /**
        * this is not type-safe, but honestly it's the best I can do right now, and it's a straightforward function.
        *
        * @template TResult1
        * @template [TResult2=never]
        * @param { (value: LegacyRenderResult) => TResult1 } onfulfilled
        * @param { (reason: unknown) => TResult2 } onrejected
        */
        value: (onfulfilled, onrejected) => {
          if (!async_mode_flag) {
            const user_result = onfulfilled({
              css: munged.css,
              head: munged.head,
              html: munged.html
            });
            return Promise.resolve(user_result);
          }
          return result.then((result2) => {
            return onfulfilled({
              css: munged.css,
              head: result2.head,
              html: result2.body,
              hashes: result2.hashes
            });
          }, onrejected);
        }
      }
    });
    return munged;
  };
  component_constructor.render = _render;
  return component_constructor;
}
function Root($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { stores, page: page2, constructors, components = [], form, data_0 = null, data_1 = null } = $$props;
    setContext("__svelte__", stores);
    stores.page.set(page2);
    const Pyramid_1 = derived(() => constructors[1]);
    if (constructors[1]) {
      $$renderer2.push("<!--[0-->");
      const Pyramid_0 = constructors[0];
      if (Pyramid_0) {
        $$renderer2.push("<!--[-->");
        Pyramid_0($$renderer2, {
          data: data_0,
          form,
          params: page2.params,
          children: ($$renderer3) => {
            if (Pyramid_1()) {
              $$renderer3.push("<!--[-->");
              Pyramid_1()($$renderer3, {
                data: data_1,
                form,
                params: page2.params
              });
              $$renderer3.push("<!--]-->");
            } else {
              $$renderer3.push("<!--[!-->");
              $$renderer3.push("<!--]-->");
            }
          },
          $$slots: { default: true }
        });
        $$renderer2.push("<!--]-->");
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push("<!--]-->");
      }
    } else {
      $$renderer2.push("<!--[-1-->");
      const Pyramid_0 = constructors[0];
      if (Pyramid_0) {
        $$renderer2.push("<!--[-->");
        Pyramid_0($$renderer2, {
          data: data_0,
          form,
          params: page2.params
        });
        $$renderer2.push("<!--]-->");
      } else {
        $$renderer2.push("<!--[!-->");
        $$renderer2.push("<!--]-->");
      }
    }
    $$renderer2.push(`<!--]--> `);
    $$renderer2.push("<!--[-1-->");
    $$renderer2.push(`<!--]-->`);
  });
}
async function get_hooks() {
  let handle2;
  let handleFetch;
  let handleError;
  let handleValidationError;
  let init3;
  ({ handle: handle2, handleFetch, handleError, handleValidationError, init: init3 } = await Promise.resolve().then(() => (init_hooks_server(), hooks_server_exports)));
  let reroute;
  let transport;
  return {
    handle: handle2,
    handleFetch,
    handleError,
    handleValidationError,
    init: init3,
    reroute,
    transport
  };
}
var public_env, read_implementation, event_symbol, all_registered_events, root_event_handles, last_propagated_event, last_propagated_event_clear_scheduled, flags, Boundary, listeners, mounted_components, Svelte4Component, root_default, error_template_default, options;
var init_internal2 = __esm({
  ".netlify/server/chunks/internal2.js"() {
    "use strict";
    init_index_server();
    init_internal();
    public_env = {};
    read_implementation = null;
    event_symbol = /* @__PURE__ */ Symbol("events");
    all_registered_events = /* @__PURE__ */ new Set();
    root_event_handles = /* @__PURE__ */ new Set();
    last_propagated_event = null;
    last_propagated_event_clear_scheduled = false;
    globalThis?.window?.trustedTypes;
    flags = EFFECT_TRANSPARENT | EFFECT_PRESERVED;
    Boundary = class {
      /** @type {Boundary | null} */
      parent;
      is_pending = false;
      /**
      * API-level transformError transform function. Transforms errors before they reach the `failed` snippet.
      * Inherited from parent boundary, or defaults to identity.
      * @type {(error: unknown) => unknown}
      */
      transform_error;
      /** @type {TemplateNode} */
      #anchor;
      /** @type {TemplateNode | null} */
      #hydrate_open = hydrating ? hydrate_node : null;
      /** @type {BoundaryProps} */
      #props;
      /** @type {((anchor: Node) => void)} */
      #children;
      /** @type {Effect} */
      #effect;
      /** @type {Effect | null} */
      #main_effect = null;
      /** @type {Effect | null} */
      #pending_effect = null;
      /** @type {Effect | null} */
      #failed_effect = null;
      /** @type {DocumentFragment | null} */
      #offscreen_fragment = null;
      #local_pending_count = 0;
      #pending_count = 0;
      #pending_count_update_queued = false;
      /** @type {Set<Effect>} */
      #dirty_effects = /* @__PURE__ */ new Set();
      /** @type {Set<Effect>} */
      #maybe_dirty_effects = /* @__PURE__ */ new Set();
      /**
      * A source containing the number of pending async deriveds/expressions.
      * Only created if `$effect.pending()` is used inside the boundary,
      * otherwise updating the source results in needless `Batch.ensure()`
      * calls followed by no-op flushes
      * @type {Source<number> | null}
      */
      #effect_pending = null;
      #effect_pending_subscriber = createSubscriber(() => {
        this.#effect_pending = source(this.#local_pending_count);
        return () => {
          this.#effect_pending = null;
        };
      });
      /**
      * @param {TemplateNode} node
      * @param {BoundaryProps} props
      * @param {((anchor: Node) => void)} children
      * @param {((error: unknown) => unknown) | undefined} [transform_error]
      */
      constructor(node, props, children, transform_error) {
        this.#anchor = node;
        this.#props = props;
        this.#children = (anchor) => {
          var effect = active_effect;
          effect.b = this;
          effect.f |= 128;
          children(anchor);
        };
        this.parent = active_effect.b;
        this.transform_error = transform_error ?? this.parent?.transform_error ?? ((e) => e);
        this.#effect = block(() => {
          if (hydrating) {
            const comment = this.#hydrate_open;
            hydrate_next();
            const server_rendered_pending = comment.data === "[!";
            if (comment.data.startsWith("[?")) {
              const serialized_error = JSON.parse(comment.data.slice(2));
              this.#hydrate_failed_content(serialized_error);
            } else if (server_rendered_pending) this.#hydrate_pending_content();
            else this.#hydrate_resolved_content();
          } else this.#render();
        }, flags);
        if (hydrating) this.#anchor = hydrate_node;
      }
      #hydrate_resolved_content() {
        try {
          this.#main_effect = branch(() => this.#children(this.#anchor));
        } catch (error2) {
          this.error(error2);
        }
      }
      /**
      * @param {unknown} error The deserialized error from the server's hydration comment
      */
      #hydrate_failed_content(error2) {
        const failed = this.#props.failed;
        const { reset: reset2, invoke_onerror } = this.#create_reset(error2);
        queue_micro_task(invoke_onerror);
        if (!failed) return;
        this.#failed_effect = branch(() => {
          failed(this.#anchor, () => error2, () => reset2);
        });
      }
      /**
      * Creates the `reset` function for a failed boundary, along with a function
      * that invokes `onerror` with it (if provided)
      * @param {unknown} error
      * @returns {{ reset: () => void, invoke_onerror: () => void }}
      */
      #create_reset(error2) {
        var did_reset = false;
        var calling_on_error = false;
        const reset2 = () => {
          if (did_reset) {
            svelte_boundary_reset_noop();
            return;
          }
          did_reset = true;
          if (calling_on_error) svelte_boundary_reset_onerror();
          if (this.#failed_effect !== null) pause_effect(this.#failed_effect, () => {
            this.#failed_effect = null;
          });
          this.#run(() => {
            this.#render();
          });
        };
        const invoke_onerror = () => {
          try {
            calling_on_error = true;
            this.#props.onerror?.(error2, reset2);
            calling_on_error = false;
          } catch (err) {
            invoke_error_boundary(err, this.#effect && this.#effect.parent);
          }
        };
        return {
          reset: reset2,
          invoke_onerror
        };
      }
      #hydrate_pending_content() {
        const pending = this.#props.pending;
        if (!pending) return;
        this.is_pending = true;
        this.#pending_effect = branch(() => pending(this.#anchor));
        queue_micro_task(() => {
          var fragment = this.#offscreen_fragment = document.createDocumentFragment();
          var anchor = create_text();
          var handled = false;
          fragment.append(anchor);
          this.#main_effect = this.#run(() => {
            try {
              return branch(() => this.#children(anchor));
            } catch (error2) {
              try {
                this.error(error2);
                handled = true;
              } catch (error3) {
                invoke_error_boundary(error3, this.#effect.parent);
              }
              return null;
            }
          });
          if (this.#main_effect === null) {
            this.#offscreen_fragment = null;
            if (handled) this.#resolve(current_batch);
            return;
          }
          if (this.#pending_count === 0) {
            this.#anchor.before(fragment);
            this.#offscreen_fragment = null;
            pause_effect(this.#pending_effect, () => {
              this.#pending_effect = null;
            });
            this.#resolve(current_batch);
          }
        });
      }
      #render() {
        try {
          this.is_pending = this.has_pending_snippet();
          this.#pending_count = 0;
          this.#local_pending_count = 0;
          this.#main_effect = branch(() => {
            this.#children(this.#anchor);
          });
          if (this.#pending_count > 0) {
            var fragment = this.#offscreen_fragment = document.createDocumentFragment();
            move_effect(this.#main_effect, fragment);
            const pending = this.#props.pending;
            this.#pending_effect = branch(() => pending(this.#anchor));
          } else this.#resolve(current_batch);
        } catch (error2) {
          this.error(error2);
        }
      }
      /**
      * @param {Batch} batch
      */
      #resolve(batch) {
        this.is_pending = false;
        batch.transfer_effects(this.#dirty_effects, this.#maybe_dirty_effects);
      }
      /**
      * Defer an effect inside a pending boundary until the boundary resolves
      * @param {Effect} effect
      */
      defer_effect(effect) {
        defer_effect(effect, this.#dirty_effects, this.#maybe_dirty_effects);
      }
      /**
      * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
      * @returns {boolean}
      */
      is_rendered() {
        return !this.is_pending && (!this.parent || this.parent.is_rendered());
      }
      has_pending_snippet() {
        return !!this.#props.pending;
      }
      /**
      * @template T
      * @param {() => T} fn
      */
      #run(fn) {
        var previous_effect = active_effect;
        var previous_reaction = active_reaction;
        var previous_ctx = component_context;
        set_active_effect(this.#effect);
        set_active_reaction(this.#effect);
        set_component_context(this.#effect.ctx);
        try {
          Batch.ensure();
          return fn();
        } finally {
          set_active_effect(previous_effect);
          set_active_reaction(previous_reaction);
          set_component_context(previous_ctx);
        }
      }
      /**
      * Updates the pending count associated with the currently visible pending snippet,
      * if any, such that we can replace the snippet with content once work is done
      * @param {1 | -1} d
      * @param {Batch} batch
      */
      #update_pending_count(d, batch) {
        if (!this.has_pending_snippet()) {
          if (this.parent) this.parent.#update_pending_count(d, batch);
          return;
        }
        this.#pending_count += d;
        if (this.#pending_count === 0) {
          this.#resolve(batch);
          if (this.#pending_effect) pause_effect(this.#pending_effect, () => {
            this.#pending_effect = null;
          });
          if (this.#offscreen_fragment) {
            this.#anchor.before(this.#offscreen_fragment);
            this.#offscreen_fragment = null;
          }
        }
      }
      /**
      * Update the source that powers `$effect.pending()` inside this boundary,
      * and controls when the current `pending` snippet (if any) is removed.
      * Do not call from inside the class
      * @param {1 | -1} d
      * @param {Batch} batch
      */
      update_pending_count(d, batch) {
        this.#update_pending_count(d, batch);
        this.#local_pending_count += d;
        if (!this.#effect_pending || this.#pending_count_update_queued) return;
        this.#pending_count_update_queued = true;
        queue_micro_task(() => {
          this.#pending_count_update_queued = false;
          if (this.#effect_pending) internal_set(this.#effect_pending, this.#local_pending_count);
        });
      }
      get_effect_pending() {
        this.#effect_pending_subscriber();
        return get(this.#effect_pending);
      }
      /** @param {unknown} error */
      error(error2) {
        if (!this.#props.onerror && !this.#props.failed) throw error2;
        if (current_batch?.is_fork) {
          if (this.#main_effect) current_batch.skip_effect(this.#main_effect);
          if (this.#pending_effect) current_batch.skip_effect(this.#pending_effect);
          if (this.#failed_effect) current_batch.skip_effect(this.#failed_effect);
          current_batch.oncommit(() => {
            this.#handle_error(error2);
          });
        } else this.#handle_error(error2);
      }
      /**
      * @param {unknown} error
      */
      #handle_error(error2) {
        if (this.#main_effect) {
          destroy_effect(this.#main_effect);
          this.#main_effect = null;
        }
        if (this.#pending_effect) {
          destroy_effect(this.#pending_effect);
          this.#pending_effect = null;
        }
        if (this.#failed_effect) {
          destroy_effect(this.#failed_effect);
          this.#failed_effect = null;
        }
        if (hydrating) {
          set_hydrate_node(this.#hydrate_open);
          next();
          set_hydrate_node(skip_nodes());
        }
        let failed = this.#props.failed;
        const handle_error_result = (transformed_error) => {
          const { reset: reset2, invoke_onerror } = this.#create_reset(transformed_error);
          invoke_onerror();
          if (failed) this.#failed_effect = this.#run(() => {
            try {
              return branch(() => {
                var effect = active_effect;
                effect.b = this;
                effect.f |= 128;
                failed(this.#anchor, () => transformed_error, () => reset2);
              });
            } catch (error3) {
              invoke_error_boundary(error3, this.#effect.parent);
              return null;
            }
          });
        };
        queue_micro_task(() => {
          var result;
          try {
            result = this.transform_error(error2);
          } catch (e) {
            invoke_error_boundary(e, this.#effect && this.#effect.parent);
            return;
          }
          if (result !== null && typeof result === "object" && typeof result.then === "function")
            result.then(
              handle_error_result,
              /** @param {unknown} e */
              (e) => invoke_error_boundary(e, this.#effect && this.#effect.parent)
            );
          else handle_error_result(result);
        });
      }
    };
    listeners = /* @__PURE__ */ new Map();
    mounted_components = /* @__PURE__ */ new WeakMap();
    Svelte4Component = class {
      /** @type {any} */
      #events;
      /** @type {Record<string, any>} */
      #instance;
      /**
      * @param {ComponentConstructorOptions & {
      *  component: any;
      * }} options
      */
      constructor(options2) {
        var sources = /* @__PURE__ */ new Map();
        var add_source = (key2, value) => {
          var s2 = /* @__PURE__ */ mutable_source(value, false, false);
          sources.set(key2, s2);
          return s2;
        };
        const props = new Proxy({
          ...options2.props || {},
          $$events: {}
        }, {
          get(target, prop) {
            return get(sources.get(prop) ?? add_source(prop, Reflect.get(target, prop)));
          },
          has(target, prop) {
            if (prop === LEGACY_PROPS) return true;
            get(sources.get(prop) ?? add_source(prop, Reflect.get(target, prop)));
            return Reflect.has(target, prop);
          },
          set(target, prop, value) {
            set(sources.get(prop) ?? add_source(prop, value), value);
            return Reflect.set(target, prop, value);
          }
        });
        this.#instance = (options2.hydrate ? hydrate2 : mount2)(options2.component, {
          target: options2.target,
          anchor: options2.anchor,
          props,
          context: options2.context,
          intro: options2.intro ?? false,
          recover: options2.recover,
          transformError: options2.transformError
        });
        if (!async_mode_flag && (!options2?.props?.$$host || options2.sync === false)) flushSync();
        this.#events = props.$$events;
        for (const key2 of Object.keys(this.#instance)) {
          if (key2 === "$set" || key2 === "$destroy" || key2 === "$on") continue;
          define_property(this, key2, {
            get() {
              return this.#instance[key2];
            },
            /** @param {any} value */
            set(value) {
              this.#instance[key2] = value;
            },
            enumerable: true
          });
        }
        this.#instance.$set = (next2) => {
          Object.assign(props, next2);
        };
        this.#instance.$destroy = () => {
          unmount2(this.#instance);
        };
      }
      /** @param {Record<string, any>} props */
      $set(props) {
        this.#instance.$set(props);
      }
      /**
      * @param {string} event
      * @param {(...args: any[]) => any} callback
      * @returns {any}
      */
      $on(event, callback) {
        this.#events[event] = this.#events[event] || [];
        const cb = (...args) => callback.call(this, ...args);
        this.#events[event].push(cb);
        return () => {
          this.#events[event] = this.#events[event].filter(
            /** @param {any} fn */
            (fn) => fn !== cb
          );
        };
      }
      $destroy() {
        this.#instance.$destroy();
      }
    };
    root_default = asClassComponent(Root);
    error_template_default = ({ status, message }) => '<!doctype html>\n<html lang="en">\n	<head>\n		<meta charset="utf-8" />\n		<title>' + message + `</title>

		<style>
			body {
				--bg: white;
				--fg: #222;
				--divider: #ccc;
				background: var(--bg);
				color: var(--fg);
				font-family:
					system-ui,
					-apple-system,
					BlinkMacSystemFont,
					'Segoe UI',
					Roboto,
					Oxygen,
					Ubuntu,
					Cantarell,
					'Open Sans',
					'Helvetica Neue',
					sans-serif;
				display: flex;
				align-items: center;
				justify-content: center;
				height: 100vh;
				margin: 0;
			}

			.error {
				display: flex;
				align-items: center;
				max-width: 32rem;
				margin: 0 1rem;
			}

			.status {
				font-weight: 200;
				font-size: 3rem;
				line-height: 1;
				position: relative;
				top: -0.05rem;
			}

			.message {
				border-left: 1px solid var(--divider);
				padding: 0 0 0 1rem;
				margin: 0 0 0 1rem;
				min-height: 2.5rem;
				display: flex;
				align-items: center;
			}

			.message h1 {
				font-weight: 400;
				font-size: 1em;
				margin: 0;
			}

			@media (prefers-color-scheme: dark) {
				body {
					--bg: #222;
					--fg: #ddd;
					--divider: #666;
				}
			}
		</style>
	</head>
	<body>
		<div class="error">
			<span class="status">` + status + '</span>\n			<div class="message">\n				<h1>' + message + "</h1>\n			</div>\n		</div>\n	</body>\n</html>\n";
    options = {
      app_template_contains_nonce: false,
      async: false,
      csp: {
        "mode": "auto",
        "directives": {
          "upgrade-insecure-requests": false,
          "block-all-mixed-content": false
        },
        "reportOnly": {
          "upgrade-insecure-requests": false,
          "block-all-mixed-content": false
        }
      },
      csrf_check_origin: true,
      csrf_trusted_origins: [],
      embedded: false,
      env_public_prefix: "PUBLIC_",
      env_private_prefix: "",
      hash_routing: false,
      hooks: null,
      preload_strategy: "modulepreload",
      root: root_default,
      service_worker: false,
      service_worker_options: void 0,
      server_error_boundaries: false,
      templates: {
        app: ({ head: head2, body, assets: assets2, nonce, env }) => '<!doctype html>\n<html lang="en">\n	<head>\n		<meta charset="utf-8" />\n		<link rel="icon" href="' + assets2 + '/favicon.ico" sizes="any" />\n		<link rel="apple-touch-icon" href="' + assets2 + `/favicon.png" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="theme-color" content="#f3f5f7" media="(prefers-color-scheme: light)" />
		<meta name="theme-color" content="#111419" media="(prefers-color-scheme: dark)" />
		<script>
			(function () {
				const stored = localStorage.getItem('theme');
				const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
				const dark = stored === 'dark' || (!stored && systemDark);
				document.documentElement.dataset.theme = dark ? 'dark' : 'light';
				document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
			})();
		</script>
		` + head2 + '\n	</head>\n	<body data-sveltekit-preload-data="hover">\n		<div style="display: contents">' + body + "</div>\n	</body>\n</html>\n",
        error: error_template_default
      },
      version_hash: "1gfwnlg"
    };
  }
});

// .netlify/server/chunks/exports.js
function resolve(base2, path) {
  if (path[0] === "/" && path[1] === "/") return path;
  let url = new URL(base2, internal);
  url = new URL(path, url);
  return url.protocol === internal.protocol ? url.pathname + url.search + url.hash : url.href;
}
function normalize_path(path, trailing_slash) {
  if (path === "/" || trailing_slash === "ignore") return path;
  if (trailing_slash === "never") return path.endsWith("/") ? path.slice(0, -1) : path;
  else if (trailing_slash === "always" && !path.endsWith("/")) return path + "/";
  return path;
}
function decode_pathname(pathname) {
  return pathname.split("%25").map(decodeURI).join("%25");
}
function decode_params(params) {
  for (const key2 in params) params[key2] = decodeURIComponent(params[key2]);
  return params;
}
function make_trackable(url, callback, search_params_callback, allow_hash = false) {
  const tracked = new URL(url);
  Object.defineProperty(tracked, "searchParams", {
    value: new Proxy(tracked.searchParams, { get(obj, key2) {
      if (key2 === "get" || key2 === "getAll" || key2 === "has") return (param, ...rest) => {
        search_params_callback(param);
        return obj[key2](param, ...rest);
      };
      callback();
      const value = Reflect.get(obj, key2);
      return typeof value === "function" ? value.bind(obj) : value;
    } }),
    enumerable: true,
    configurable: true
  });
  const tracked_url_properties = [
    "href",
    "pathname",
    "search",
    "toString",
    "toJSON"
  ];
  if (allow_hash) tracked_url_properties.push("hash");
  for (const property of tracked_url_properties) Object.defineProperty(tracked, property, {
    get() {
      callback();
      return url[property];
    },
    enumerable: true,
    configurable: true
  });
  tracked[/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")] = (_depth, opts, inspect) => {
    return inspect(url, opts);
  };
  tracked.searchParams[/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")] = (_depth, opts, inspect) => {
    return inspect(url.searchParams, opts);
  };
  if (!allow_hash) disable_hash(tracked);
  return tracked;
}
function disable_hash(url) {
  allow_nodejs_console_log(url);
  Object.defineProperty(url, "hash", { get() {
    throw new Error("Cannot access event.url.hash. Consider using `page.url.hash` inside a component instead");
  } });
}
function disable_search(url) {
  allow_nodejs_console_log(url);
  for (const property of ["search", "searchParams"]) Object.defineProperty(url, property, { get() {
    throw new Error(`Cannot access url.${property} on a page with prerendering enabled`);
  } });
}
function allow_nodejs_console_log(url) {
  url[/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")] = (_depth, opts, inspect) => {
    return inspect(new URL(url), opts);
  };
}
function hash(...values) {
  let hash2 = 5381;
  for (const value of values) if (typeof value === "string") {
    let i = value.length;
    while (i) hash2 = hash2 * 33 ^ value.charCodeAt(--i);
  } else if (ArrayBuffer.isView(value)) {
    const buffer2 = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    let i = buffer2.length;
    while (i) hash2 = hash2 * 33 ^ buffer2[--i];
  } else throw new TypeError("value must be a string or TypedArray");
  return (hash2 >>> 0).toString(36);
}
function exec(match, params, matchers) {
  const result = {};
  const values = match.slice(1);
  const values_needing_match = values.filter((value) => value !== void 0);
  let buffered = 0;
  for (let i = 0; i < params.length; i += 1) {
    const param = params[i];
    let value = values[i - buffered];
    if (param.chained && param.rest && buffered) {
      value = values.slice(i - buffered, i + 1).filter((s2) => s2).join("/");
      buffered = 0;
    }
    if (value === void 0) {
      if (param.rest) value = "";
      else continue;
    }
    if (!param.matcher || matchers[param.matcher](value)) {
      result[param.name] = value;
      const next_param = params[i + 1];
      const next_value = values[i + 1];
      if (next_param && !next_param.rest && next_param.optional && next_value && param.chained) buffered = 0;
      if (!next_param && !next_value && Object.keys(result).length === values_needing_match.length) buffered = 0;
      continue;
    }
    if (param.optional && param.chained) {
      buffered++;
      continue;
    }
    return;
  }
  if (buffered) return;
  return result;
}
function find_route(path, routes, matchers) {
  for (const route of routes) {
    const match = route.pattern.exec(path);
    if (!match) continue;
    const matched = exec(match, route.params, matchers);
    if (matched) return {
      route,
      params: decode_params(matched)
    };
  }
  return null;
}
function validator(expected) {
  function validate(module, file) {
    if (!module) return;
    for (const key2 in module) {
      if (key2[0] === "_" || expected.has(key2)) continue;
      const values = [...expected.values()];
      const hint = hint_for_supported_files(key2, file?.slice(file.lastIndexOf("."))) ?? `valid exports are ${values.join(", ")}, or anything with a '_' prefix`;
      throw new Error(`Invalid export '${key2}'${file ? ` in ${file}` : ""} (${hint})`);
    }
  }
  return validate;
}
function hint_for_supported_files(key2, ext = ".js") {
  const supported_files = [];
  if (valid_layout_exports.has(key2)) supported_files.push(`+layout${ext}`);
  if (valid_page_exports.has(key2)) supported_files.push(`+page${ext}`);
  if (valid_layout_server_exports.has(key2)) supported_files.push(`+layout.server${ext}`);
  if (valid_page_server_exports.has(key2)) supported_files.push(`+page.server${ext}`);
  if (valid_server_exports.has(key2)) supported_files.push(`+server${ext}`);
  if (supported_files.length > 0) return `'${key2}' is a valid export in ${supported_files.slice(0, -1).join(", ")}${supported_files.length > 1 ? " or " : ""}${supported_files.at(-1)}`;
}
var internal, valid_layout_exports, valid_page_exports, valid_layout_server_exports, valid_page_server_exports, valid_server_exports, validate_layout_exports, validate_page_exports, validate_layout_server_exports, validate_page_server_exports, validate_server_exports;
var init_exports = __esm({
  ".netlify/server/chunks/exports.js"() {
    "use strict";
    init_index_server();
    internal = new URL("sveltekit-internal://");
    valid_layout_exports = /* @__PURE__ */ new Set([
      "load",
      "prerender",
      "csr",
      "ssr",
      "trailingSlash",
      "config"
    ]);
    valid_page_exports = /* @__PURE__ */ new Set([...valid_layout_exports, "entries"]);
    valid_layout_server_exports = /* @__PURE__ */ new Set([...valid_layout_exports]);
    valid_page_server_exports = /* @__PURE__ */ new Set([
      ...valid_layout_server_exports,
      "actions",
      "entries"
    ]);
    valid_server_exports = /* @__PURE__ */ new Set([
      "GET",
      "POST",
      "PATCH",
      "PUT",
      "DELETE",
      "OPTIONS",
      "HEAD",
      "fallback",
      "prerender",
      "trailingSlash",
      "config",
      "entries"
    ]);
    validate_layout_exports = validator(valid_layout_exports);
    validate_page_exports = validator(valid_page_exports);
    validate_layout_server_exports = validator(valid_layout_server_exports);
    validate_page_server_exports = validator(valid_page_server_exports);
    validate_server_exports = validator(valid_server_exports);
  }
});

// .netlify/server/chunks/analytics.js
import "@plausible-analytics/tracker";
var init_analytics = __esm({
  ".netlify/server/chunks/analytics.js"() {
    "use strict";
  }
});

// .netlify/server/entries/pages/_layout.svelte.js
var layout_svelte_exports = {};
__export(layout_svelte_exports, {
  default: () => _layout
});
function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<a class="skip-link" href="#main-content">Skip to main content</a> <!--[-->`);
    slot($$renderer2, $$props, "default", {}, null);
    $$renderer2.push(`<!--]-->`);
  });
}
var init_layout_svelte = __esm({
  ".netlify/server/entries/pages/_layout.svelte.js"() {
    "use strict";
    init_index_server();
    init_analytics();
  }
});

// .netlify/server/nodes/0.js
var __exports = {};
__export(__exports, {
  component: () => component,
  fonts: () => fonts,
  imports: () => imports,
  index: () => index,
  stylesheets: () => stylesheets
});
var index, component_cache, component, imports, stylesheets, fonts;
var init__ = __esm({
  ".netlify/server/nodes/0.js"() {
    "use strict";
    index = 0;
    component = async () => component_cache ??= (await Promise.resolve().then(() => (init_layout_svelte(), layout_svelte_exports))).default;
    imports = ["_app/immutable/nodes/0.Bsa22k9W.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/chunks/xihTtKlq.js", "_app/immutable/chunks/BxQp6cwM.js"];
    stylesheets = ["_app/immutable/assets/0.DOTC5692.css"];
    fonts = ["_app/immutable/assets/manrope-cyrillic-wght-normal.Dvxsihut.woff2", "_app/immutable/assets/manrope-greek-wght-normal.DL7QRZyv.woff2", "_app/immutable/assets/manrope-vietnamese-wght-normal.usUDDRr7.woff2", "_app/immutable/assets/manrope-latin-ext-wght-normal.Ch3YOpNY.woff2", "_app/immutable/assets/manrope-latin-wght-normal.DHIcAJRg.woff2", "_app/immutable/assets/ibm-plex-mono-cyrillic-ext-400-normal.xuaO2J-f.woff2", "_app/immutable/assets/ibm-plex-mono-cyrillic-ext-400-normal.DMdlQ8Kv.woff", "_app/immutable/assets/ibm-plex-mono-cyrillic-400-normal.BSMlKf0J.woff2", "_app/immutable/assets/ibm-plex-mono-cyrillic-400-normal.CEL4l2ZJ.woff", "_app/immutable/assets/ibm-plex-mono-vietnamese-400-normal.BulugwFq.woff2", "_app/immutable/assets/ibm-plex-mono-vietnamese-400-normal.DDuiU_S-.woff", "_app/immutable/assets/ibm-plex-mono-latin-ext-400-normal.BmRBH3aV.woff2", "_app/immutable/assets/ibm-plex-mono-latin-ext-400-normal.D3D2R8hC.woff", "_app/immutable/assets/ibm-plex-mono-latin-400-normal.DMJ8VG8y.woff2", "_app/immutable/assets/ibm-plex-mono-latin-400-normal.CvHOgSBP.woff", "_app/immutable/assets/ibm-plex-mono-cyrillic-ext-500-normal.BqneJy0T.woff2", "_app/immutable/assets/ibm-plex-mono-cyrillic-ext-500-normal.BIfNGwUT.woff", "_app/immutable/assets/ibm-plex-mono-cyrillic-500-normal.Bq9vWWag.woff2", "_app/immutable/assets/ibm-plex-mono-cyrillic-500-normal.Ael50iVv.woff", "_app/immutable/assets/ibm-plex-mono-vietnamese-500-normal.DZ4AoWbu.woff2", "_app/immutable/assets/ibm-plex-mono-vietnamese-500-normal.C8zxqsMH.woff", "_app/immutable/assets/ibm-plex-mono-latin-ext-500-normal.CAhNIIs5.woff2", "_app/immutable/assets/ibm-plex-mono-latin-ext-500-normal.CZ70TYgx.woff", "_app/immutable/assets/ibm-plex-mono-latin-500-normal.DSY6xOcd.woff2", "_app/immutable/assets/ibm-plex-mono-latin-500-normal.CB9ihrfo.woff"];
  }
});

// .netlify/server/chunks/Footer.js
function ThemeToggle($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<button class="theme-toggle svelte-1cmi4dh" type="button"${attr("aria-label", `Switch to Dark theme`)}><span>${escape_html("Dark")}</span></button>`);
  });
}
function getCaseStudy(slug) {
  const study = caseStudies.find((item) => item.slug === slug);
  if (!study) throw new Error(`Unknown case study: ${slug}`);
  return study;
}
function Header($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let home = fallback($$props["home"], false);
    let menuOpen = false;
    const links = [
      {
        label: "Work",
        href: home ? "#work" : "/#work"
      },
      {
        label: "Approach",
        href: home ? "#approach" : "/#approach"
      },
      {
        label: "Experience",
        href: home ? "#experience" : "/#experience"
      },
      {
        label: "About",
        href: home ? "#about" : "/#about"
      }
    ];
    $$renderer2.push(`<header class="site-header svelte-1elxaub"><div class="header-inner svelte-1elxaub"><a class="wordmark svelte-1elxaub" href="/" aria-label="Abhishek Kumar home"><span class="mark svelte-1elxaub" aria-hidden="true">AK</span> <span>Abhishek Kumar</span></a> <button class="menu-button svelte-1elxaub" type="button"${attr("aria-expanded", menuOpen)} aria-controls="site-navigation">${escape_html("Menu")}</button> <nav id="site-navigation" aria-label="Primary navigation"${attr_class("svelte-1elxaub", void 0, { "open": menuOpen })}><!--[-->`);
    const each_array = ensure_array_like(links);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let link = each_array[$$index];
      $$renderer2.push(`<a${attr("href", link.href)} class="svelte-1elxaub">${escape_html(link.label)}</a>`);
    }
    $$renderer2.push(`<!--]--> <a class="header-cta svelte-1elxaub"${attr("href", externalLinks.email.href)}>Start a conversation</a> `);
    ThemeToggle($$renderer2, {});
    $$renderer2.push(`<!----></nav></div></header>`);
    bind_props($$props, { home });
  });
}
function Footer($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<footer class="svelte-jz8lnl"><div class="page-shell footer-inner svelte-jz8lnl"><div class="svelte-jz8lnl"><strong class="svelte-jz8lnl">Abhishek Kumar</strong> <span class="svelte-jz8lnl">Product Manager in Dublin</span></div> <nav aria-label="Footer navigation" class="svelte-jz8lnl"><a${attr("href", externalLinks.linkedin.href)} target="_blank" rel="noreferrer" class="svelte-jz8lnl">LinkedIn</a> <a${attr("href", externalLinks.resume.href)} target="_blank" rel="noreferrer" class="svelte-jz8lnl">Resume</a> <a href="#main-content" class="svelte-jz8lnl">Back to top</a></nav></div></footer>`);
  });
}
var externalLinks, visaJobsPublicMetrics, caseStudies, homeMetrics, experience, credentials;
var init_Footer = __esm({
  ".netlify/server/chunks/Footer.js"() {
    "use strict";
    init_index_server();
    init_analytics();
    externalLinks = {
      email: {
        label: "Start a conversation",
        href: "mailto:abhishzk.ie@gmail.com?subject=Product conversation",
        event: "contact_click"
      },
      linkedin: {
        label: "LinkedIn",
        href: "https://www.linkedin.com/in/abhishzk/",
        event: "linkedin_click"
      },
      resume: {
        label: "Resume",
        href: "/abhishek-kumar-resume.pdf",
        event: "resume_download"
      },
      visaJobsCandidate: {
        label: "Visit candidate product",
        href: "https://www.visajobs.ie/",
        event: "product_visit"
      },
      visaJobsEmployer: {
        label: "Visit employer product",
        href: "https://employers.visajobs.ie/",
        event: "product_visit"
      }
    };
    visaJobsPublicMetrics = [
      {
        value: "3,500+",
        label: "candidates",
        verifiedAt: "September 2026",
        sourceNote: "Founder-confirmed public product figure"
      },
      {
        value: "204,612",
        label: "permit records",
        verifiedAt: "September 2026",
        sourceNote: "VisaJobs public product data"
      },
      {
        value: "22,800+",
        label: "employers",
        verifiedAt: "September 2026",
        sourceNote: "VisaJobs public product data"
      },
      {
        value: "4,400+",
        label: "live jobs",
        verifiedAt: "September 2026",
        sourceNote: "VisaJobs public product data"
      },
      {
        value: "142",
        label: "nationalities",
        verifiedAt: "September 2026",
        sourceNote: "VisaJobs public product data"
      },
      {
        value: "51,000+",
        label: "launch-post views",
        sourceNote: "Founder-confirmed launch distribution figure"
      },
      {
        value: "1,400+",
        label: "launch-post click-throughs",
        sourceNote: "Founder-confirmed launch distribution figure"
      }
    ];
    caseStudies = [
      {
        slug: "visajobs",
        shortTitle: "VisaJobs Ireland",
        title: "Making visa sponsorship searchable in Ireland",
        description: "A 0-to-1 product that turns fragmented government permit records and live jobs into practical decisions for candidates and employers.",
        role: "Founder and Product Manager",
        period: "2026 to present",
        domains: [
          "0-to-1 product",
          "Data product",
          "Two-sided marketplace"
        ],
        image: "/images/casestudies/visajobs-product.webp",
        imageAlt: "VisaJobs Ireland search experience showing sponsor-backed job discovery",
        imageWidth: 1440,
        imageHeight: 1100,
        imageSrcset: "/images/casestudies/visajobs-product-720.webp 720w, /images/casestudies/visajobs-product-1200.webp 1200w, /images/casestudies/visajobs-product.webp 1440w",
        decision: "Use official permit history as the trust layer, then connect it to live jobs and decision tools.",
        result: "3,500+ candidates and a new verified employer product.",
        metrics: visaJobsPublicMetrics.slice(0, 4)
      },
      {
        slug: "bill-reader",
        shortTitle: "Bill Reader",
        title: "Rebuilding an energy bill pipeline people could trust",
        description: "A production AI workflow that separated extraction from validation and sent uncertain results to focused human review.",
        role: "Product Owner",
        period: "July to December 2025",
        domains: [
          "AI product",
          "Energy SaaS",
          "Human review"
        ],
        image: "/images/casestudies/bill-reader-system.svg",
        imageAlt: "Bill Reader workflow from upload through extraction, validation, review, and storage",
        imageWidth: 1600,
        imageHeight: 900,
        decision: "Use AWS Textract for extraction, OpenAI for structured validation, and human review below the confidence threshold.",
        result: "95% PDF accuracy and 80% less processing time.",
        metrics: [
          {
            value: "95%",
            label: "PDF accuracy"
          },
          {
            value: "80%",
            label: "image accuracy"
          },
          {
            value: "80%",
            label: "less processing time"
          }
        ]
      },
      {
        slug: "platform-delivery",
        shortTitle: "Watt Footprint Platform",
        title: "Turning passive pilots into active energy management",
        description: "A platform redesign and delivery system that moved enterprise customers toward deeper operational use across web and mobile.",
        role: "Product Owner",
        period: "July to December 2025",
        domains: [
          "B2B SaaS",
          "Analytics",
          "Platform adoption"
        ],
        image: "/images/casestudies/wfp-evidence-map.svg",
        imageAlt: "Watt Footprint product evidence map connecting customer behavior, roadmap decisions, and outcomes",
        imageWidth: 1600,
        imageHeight: 900,
        decision: "Prioritize adoption and stability together, using Amplitude evidence and structured release gates to guide delivery.",
        result: "84% session growth with 100% logo retention.",
        metrics: [{
          value: "84%",
          label: "session growth"
        }, {
          value: "100%",
          label: "logo retention"
        }]
      }
    ];
    homeMetrics = [
      {
        value: "3,500+",
        label: "VisaJobs candidates"
      },
      {
        value: "84%",
        label: "platform session growth"
      },
      {
        value: "95%",
        label: "PDF bill accuracy"
      },
      {
        value: "28+",
        label: "AI product integrations"
      }
    ];
    experience = [
      {
        company: "VisaJobs Ireland",
        role: "Founder and Product Manager",
        period: "January 2026 to present",
        location: "Dublin, Ireland",
        summary: "Building a data product that helps international candidates and Irish employers make visa-sponsorship decisions with evidence.",
        outcomes: [
          "Grew the candidate product to 3,500+ candidates.",
          "Expanded into verified employer claiming and job posting.",
          "Turned official permit data into search, comparison, scoring, and planning tools."
        ]
      },
      {
        company: "Watt Footprint",
        role: "Product Owner",
        period: "July 2025 to December 2025",
        location: "Dublin, Ireland",
        summary: "Owned product delivery for an enterprise energy platform across billing, analytics, onboarding, and international expansion.",
        outcomes: [
          "Increased external sessions by 84% through instrumented product iteration.",
          "Shipped bill automation at 95% PDF accuracy.",
          "Coordinated a nine-person internal and external delivery group."
        ]
      },
      {
        company: "Speeir",
        role: "Product Manager",
        period: "September 2024 to June 2025",
        location: "Athlone, Ireland",
        summary: "Led two early-stage products from concept to production across AI search and multi-tenant fitness management.",
        outcomes: [
          "Integrated 28+ external services into an AI search product.",
          "Delivered a multi-tenant fitness platform across web and mobile.",
          "Owned product strategy, prioritization, pricing, and delivery in a lean team."
        ]
      },
      {
        company: "Mastercard",
        role: "Software Engineer, Payments Network",
        period: "June 2022 to January 2023",
        location: "Dublin, Ireland",
        summary: "Built event-driven payment systems and developed the technical depth I now use to make better product trade-offs.",
        outcomes: [
          "Supported production-like testing for 300+ merchants.",
          "Raised automated test coverage to 97%.",
          "Worked in a regulated environment with strict PCI and PII controls."
        ]
      }
    ];
    credentials = [
      {
        name: "Professional Scrum Product Owner I",
        institution: "Scrum.org",
        detail: "93.8% score, March 2026"
      },
      {
        name: "MEng Engineering Management",
        institution: "Technological University of the Shannon",
        detail: "First Class Honours, 2024"
      },
      {
        name: "BEng Software Engineering",
        institution: "Technological University of the Shannon",
        detail: "Honours degree, 2021"
      }
    ];
  }
});

// .netlify/server/entries/pages/_error.svelte.js
var error_svelte_exports = {};
__export(error_svelte_exports, {
  default: () => _error
});
import "@sveltejs/kit/internal";
import "@sveltejs/kit/internal/server";
function _error($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    head("1j96wlh", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>${escape_html(store_get($$store_subs ??= {}, "$page", page).status)} | Abhishek Kumar</title>`);
      });
      $$renderer3.push(`<meta name="robots" content="noindex"/>`);
    });
    Header($$renderer2, {});
    $$renderer2.push(`<!----> <main id="main-content" class="error-page page-shell svelte-1j96wlh"><p class="mono svelte-1j96wlh">${escape_html(store_get($$store_subs ??= {}, "$page", page).status)}</p> <h1 class="svelte-1j96wlh">This page is not available.</h1> <p class="svelte-1j96wlh">${escape_html(store_get($$store_subs ??= {}, "$page", page).error?.message || "The link may have changed or the page may no longer exist.")}</p> <a class="button button-primary" href="/">Return home</a></main> `);
    Footer($$renderer2, {});
    $$renderer2.push(`<!---->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
var PRELOAD_PRIORITIES, updated_listener, updated2, is_legacy, placeholder_url, onMount, tick2, getStores, page;
var init_error_svelte = __esm({
  ".netlify/server/entries/pages/_error.svelte.js"() {
    "use strict";
    init_index_server();
    init_shared();
    init_internal();
    init_internal2();
    init_exports();
    init_Footer();
    PRELOAD_PRIORITIES = {
      tap: 1,
      hover: 2,
      viewport: 3,
      eager: 4,
      off: -1,
      false: -1
    };
    ({ ...PRELOAD_PRIORITIES }, PRELOAD_PRIORITIES.hover);
    updated_listener = { v: noop2 };
    is_legacy = noop.toString().includes("$$") || /function \w+\(\) \{\}/.test(noop.toString());
    placeholder_url = "a:";
    if (is_legacy) {
      new URL(placeholder_url);
      updated2 = { current: false };
    } else {
      new class Page {
        data = {};
        form = null;
        error = null;
        params = {};
        route = { id: null };
        state = {};
        status = -1;
        url = new URL(placeholder_url);
      }();
      new class Navigating {
        current = null;
      }();
      updated2 = new class Updated {
        current = false;
      }();
      updated_listener.v = () => updated2.current = true;
    }
    ({ onMount, tick: tick2 } = index_server_exports);
    getStores = () => {
      const stores$1 = getContext("__svelte__");
      return {
        /** @type {typeof page} */
        page: { subscribe: stores$1.page.subscribe },
        /** @type {typeof navigating} */
        navigating: { subscribe: stores$1.navigating.subscribe },
        /** @type {typeof updated} */
        updated: stores$1.updated
      };
    };
    page = { subscribe(fn) {
      return getStores().page.subscribe(fn);
    } };
  }
});

// .netlify/server/nodes/1.js
var __exports2 = {};
__export(__exports2, {
  component: () => component2,
  fonts: () => fonts2,
  imports: () => imports2,
  index: () => index2,
  stylesheets: () => stylesheets2
});
var index2, component_cache2, component2, imports2, stylesheets2, fonts2;
var init__2 = __esm({
  ".netlify/server/nodes/1.js"() {
    "use strict";
    index2 = 1;
    component2 = async () => component_cache2 ??= (await Promise.resolve().then(() => (init_error_svelte(), error_svelte_exports))).default;
    imports2 = ["_app/immutable/nodes/1.CpvyOuyi.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/chunks/DXtUsCh-.js", "_app/immutable/chunks/xihTtKlq.js", "_app/immutable/chunks/BxQp6cwM.js", "_app/immutable/chunks/LyT3dOoU.js"];
    stylesheets2 = ["_app/immutable/assets/Footer.BnU4mJEO.css", "_app/immutable/assets/1.D5RVi9BF.css"];
    fonts2 = [];
  }
});

// .netlify/server/chunks/Contact.js
function Metrics($$renderer, $$props) {
  let metrics = $$props["metrics"];
  let compact2 = fallback($$props["compact"], false);
  $$renderer.push(`<div${attr_class("metrics svelte-11zw4ht", void 0, { "compact": compact2 })} aria-label="Key outcomes"><!--[-->`);
  const each_array = ensure_array_like(metrics);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let metric = each_array[$$index];
    $$renderer.push(`<div class="metric svelte-11zw4ht"><strong class="mono svelte-11zw4ht">${escape_html(metric.value)}</strong> <span class="svelte-11zw4ht">${escape_html(metric.label)}</span> `);
    if (metric.verifiedAt) $$renderer.push(`<!--[0--><small class="svelte-11zw4ht">Verified ${escape_html(metric.verifiedAt)}</small>`);
    else $$renderer.push("<!--[-1-->");
    $$renderer.push(`<!--]--></div>`);
  }
  $$renderer.push(`<!--]--></div>`);
  bind_props($$props, {
    metrics,
    compact: compact2
  });
}
function Contact($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<section id="contact" class="contact-section svelte-wt4tt0"><div class="page-shell contact-grid svelte-wt4tt0"><div><span class="eyebrow">Open to Product Manager roles</span> <h2 class="svelte-wt4tt0">Have a product problem worth solving?</h2></div> <div class="contact-copy svelte-wt4tt0"><p class="svelte-wt4tt0">I am based in Dublin and interested in Product Manager opportunities across Ireland and the
				EU.</p> <div class="contact-actions svelte-wt4tt0"><a class="button button-primary"${attr("href", externalLinks.email.href)}>Start a conversation</a> <button class="button button-secondary" type="button"><span aria-live="polite">${escape_html("Copy email")}</span></button></div></div></div></section>`);
  });
}
var init_Contact = __esm({
  ".netlify/server/chunks/Contact.js"() {
    "use strict";
    init_index_server();
    init_analytics();
    init_Footer();
  }
});

// .netlify/server/entries/pages/_page.svelte.js
var page_svelte_exports = {};
__export(page_svelte_exports, {
  default: () => _page
});
function Hero($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<section class="hero svelte-1q37ri0"><div class="page-shell hero-grid svelte-1q37ri0"><div class="hero-copy svelte-1q37ri0"><span class="eyebrow">Open to Product Manager roles</span> <h1 class="svelte-1q37ri0"><span class="svelte-1q37ri0">Product Manager</span> <span class="svelte-1q37ri0">building useful, data-rich products.</span></h1> <p class="svelte-1q37ri0">I lead 0-to-1 and enterprise SaaS products across AI, energy and fintech, from discovery
				through adoption.</p> <div class="hero-actions svelte-1q37ri0"><a class="button button-primary"${attr("href", externalLinks.email.href)}>Start a conversation</a> <a class="button button-secondary" href="#work">View product work</a></div></div> <div class="portrait-wrap svelte-1q37ri0"><div class="portrait-frame svelte-1q37ri0"><img src="/images/headshot.webp" srcset="/images/headshot-480.webp 480w, /images/headshot-800.webp 800w, /images/headshot.webp 1024w" sizes="(max-width: 900px) 88vw, 32vw" alt="Illustrated portrait of Abhishek Kumar" width="1024" height="1024" loading="eager" fetchpriority="high" class="svelte-1q37ri0"/></div> <div class="portrait-note svelte-1q37ri0"><span class="mono svelte-1q37ri0">Dublin, Ireland</span> <span>AI, B2B SaaS, data, energy, fintech</span></div></div></div></section>`);
  });
}
function WorkGrid($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    $$renderer2.push(`<section id="work" class="section work-section svelte-j4tx33"><div class="page-shell"><div class="section-heading"><span class="eyebrow">Selected product work</span> <h2>Decisions, trade-offs, and outcomes.</h2> <p>Three products that show how I find the real constraint, align teams, and measure what
				changes after launch.</p></div> <div class="work-list svelte-j4tx33"><!--[-->`);
    const each_array = ensure_array_like(caseStudies);
    for (let index7 = 0, $$length = each_array.length; index7 < $$length; index7++) {
      let study = each_array[index7];
      $$renderer2.push(`<article${attr_class("work-item reveal svelte-j4tx33", void 0, { "featured": index7 === 0 })}><a class="work-media svelte-j4tx33"${attr("href", `/work/${stringify(study.slug)}`)}><img${attr("src", study.image)}${attr("srcset", study.imageSrcset)}${attr("sizes", index7 === 0 ? "(max-width: 900px) 100vw, 58vw" : "(max-width: 900px) 100vw, 50vw")}${attr("alt", study.imageAlt)}${attr("width", study.imageWidth)}${attr("height", study.imageHeight)} loading="lazy" decoding="async" class="svelte-j4tx33"/></a> <div class="work-copy svelte-j4tx33"><div class="work-meta svelte-j4tx33"><span>${escape_html(study.role)}</span> <span>${escape_html(study.period)}</span></div> <h3 class="svelte-j4tx33"><a${attr("href", `/work/${stringify(study.slug)}`)} class="svelte-j4tx33">${escape_html(study.title)}</a></h3> <p class="description svelte-j4tx33">${escape_html(study.description)}</p> <div class="evidence-pair svelte-j4tx33"><div><span class="evidence-label svelte-j4tx33">Product decision</span> <p class="svelte-j4tx33">${escape_html(study.decision)}</p></div> <div><span class="evidence-label svelte-j4tx33">Outcome</span> <p class="svelte-j4tx33">${escape_html(study.result)}</p></div></div> <a class="text-link"${attr("href", `/work/${stringify(study.slug)}`)}>Read case study <span aria-hidden="true">\u2192</span></a></div></article>`);
    }
    $$renderer2.push(`<!--]--></div></div></section>`);
  });
}
function Approach($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const steps = [
      {
        title: "Discover the real constraint",
        body: "Start with observed friction, production evidence, and the people closest to the problem.",
        proof: "VisaJobs started with a repeated job-search failure, not a feature idea.",
        href: "/work/visajobs"
      },
      {
        title: "Prioritize measurable value",
        body: "Define the user and business change before deciding what belongs in the roadmap.",
        proof: "Bill Reader success was defined through accuracy, time saved, and trusted financial fields.",
        href: "/work/bill-reader"
      },
      {
        title: "Align product and engineering",
        body: "Translate customer needs into clear decisions, acceptance criteria, and technical trade-offs.",
        proof: "Extraction, validation, and human review were separated by what each method did best.",
        href: "/work/bill-reader"
      },
      {
        title: "Instrument adoption",
        body: "Measure whether customers are moving beyond access into meaningful product behavior.",
        proof: "Amplitude evidence shifted Watt Footprint priorities toward depth of enterprise use.",
        href: "/work/platform-delivery"
      },
      {
        title: "Iterate from production evidence",
        body: "Treat real failure modes, support signals, and adoption patterns as inputs to the next release.",
        proof: "VisaJobs expanded into an employer product after inbound demand exposed the second side.",
        href: "/work/visajobs"
      }
    ];
    $$renderer2.push(`<section id="approach" class="section"><div class="page-shell approach-grid svelte-34wvco"><div class="approach-intro svelte-34wvco"><h2 class="svelte-34wvco">How I work when the path is unclear.</h2> <p class="svelte-34wvco">Product management is a decision system. I use evidence to narrow ambiguity, make the
				trade-off visible, and give teams a clear reason to build.</p></div> <div class="approach-list svelte-34wvco"><!--[-->`);
    const each_array = ensure_array_like(steps);
    for (let index7 = 0, $$length = each_array.length; index7 < $$length; index7++) {
      let step = each_array[index7];
      $$renderer2.push(`<article class="approach-item reveal svelte-34wvco"><div><h3 class="svelte-34wvco">${escape_html(step.title)}</h3> <p class="svelte-34wvco">${escape_html(step.body)}</p> <a${attr("href", step.href)} class="svelte-34wvco">${escape_html(step.proof)} <span aria-hidden="true">\u2192</span></a></div></article>`);
    }
    $$renderer2.push(`<!--]--></div></div></section>`);
  });
}
function ExperienceTimeline($$renderer) {
  $$renderer.push(`<section id="experience" class="section experience-section svelte-2a0qkh"><div class="page-shell"><div class="section-heading"><h2>Experience built across products and systems.</h2> <p>My product work spans 0-to-1 discovery, enterprise adoption, AI workflows, and regulated
				payment infrastructure.</p></div> <div class="timeline svelte-2a0qkh"><!--[-->`);
  const each_array = ensure_array_like(experience);
  for (let index7 = 0, $$length = each_array.length; index7 < $$length; index7++) {
    let item = each_array[index7];
    $$renderer.push(`<article class="timeline-item reveal svelte-2a0qkh"><div class="timeline-meta svelte-2a0qkh"><span class="mono svelte-2a0qkh">${escape_html(item.period)}</span> <span>${escape_html(item.location)}</span></div> <div class="timeline-copy svelte-2a0qkh"><p class="company svelte-2a0qkh">${escape_html(item.company)}</p> <h3 class="svelte-2a0qkh">${escape_html(item.role)}</h3> <p class="summary svelte-2a0qkh">${escape_html(item.summary)}</p> <ul class="svelte-2a0qkh"><!--[-->`);
    const each_array_1 = ensure_array_like(item.outcomes);
    for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
      let outcome = each_array_1[$$index];
      $$renderer.push(`<li class="svelte-2a0qkh">${escape_html(outcome)}</li>`);
    }
    $$renderer.push(`<!--]--></ul></div></article>`);
  }
  $$renderer.push(`<!--]--></div></div></section>`);
}
function About($$renderer) {
  $$renderer.push(`<section id="about" class="section"><div class="page-shell about-grid svelte-7hpc9t"><div class="about-copy reveal svelte-7hpc9t"><span class="eyebrow">About</span> <h2 class="svelte-7hpc9t">Technical enough to challenge the solution. Product-minded enough to challenge the problem.</h2> <p class="svelte-7hpc9t">I started in software engineering and moved into product because I was most interested in
				why a system should exist, who it should serve, and how we would know it worked.</p> <p class="svelte-7hpc9t">That foundation helps me work closely with engineers without turning technical complexity
				into the product strategy. I connect architecture, customer behavior, and commercial goals
				into decisions a team can act on.</p></div> <div class="credentials reveal svelte-7hpc9t"><!--[-->`);
  const each_array = ensure_array_like(credentials);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let credential = each_array[$$index];
    $$renderer.push(`<article class="svelte-7hpc9t"><h3 class="svelte-7hpc9t">${escape_html(credential.name)}</h3> <p class="svelte-7hpc9t">${escape_html(credential.institution)}</p> <span class="mono svelte-7hpc9t">${escape_html(credential.detail)}</span></article>`);
  }
  $$renderer.push(`<!--]--></div></div></section>`);
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const description = "Product Manager in Dublin building data-rich products across AI, B2B SaaS, energy and fintech.";
    const structuredDataHtml = `<script type="application/ld+json">${JSON.stringify({
      "@context": "https://schema.org",
      "@graph": [{
        "@type": "Person",
        name: "Abhishek Kumar",
        url: "https://abhishzk.com",
        image: "https://abhishzk.com/images/headshot.webp",
        jobTitle: "Product Manager",
        homeLocation: {
          "@type": "Place",
          name: "Dublin, Ireland"
        },
        sameAs: ["https://www.linkedin.com/in/abhishzk/", "https://www.visajobs.ie/"],
        knowsAbout: [
          "Product Management",
          "B2B SaaS",
          "AI Products",
          "Energy Technology",
          "Fintech"
        ]
      }, {
        "@type": "WebSite",
        name: "Abhishek Kumar Product Portfolio",
        url: "https://abhishzk.com",
        description
      }]
    }).replace(/</g, "\\u003c")}</script>`;
    head("1uha8ag", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Abhishek Kumar | Product Manager</title>`);
      });
      $$renderer3.push(`<meta name="description"${attr("content", description)}/> <link rel="canonical" href="https://abhishzk.com/"/> <meta property="og:type" content="website"/> <meta property="og:title" content="Abhishek Kumar | Product Manager"/> <meta property="og:description"${attr("content", description)}/> <meta property="og:url" content="https://abhishzk.com/"/> <meta property="og:image" content="https://abhishzk.com/images/social/home.png"/> <meta property="og:image:width" content="1200"/> <meta property="og:image:height" content="630"/> <meta property="og:image:alt" content="Abhishek Kumar, Product Manager in Dublin"/> <meta name="twitter:card" content="summary_large_image"/> <meta name="twitter:title" content="Abhishek Kumar | Product Manager"/> <meta name="twitter:description"${attr("content", description)}/> <meta name="twitter:image" content="https://abhishzk.com/images/social/home.png"/> <meta name="twitter:image:alt" content="Abhishek Kumar, Product Manager in Dublin"/> ${html(structuredDataHtml)}`);
    });
    Header($$renderer2, { home: true });
    $$renderer2.push(`<!----> <main id="main-content">`);
    Hero($$renderer2, {});
    $$renderer2.push(`<!----> <section class="outcomes section-tight svelte-1uha8ag" aria-label="Selected outcomes"><div class="page-shell">`);
    Metrics($$renderer2, { metrics: homeMetrics });
    $$renderer2.push(`<!----></div></section> `);
    WorkGrid($$renderer2, {});
    $$renderer2.push(`<!----> `);
    Approach($$renderer2, {});
    $$renderer2.push(`<!----> `);
    ExperienceTimeline($$renderer2, {});
    $$renderer2.push(`<!----> `);
    About($$renderer2, {});
    $$renderer2.push(`<!----> `);
    Contact($$renderer2, {});
    $$renderer2.push(`<!----></main> `);
    Footer($$renderer2, {});
    $$renderer2.push(`<!---->`);
  });
}
var init_page_svelte = __esm({
  ".netlify/server/entries/pages/_page.svelte.js"() {
    "use strict";
    init_index_server();
    init_analytics();
    init_Footer();
    init_Contact();
  }
});

// .netlify/server/nodes/2.js
var __exports3 = {};
__export(__exports3, {
  component: () => component3,
  fonts: () => fonts3,
  imports: () => imports3,
  index: () => index3,
  stylesheets: () => stylesheets3
});
var index3, component_cache3, component3, imports3, stylesheets3, fonts3;
var init__3 = __esm({
  ".netlify/server/nodes/2.js"() {
    "use strict";
    index3 = 2;
    component3 = async () => component_cache3 ??= (await Promise.resolve().then(() => (init_page_svelte(), page_svelte_exports))).default;
    imports3 = ["_app/immutable/nodes/2.zOu-Kt1n.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/chunks/xihTtKlq.js", "_app/immutable/chunks/BxQp6cwM.js", "_app/immutable/chunks/LyT3dOoU.js", "_app/immutable/chunks/B8_E3Gts.js"];
    stylesheets3 = ["_app/immutable/assets/Footer.BnU4mJEO.css", "_app/immutable/assets/Contact.BlBHjYPW.css", "_app/immutable/assets/2.aqI28ORy.css"];
    fonts3 = [];
  }
});

// .netlify/server/chunks/CaseStudyNav.js
function CaseStudyHero($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let study = $$props["study"];
    $$renderer2.push(`<header class="case-hero svelte-16sasvy"><div class="page-shell"><a class="back-link svelte-16sasvy" href="/#work"><span aria-hidden="true">\u2190</span> Selected work</a> <div class="case-title-grid svelte-16sasvy"><div><p class="case-domains mono svelte-16sasvy">${escape_html(study.domains.join(" / "))}</p> <h1 class="svelte-16sasvy">${escape_html(study.title)}</h1></div> <div class="case-intro svelte-16sasvy"><p class="svelte-16sasvy">${escape_html(study.description)}</p> <dl class="svelte-16sasvy"><div><dt class="svelte-16sasvy">Role</dt> <dd class="svelte-16sasvy">${escape_html(study.role)}</dd></div> <div><dt class="svelte-16sasvy">Period</dt> <dd class="svelte-16sasvy">${escape_html(study.period)}</dd></div></dl></div></div> <div class="case-image svelte-16sasvy"><img${attr("src", study.image)}${attr("srcset", study.imageSrcset)} sizes="(max-width: 1240px) 100vw, 1200px"${attr("alt", study.imageAlt)}${attr("width", study.imageWidth)}${attr("height", study.imageHeight)} loading="eager" fetchpriority="high" class="svelte-16sasvy"/></div> `);
    Metrics($$renderer2, {
      metrics: study.metrics,
      compact: true
    });
    $$renderer2.push(`<!----></div></header>`);
    bind_props($$props, { study });
  });
}
function CaseStudySection($$renderer, $$props) {
  let title = $$props["title"];
  let tone = fallback($$props["tone"], "default");
  $$renderer.push(`<section${attr_class("case-section svelte-1sdugm1", void 0, { "soft": tone === "soft" })}><div class="case-section-inner page-shell svelte-1sdugm1"><div class="case-heading svelte-1sdugm1"><h2 class="svelte-1sdugm1">${escape_html(title)}</h2></div> <div class="case-body svelte-1sdugm1"><!--[-->`);
  slot($$renderer, $$props, "default", {}, null);
  $$renderer.push(`<!--]--></div></div></section>`);
  bind_props($$props, {
    title,
    tone
  });
}
function DecisionBlock($$renderer, $$props) {
  let title = $$props["title"];
  $$renderer.push(`<aside class="decision-block svelte-1h8kplc"><span class="mono svelte-1h8kplc">Product decision</span> <h3 class="svelte-1h8kplc">${escape_html(title)}</h3> <!--[-->`);
  slot($$renderer, $$props, "default", {}, null);
  $$renderer.push(`<!--]--></aside>`);
  bind_props($$props, { title });
}
function CaseStudyNav($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let index7, next2;
    let current2 = $$props["current"];
    $: index7 = caseStudies.findIndex((study) => study.slug === current2);
    $: next2 = caseStudies[(index7 + 1) % caseStudies.length];
    $$renderer2.push(`<section class="next-work svelte-15lxnyf"><div class="page-shell next-grid svelte-15lxnyf"><div><span class="mono svelte-15lxnyf">Next case study</span> <h2 class="svelte-15lxnyf">${escape_html(next2.title)}</h2></div> <a class="button button-primary"${attr("href", `/work/${stringify(next2.slug)}`)}>Read next case study</a></div></section>`);
    bind_props($$props, { current: current2 });
  });
}
var init_CaseStudyNav = __esm({
  ".netlify/server/chunks/CaseStudyNav.js"() {
    "use strict";
    init_index_server();
    init_analytics();
    init_Footer();
    init_Contact();
  }
});

// .netlify/server/entries/pages/work/bill-reader/_page.svelte.js
var page_svelte_exports2 = {};
__export(page_svelte_exports2, {
  default: () => _page2
});
function _page2($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const study = getCaseStudy("bill-reader");
    const description = "How Abhishek Kumar rebuilt an unreliable energy bill workflow using AWS Textract extraction, OpenAI validation, and focused human review.";
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "CreativeWork",
      name: study.title,
      description,
      url: "https://abhishzk.com/work/bill-reader",
      image: `https://abhishzk.com${study.image}`,
      author: {
        "@type": "Person",
        name: "Abhishek Kumar",
        url: "https://abhishzk.com"
      },
      dateModified: "2026-09-01",
      about: [
        "Product Management",
        "AI Product",
        "Energy Billing",
        "Human Review"
      ]
    };
    const structuredDataHtml = `<script type="application/ld+json">${JSON.stringify(structuredData).replace(/</g, "\\u003c")}</script>`;
    head("qpxry2", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Bill Reader Product Case Study | Abhishek Kumar</title>`);
      });
      $$renderer3.push(`<meta name="description"${attr("content", description)}/> <link rel="canonical" href="https://abhishzk.com/work/bill-reader"/> <meta property="og:type" content="article"/> <meta property="og:title"${attr("content", `${stringify(study.title)} | Product Case Study`)}/> <meta property="og:description"${attr("content", description)}/> <meta property="og:url" content="https://abhishzk.com/work/bill-reader"/> <meta property="og:image" content="https://abhishzk.com/images/social/bill-reader.png"/> <meta property="og:image:width" content="1200"/> <meta property="og:image:height" content="630"/> <meta property="og:image:alt" content="Bill Reader product case study by Abhishek Kumar"/> <meta name="twitter:card" content="summary_large_image"/> <meta name="twitter:title"${attr("content", `${stringify(study.title)} | Product Case Study`)}/> <meta name="twitter:description"${attr("content", description)}/> <meta name="twitter:image" content="https://abhishzk.com/images/social/bill-reader.png"/> <meta name="twitter:image:alt" content="Bill Reader product case study by Abhishek Kumar"/> ${html(structuredDataHtml)}`);
    });
    Header($$renderer2, {});
    $$renderer2.push(`<!----> <main id="main-content">`);
    CaseStudyHero($$renderer2, { study });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "The system extracted data quickly, but nobody trusted it.",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>When I joined Watt Footprint, energy bills were processed through a direct model call and
			written into the platform. Spot checks exposed recurring errors in account numbers, unit
			rates, standing charges, VAT, and totals.</p> <p>The immediate cost was manual validation. Ten bills could take 60 to 90 minutes to read,
			cross-check, calculate, and correct. The larger cost was product trust. Incorrect financial
			data could slow onboarding and undermine the dashboard before customers saw its value.</p> `);
        DecisionBlock($$renderer3, {
          title: "Define success around trusted fields, not successful model responses.",
          children: ($$renderer4) => {
            $$renderer4.push(`<p>The product needed field-level accuracy, logical consistency, controlled human review, and a
				clear route for failures. A completed extraction was not a successful outcome.</p>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!---->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "The input was inconsistent by design.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>The platform supported electricity, gas, and water bills across Ireland, the UK, and the UAE.
			Inputs ranged from clean digital PDFs to scanned images with skew, blur, missing fields, and
			provider-specific layouts.</p> <div class="constraint-grid svelte-qpxry2"><article class="svelte-qpxry2"><strong class="svelte-qpxry2">Document quality</strong><span class="svelte-qpxry2">Digital PDFs, scans, photos, blur, and rotation</span></article> <article class="svelte-qpxry2"><strong class="svelte-qpxry2">Billing logic</strong><span class="svelte-qpxry2">Day and night tariffs, levies, VAT, and standing charges</span></article> <article class="svelte-qpxry2"><strong class="svelte-qpxry2">Regional formats</strong><span class="svelte-qpxry2">EUR, GBP, AED, and different supplier conventions</span></article> <article class="svelte-qpxry2"><strong class="svelte-qpxry2">Business risk</strong><span class="svelte-qpxry2">Incorrect financial fields damage customer confidence</span></article></div> <p>I worked with operations, engineering, and data to make the technical trade-offs
			understandable. That included explaining why OCR accuracy and financial correctness were
			related but different product measures.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Three releases clarified what each technology should do.",
      children: ($$renderer3) => {
        $$renderer3.push(`<div class="version-list svelte-qpxry2"><article class="svelte-qpxry2"><span class="mono svelte-qpxry2">First release</span> <h3 class="svelte-qpxry2">Direct model extraction</h3> <p class="svelte-qpxry2">Fast to build, but values could be invented or misread without a dependable error check.</p></article> <article class="svelte-qpxry2"><span class="mono svelte-qpxry2">Second release</span> <h3 class="svelte-qpxry2">AWS Textract extraction</h3> <p class="svelte-qpxry2">Improved printed-text recognition, but brittle parsing still failed on financial edge
					cases.</p></article> <article class="svelte-qpxry2"><span class="mono svelte-qpxry2">Third release</span> <h3 class="svelte-qpxry2">Extraction plus structured validation</h3> <p class="svelte-qpxry2">Textract extracted the document. OpenAI checked structured output and financial
					consistency.</p></article></div> `);
        DecisionBlock($$renderer3, {
          title: "Use the model as a validator, not the source of truth.",
          children: ($$renderer4) => {
            $$renderer4.push(`<p>AWS Textract handled document extraction. OpenAI validated structured fields and
				relationships. Any bill below the 75% confidence threshold moved to human review instead of
				the database.</p>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> <div class="pipeline svelte-qpxry2" aria-label="Bill Reader processing flow"><span>Upload</span><b aria-hidden="true" class="svelte-qpxry2">\u2192</b><span>Extract</span><b aria-hidden="true" class="svelte-qpxry2">\u2192</b><span>Structure</span><b aria-hidden="true" class="svelte-qpxry2">\u2192</b><span>Validate</span><b aria-hidden="true" class="svelte-qpxry2">\u2192</b><span>Review or save</span></div>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Accuracy needed a repeatable evaluation method.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>Before committing to the extraction approach, the team tested a deliberate mix of clean PDFs,
			scanned documents, blurry images, and difficult layouts. We compared extracted fields against
			manually verified ground truth.</p> <div class="score-grid svelte-qpxry2"><article class="svelte-qpxry2"><strong class="mono svelte-qpxry2">1.0</strong><span class="svelte-qpxry2">Exact field match</span></article> <article class="svelte-qpxry2"><strong class="mono svelte-qpxry2">0.5</strong><span class="svelte-qpxry2">Correct value with a minor format difference</span></article> <article class="svelte-qpxry2"><strong class="mono svelte-qpxry2">0.0</strong><span class="svelte-qpxry2">Incorrect or missing value</span></article></div> <p>For financial fields, we also compared extracted totals with verified totals across each test
			batch. This caught small errors that could compound across an enterprise account.</p> <h3>My responsibility</h3> <ul><li>Defined accuracy and processing-time success criteria.</li> <li>Translated billing rules into requirements and acceptance criteria.</li> <li>Prioritized failure modes from production evidence.</li> <li>Aligned operations and engineering on the human-review threshold.</li> <li>Coordinated rollout across regional billing formats.</li></ul>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Automation changed the work, not only the duration.",
      children: ($$renderer3) => {
        $$renderer3.push(`<div class="before-after svelte-qpxry2"><div class="svelte-qpxry2"><span class="mono svelte-qpxry2">Before</span> <strong class="svelte-qpxry2">60 to 90 minutes</strong> <p class="svelte-qpxry2">Read, type, calculate, and verify ten bills with sustained concentration.</p></div> <div class="svelte-qpxry2"><span class="mono svelte-qpxry2">After</span> <strong class="svelte-qpxry2">12 to 18 minutes</strong> <p class="svelte-qpxry2">Review flagged fields, confirm or correct the value, and save.</p></div></div> <p>The result was 95% accuracy for PDF bills, 80% for image-based bills, and roughly 80% less
			processing time. The human role shifted from data entry and calculation to focused
			verification.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "What I learned, and what I would change.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<h3>Test diverse inputs before production</h3> <p>The first migration was reactive. A structured bill set covering providers, regions,
			utilities, and image quality should have been part of the release gate from the start.</p> <h3>Use risk-weighted thresholds</h3> <p>A single confidence score treats every field equally. The next iteration should assign
			stricter thresholds to totals, VAT, and unit rates than to lower-risk descriptive fields.</p> <h3>Next experiment</h3> <p>Measure correction rates by field and document type, then route reviews using both confidence
			and business impact. That would reduce manual effort without weakening protection around
			financial data.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudyNav($$renderer2, { current: "bill-reader" });
    $$renderer2.push(`<!----> `);
    Contact($$renderer2, {});
    $$renderer2.push(`<!----></main> `);
    Footer($$renderer2, {});
    $$renderer2.push(`<!---->`);
  });
}
var init_page_svelte2 = __esm({
  ".netlify/server/entries/pages/work/bill-reader/_page.svelte.js"() {
    "use strict";
    init_index_server();
    init_Footer();
    init_Contact();
    init_CaseStudyNav();
  }
});

// .netlify/server/nodes/3.js
var __exports4 = {};
__export(__exports4, {
  component: () => component4,
  fonts: () => fonts4,
  imports: () => imports4,
  index: () => index4,
  stylesheets: () => stylesheets4
});
var index4, component_cache4, component4, imports4, stylesheets4, fonts4;
var init__4 = __esm({
  ".netlify/server/nodes/3.js"() {
    "use strict";
    index4 = 3;
    component4 = async () => component_cache4 ??= (await Promise.resolve().then(() => (init_page_svelte2(), page_svelte_exports2))).default;
    imports4 = ["_app/immutable/nodes/3.DIF8WK_W.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/chunks/xihTtKlq.js", "_app/immutable/chunks/BxQp6cwM.js", "_app/immutable/chunks/LyT3dOoU.js", "_app/immutable/chunks/B8_E3Gts.js", "_app/immutable/chunks/CSgo6OAD.js"];
    stylesheets4 = ["_app/immutable/assets/Footer.BnU4mJEO.css", "_app/immutable/assets/Contact.BlBHjYPW.css", "_app/immutable/assets/CaseStudyNav.BZy3QHTA.css", "_app/immutable/assets/3.UX8ylrBZ.css"];
    fonts4 = [];
  }
});

// .netlify/server/entries/pages/work/platform-delivery/_page.svelte.js
var page_svelte_exports3 = {};
__export(page_svelte_exports3, {
  default: () => _page3
});
function _page3($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const study = getCaseStudy("platform-delivery");
    const description = "How Abhishek Kumar introduced product delivery structure, used Amplitude evidence, and increased engagement across an enterprise energy platform.";
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "CreativeWork",
      name: study.title,
      description,
      url: "https://abhishzk.com/work/platform-delivery",
      image: `https://abhishzk.com${study.image}`,
      author: {
        "@type": "Person",
        name: "Abhishek Kumar",
        url: "https://abhishzk.com"
      },
      dateModified: "2026-09-01",
      about: [
        "Product Management",
        "B2B SaaS",
        "Energy Analytics",
        "Platform Adoption"
      ]
    };
    const structuredDataHtml = `<script type="application/ld+json">${JSON.stringify(structuredData).replace(/</g, "\\u003c")}</script>`;
    head("1yc45hh", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Watt Footprint Platform Case Study | Abhishek Kumar</title>`);
      });
      $$renderer3.push(`<meta name="description"${attr("content", description)}/> <link rel="canonical" href="https://abhishzk.com/work/platform-delivery"/> <meta property="og:type" content="article"/> <meta property="og:title"${attr("content", `${stringify(study.title)} | Product Case Study`)}/> <meta property="og:description"${attr("content", description)}/> <meta property="og:url" content="https://abhishzk.com/work/platform-delivery"/> <meta property="og:image" content="https://abhishzk.com/images/social/platform-delivery.png"/> <meta property="og:image:width" content="1200"/> <meta property="og:image:height" content="630"/> <meta property="og:image:alt" content="Watt Footprint platform case study by Abhishek Kumar"/> <meta name="twitter:card" content="summary_large_image"/> <meta name="twitter:title"${attr("content", `${stringify(study.title)} | Product Case Study`)}/> <meta name="twitter:description"${attr("content", description)}/> <meta name="twitter:image" content="https://abhishzk.com/images/social/platform-delivery.png"/> <meta name="twitter:image:alt" content="Watt Footprint platform case study by Abhishek Kumar"/> ${html(structuredDataHtml)}`);
    });
    Header($$renderer2, {});
    $$renderer2.push(`<!----> <main id="main-content">`);
    CaseStudyHero($$renderer2, { study });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "The platform had customers, but product delivery lacked a system.",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>Watt Footprint operated across energy studies, physical project implementation, and software.
			The software team was the newest group. When I joined, its backlog sat in a shared workspace
			with other departments, external delivery happened through Slack, and there was no consistent
			sprint or release structure.</p> <p>At the same time, customers were moving beyond pilots. New accounts, international markets,
			and larger IoT deployments increased the cost of unclear priorities and unstable releases.</p> `);
        DecisionBlock($$renderer3, {
          title: "Create one product cadence across internal and external teams.",
          children: ($$renderer4) => {
            $$renderer4.push(`<p>I separated the software backlog, introduced two-week delivery cycles, and brought
				engineering, data, design, QA, and operations into the same review and prioritization
				rhythm.</p>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!---->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Adoption was the goal. Sprint completion was a supporting signal.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>The product served two enterprise experiences. Energy Snapshot customers used bills for
			analytics, reporting, CO2 tracking, and a familiar rating model. Energy Pro customers used
			live meters for real-time electricity, gas, water, and solar monitoring.</p> <div class="tier-grid svelte-1yc45hh"><article class="svelte-1yc45hh"><h3 class="svelte-1yc45hh">Energy Snapshot</h3> <p class="svelte-1yc45hh">Bill-led analytics, reporting, CO2 tracking, and a clear energy-performance rating.</p></article> <article class="svelte-1yc45hh"><h3 class="svelte-1yc45hh">Energy Pro</h3> <p class="svelte-1yc45hh">Live utility data, site trends, bill management, sensors, gateways, and operational
					alerts.</p></article></div> <p>The roadmap needed to support both experiences while improving the shared platform foundation.
			That meant balancing visible customer value with identity, performance, data quality, and
			release stability.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Evidence changed what belonged in the roadmap.",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>I reviewed Amplitude weekly to understand how external customers used the platform. The useful
			question was not whether someone logged in. It was whether accounts were using the workflows
			that turned energy data into operational decisions.</p> <div class="adoption-grid svelte-1yc45hh"><article class="svelte-1yc45hh"><strong class="mono svelte-1yc45hh">+84%</strong><span class="svelte-1yc45hh">total sessions from H1 to H2 2025</span></article> <article class="svelte-1yc45hh"><strong class="mono svelte-1yc45hh">100%</strong><span class="svelte-1yc45hh">logo retention across the engagement</span></article></div> `);
        DecisionBlock($$renderer3, {
          title: "Prioritize depth of use, not surface-level login frequency.",
          children: ($$renderer4) => {
            $$renderer4.push(`<p>The same small set of energy managers could create much more account value without a large
				rise in individual users. Account-level workflow adoption became the more useful product
				signal.</p>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!---->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Delivery covered customer value and platform resilience together.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>Across seven completed sprints, the team delivered a redesigned dashboard, analytics and
			bills, multi-currency support, budgets, alerts, reporting, role-based administration, mobile
			work, and performance improvements.</p> <div class="delivery-groups svelte-1yc45hh"><div class="svelte-1yc45hh"><h3 class="svelte-1yc45hh">Customer workflows</h3> <p class="svelte-1yc45hh">Budget tracking, configurable alerts, reporting, notes, and multi-site administration.</p></div> <div class="svelte-1yc45hh"><h3 class="svelte-1yc45hh">International readiness</h3> <p class="svelte-1yc45hh">GBP and AED support, regional bill formats, customer onboarding, and compliance
					coordination.</p></div> <div class="svelte-1yc45hh"><h3 class="svelte-1yc45hh">Platform foundation</h3> <p class="svelte-1yc45hh">Identity and access, technical debt, release quality, data performance, and mobile
					experience.</p></div></div> <h3>My responsibility</h3> <ul><li>Owned prioritization and delivery across web and mobile.</li> <li>Managed an external group of two engineers, QA, and UX design.</li> <li>Aligned internal engineering, data, operations, and commercial stakeholders.</li> <li>Introduced refinement, regression testing, and release quality gates.</li> <li>Reported product performance, risk, and roadmap recommendations to senior leaders.</li></ul>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Stability became a product priority when heavy users felt the cost.",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>Some established customer accounts experienced infographic load times above two minutes
			because of larger data volumes and under-sized compute. The issue affected the customers using
			the platform most deeply, so it could not be treated as invisible technical work.</p> `);
        DecisionBlock($$renderer3, {
          title: "Treat performance as part of enterprise adoption.",
          children: ($$renderer4) => {
            $$renderer4.push(`<p>The team increased compute capacity and introduced continuous aggregates for expensive
				queries. Heavy-client responses moved to roughly 300 to 400 milliseconds, while standard
				responses moved to roughly 40 to 50 milliseconds.</p>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> <p>That change protected the workflows generating the strongest adoption signal and reduced the
			gap between product promise and daily customer experience.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "The result was deeper use across the same customer base.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>External sessions grew by 84%, repeat use increased, and core reporting and energy-management
			actions grew substantially. All seven completed sprints reached their committed scope, while
			logo retention remained at 100% across the engagement.</p> <p>The important outcome was not a longer feature list. Customers moved from passive access
			toward budgets, reporting, live monitoring, alerts, and multi-site management as operational
			workflows.</p> <h3>What I would change</h3> <p>I would segment analytics by persona earlier. Sustainability leads, site managers, and account
			administrators use the platform differently. Role-based cohorts would have made prioritization
			more precise.</p> <h3>Next experiment</h3> <p>Connect account-level adoption to renewal and expansion signals, then test whether quarterly
			value summaries can create the same customer engagement as the annual energy report.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudyNav($$renderer2, { current: "platform-delivery" });
    $$renderer2.push(`<!----> `);
    Contact($$renderer2, {});
    $$renderer2.push(`<!----></main> `);
    Footer($$renderer2, {});
    $$renderer2.push(`<!---->`);
  });
}
var init_page_svelte3 = __esm({
  ".netlify/server/entries/pages/work/platform-delivery/_page.svelte.js"() {
    "use strict";
    init_index_server();
    init_Footer();
    init_Contact();
    init_CaseStudyNav();
  }
});

// .netlify/server/nodes/4.js
var __exports5 = {};
__export(__exports5, {
  component: () => component5,
  fonts: () => fonts5,
  imports: () => imports5,
  index: () => index5,
  stylesheets: () => stylesheets5
});
var index5, component_cache5, component5, imports5, stylesheets5, fonts5;
var init__5 = __esm({
  ".netlify/server/nodes/4.js"() {
    "use strict";
    index5 = 4;
    component5 = async () => component_cache5 ??= (await Promise.resolve().then(() => (init_page_svelte3(), page_svelte_exports3))).default;
    imports5 = ["_app/immutable/nodes/4.BjGb5l5l.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/chunks/xihTtKlq.js", "_app/immutable/chunks/BxQp6cwM.js", "_app/immutable/chunks/LyT3dOoU.js", "_app/immutable/chunks/B8_E3Gts.js", "_app/immutable/chunks/CSgo6OAD.js"];
    stylesheets5 = ["_app/immutable/assets/Footer.BnU4mJEO.css", "_app/immutable/assets/Contact.BlBHjYPW.css", "_app/immutable/assets/CaseStudyNav.BZy3QHTA.css", "_app/immutable/assets/4.Dtop65CU.css"];
    fonts5 = [];
  }
});

// .netlify/server/entries/pages/work/visajobs/_page.svelte.js
var page_svelte_exports4 = {};
__export(page_svelte_exports4, {
  default: () => _page4
});
function MediaFigure($$renderer, $$props) {
  let src = $$props["src"];
  let alt = $$props["alt"];
  let caption = $$props["caption"];
  let width = $$props["width"];
  let height = $$props["height"];
  let tone = fallback($$props["tone"], "light");
  $$renderer.push(`<figure${attr_class("svelte-165iacd", void 0, { "dark": tone === "dark" })}><div class="media-frame svelte-165iacd"><img${attr("src", src)}${attr("alt", alt)}${attr("width", width)}${attr("height", height)} loading="lazy" decoding="async" class="svelte-165iacd"/></div> <figcaption class="svelte-165iacd">${escape_html(caption)}</figcaption></figure>`);
  bind_props($$props, {
    src,
    alt,
    caption,
    width,
    height,
    tone
  });
}
function _page4($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    const study = getCaseStudy("visajobs");
    const description = "How Abhishek Kumar built VisaJobs Ireland from a personal job-search problem into a data product for 3,500+ candidates and Irish employers.";
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "CreativeWork",
      name: study.title,
      description,
      url: "https://abhishzk.com/work/visajobs",
      image: `https://abhishzk.com${study.image}`,
      author: {
        "@type": "Person",
        name: "Abhishek Kumar",
        url: "https://abhishzk.com"
      },
      dateModified: "2026-09-01",
      about: [
        "Product Management",
        "Data Product",
        "Visa Sponsorship",
        "Two-sided Marketplace"
      ]
    };
    const structuredDataHtml = `<script type="application/ld+json">${JSON.stringify(structuredData).replace(/</g, "\\u003c")}</script>`;
    head("kqjc9g", $$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>VisaJobs Product Case Study | Abhishek Kumar</title>`);
      });
      $$renderer3.push(`<meta name="description"${attr("content", description)}/> <link rel="canonical" href="https://abhishzk.com/work/visajobs"/> <meta property="og:type" content="article"/> <meta property="og:title"${attr("content", `${stringify(study.title)} | Product Case Study`)}/> <meta property="og:description"${attr("content", description)}/> <meta property="og:url" content="https://abhishzk.com/work/visajobs"/> <meta property="og:image" content="https://abhishzk.com/images/social/visajobs.png"/> <meta property="og:image:width" content="1200"/> <meta property="og:image:height" content="630"/> <meta property="og:image:alt" content="VisaJobs Ireland product case study by Abhishek Kumar"/> <meta name="twitter:card" content="summary_large_image"/> <meta name="twitter:title"${attr("content", `${stringify(study.title)} | Product Case Study`)}/> <meta name="twitter:description"${attr("content", description)}/> <meta name="twitter:image" content="https://abhishzk.com/images/social/visajobs.png"/> <meta name="twitter:image:alt" content="VisaJobs Ireland product case study by Abhishek Kumar"/> ${html(structuredDataHtml)}`);
    });
    Header($$renderer2, {});
    $$renderer2.push(`<!----> <main id="main-content">`);
    CaseStudyHero($$renderer2, { study });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "The problem was visible. The answer was buried.",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>While job hunting in Ireland, I kept reaching the same late-stage failure: a strong role and a
			promising interview process would stop when visa sponsorship came up. The information existed,
			but it was spread across government PDFs, spreadsheets, job boards, and company claims that
			were difficult to verify.</p> <p>The candidate job was not simply to find more vacancies. It was to know which opportunities
			were worth the time before applying. The employer job was different: reach candidates who
			already understood their eligibility and could have a more informed sponsorship conversation.</p> `);
        DecisionBlock($$renderer3, {
          title: "Treat permit history as product infrastructure, not editorial content.",
          children: ($$renderer4) => {
            $$renderer4.push(`<p>Official permit records became the trust layer beneath company discovery, live jobs, sponsor
				scores, comparison tools, and the employer verification flow.</p>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!---->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "A useful product needed more than a searchable database.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>The first product question was how to convert raw public records into a decision. A company
			name and permit count were useful, but candidates also needed recency, consistency, direction
			of travel, relevant jobs, salary eligibility, and a way to manage applications.</p> <div class="jobs-grid svelte-kqjc9g"><article class="svelte-kqjc9g"><h3 class="svelte-kqjc9g">Candidate job</h3> <p class="svelte-kqjc9g">Find employers with evidence of sponsorship and decide where an application is viable.</p></article> <article class="svelte-kqjc9g"><h3 class="svelte-kqjc9g">Employer job</h3> <p class="svelte-kqjc9g">Reach visa-ready candidates and prove sponsorship history without repeating manual checks.</p></article> <article class="svelte-kqjc9g"><h3 class="svelte-kqjc9g">Trust job</h3> <p class="svelte-kqjc9g">Show the public source, verification logic, and limits behind every product conclusion.</p></article></div> <h3>Constraints that shaped the roadmap</h3> <ul><li>Employer names in government data do not always match consumer-facing brands.</li> <li>Live job availability changes daily while permit history changes on a different cadence.</li> <li>Eligibility depends on salary, occupation, permit type, and personal circumstances.</li> <li>The product must clarify evidence without presenting legal advice.</li></ul>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "The product expanded when demand revealed a second side.",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>The candidate launch produced more than candidate interest. Recruiters and employers began
			asking whether they could post roles directly. That signal changed the product from a
			candidate research tool into a two-sided system.</p> `);
        DecisionBlock($$renderer3, {
          title: "Verify the company before giving its jobs a trusted badge.",
          children: ($$renderer4) => {
            $$renderer4.push(`<p>Employers claim an existing permit record, verify a work-domain email, and complete a
				one-time account review before their first role goes live. Later roles inherit the verified
				company relationship without repeating the full process.</p>`);
          },
          $$slots: { default: true }
        });
        $$renderer3.push(`<!----> <p>This protected the core promise. A sponsor label should represent evidence and a verified
			company relationship, not a self-reported checkbox.</p> <div class="product-link-wrap svelte-kqjc9g"><a class="button button-secondary"${attr("href", externalLinks.visaJobsCandidate.href)} target="_blank" rel="noreferrer">Visit candidate product</a> <a class="button button-secondary"${attr("href", externalLinks.visaJobsEmployer.href)} target="_blank" rel="noreferrer">Visit employer product</a></div>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "I owned the product from signal to release.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>As Founder and Product Manager, I framed the problem, shaped the roadmap, defined the data
			model, designed the core journeys, and coordinated implementation and launch. Product
			decisions covered candidate discovery, employer verification, job publishing, trust language,
			and the boundary between helpful guidance and legal advice.</p> <h3>Delivery and collaboration</h3> <ul><li>Translated government permit records into product definitions and acceptance criteria.</li> <li>Prioritized candidate and employer workflows from search behavior and direct feedback.</li> <li>Reviewed production data quality, company matching, and verification edge cases.</li> <li>Connected launch distribution to the next discovery cycle.</li></ul> <h3>Measurement</h3> <p>I tracked public demand, product scope, search behavior, employer requests, and qualitative
			feedback. The next measurement layer is activation and repeat-use cohorts that connect product
			behavior to better-informed candidate and employer decisions.</p> `);
        MediaFigure($$renderer3, {
          src: "/images/casestudies/visajobs-extension.webp",
          alt: "VisaJobs Job Check browser extension evaluating a live LinkedIn job",
          width: 640,
          height: 400,
          caption: "A real VisaJobs Job Check product capture. The extension brings sponsorship evidence into the candidate's existing job-search workflow."
        });
        $$renderer3.push(`<!---->`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "Distribution became a product feedback channel.",
      tone: "soft",
      children: ($$renderer3) => {
        $$renderer3.push(`<p>The launch story reached ${escape_html(visaJobsPublicMetrics[5].value)} people and generated ${escape_html(visaJobsPublicMetrics[6].value)} click-throughs. The distribution mattered because it exposed the product to people who
			had already experienced the same problem.</p> <p>Comments, direct messages, search behavior, and employer requests became discovery inputs.
			They helped prioritize comparison tools, permit explainers, salary checks, application
			tracking, and the separate employer workflow.</p> <div class="public-facts svelte-kqjc9g"><div class="svelte-kqjc9g"><strong class="mono svelte-kqjc9g">${escape_html(visaJobsPublicMetrics[4].value)}</strong><span class="svelte-kqjc9g">nationalities represented in the public data</span></div> <div class="svelte-kqjc9g"><strong class="mono svelte-kqjc9g">${escape_html(visaJobsPublicMetrics[1].value)}</strong><span class="svelte-kqjc9g">official permit records</span></div> <div class="svelte-kqjc9g"><strong class="mono svelte-kqjc9g">${escape_html(visaJobsPublicMetrics[2].value)}</strong><span class="svelte-kqjc9g">employers in the searchable data</span></div></div> <p class="verification-note mono svelte-kqjc9g">Changing product figures verified September 2026.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudySection($$renderer2, {
      title: "What I learned, and what comes next.",
      children: ($$renderer3) => {
        $$renderer3.push(`<h3>What worked</h3> <p>Starting from a personal problem made the user need clear, but the product became credible
			only when the evidence model was stronger than a typical job-board filter. Public provenance
			and transparent definitions are part of the user experience.</p> <h3>What I would improve</h3> <p>I would formalize activation and repeat-use cohorts earlier. Growth and public reach show
			demand, but the next product questions require clearer evidence about which tools change
			application behavior and which employer actions produce useful candidate outcomes.</p> <h3>Next experiment</h3> <p>Connect employer verification, candidate fit signals, and application progress into a
			measurable quality loop. The goal is not more listings. It is fewer wasted applications and
			better-informed hiring conversations.</p>`);
      },
      $$slots: { default: true }
    });
    $$renderer2.push(`<!----> `);
    CaseStudyNav($$renderer2, { current: "visajobs" });
    $$renderer2.push(`<!----> `);
    Contact($$renderer2, {});
    $$renderer2.push(`<!----></main> `);
    Footer($$renderer2, {});
    $$renderer2.push(`<!---->`);
  });
}
var init_page_svelte4 = __esm({
  ".netlify/server/entries/pages/work/visajobs/_page.svelte.js"() {
    "use strict";
    init_index_server();
    init_analytics();
    init_Footer();
    init_Contact();
    init_CaseStudyNav();
  }
});

// .netlify/server/nodes/5.js
var __exports6 = {};
__export(__exports6, {
  component: () => component6,
  fonts: () => fonts6,
  imports: () => imports6,
  index: () => index6,
  stylesheets: () => stylesheets6
});
var index6, component_cache6, component6, imports6, stylesheets6, fonts6;
var init__6 = __esm({
  ".netlify/server/nodes/5.js"() {
    "use strict";
    index6 = 5;
    component6 = async () => component_cache6 ??= (await Promise.resolve().then(() => (init_page_svelte4(), page_svelte_exports4))).default;
    imports6 = ["_app/immutable/nodes/5.Cjllpfz2.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/chunks/xihTtKlq.js", "_app/immutable/chunks/BxQp6cwM.js", "_app/immutable/chunks/LyT3dOoU.js", "_app/immutable/chunks/B8_E3Gts.js", "_app/immutable/chunks/CSgo6OAD.js"];
    stylesheets6 = ["_app/immutable/assets/Footer.BnU4mJEO.css", "_app/immutable/assets/Contact.BlBHjYPW.css", "_app/immutable/assets/CaseStudyNav.BZy3QHTA.css", "_app/immutable/assets/5.DavqBdBI.css"];
    fonts6 = [];
  }
});

// .netlify/shims.js
import buffer from "node:buffer";
import { webcrypto } from "node:crypto";
var File2 = (
  /** @type {import('node:buffer') & { File?: File}} */
  buffer.File
);
var globals = {
  crypto: webcrypto,
  File: File2
};
function installPolyfills() {
  for (const name in globals) {
    if (name in globalThis) continue;
    Object.defineProperty(globalThis, name, {
      enumerable: true,
      configurable: true,
      writable: true,
      value: globals[name]
    });
  }
}
installPolyfills();

// .netlify/server/index.js
init_index_server();
init_shared();
init_internal();

// .netlify/server/chunks/utils.js
init_shared();
import { json, text } from "@sveltejs/kit";
import { HttpError as HttpError2, SvelteKitError as SvelteKitError2 } from "@sveltejs/kit/internal";
import { with_request_store } from "@sveltejs/kit/internal/server";
import * as set_cookie_parser from "set-cookie-parser";
import * as devalue3 from "devalue";
var ENDPOINT_METHODS = [
  "GET",
  "POST",
  "PUT",
  "PATCH",
  "DELETE",
  "OPTIONS",
  "HEAD"
];
var PAGE_METHODS = [
  "GET",
  "POST",
  "HEAD"
];
var decoder = new TextDecoder();
function set_nested_value(object, path_string, value) {
  if (path_string.startsWith("n:")) {
    path_string = path_string.slice(2);
    value = value === "" ? void 0 : parseFloat(value);
  } else if (path_string.startsWith("b:")) {
    path_string = path_string.slice(2);
    value = value === "on";
  }
  deep_set(object, split_path(path_string), value);
}
var DELETE_KEY = {};
function convert_formdata(data) {
  const result = {};
  for (let key2 of data.keys()) {
    const is_array2 = key2.endsWith("[]");
    let values = data.getAll(key2);
    if (is_array2) key2 = key2.slice(0, -2);
    values = values.filter((entry) => typeof entry === "string" || entry.name !== "" || entry.size > 0);
    if (values.length === 0 && !is_array2) continue;
    if (key2.startsWith("n:")) {
      key2 = key2.slice(2);
      values = values.map((v) => v === "" ? void 0 : parseFloat(v));
    } else if (key2.startsWith("b:")) {
      key2 = key2.slice(2);
      values = values.map((v) => v === "on");
    }
    if (values.length > 1 && !is_array2) throw new Error(`Form cannot contain duplicated keys \u2014 "${key2}" has ${values.length} values`);
    set_nested_value(result, key2, is_array2 ? values : values[0]);
  }
  return result;
}
var BINARY_FORM_CONTENT_TYPE = "application/x-sveltekit-formdata";
var BINARY_FORM_VERSION = 0;
var HEADER_BYTES = 7;
async function deserialize_binary_form(request) {
  if (request.headers.get("content-type") !== "application/x-sveltekit-formdata") {
    const form_data = await request.formData();
    return {
      data: convert_formdata(form_data),
      meta: {},
      form_data
    };
  }
  if (!request.body) throw deserialize_error("no body");
  const reader = request.body.getReader();
  const chunks = [];
  function get_chunk(index7) {
    if (index7 in chunks) return chunks[index7];
    let i = chunks.length;
    while (i <= index7) {
      chunks[i] = reader.read().then((chunk) => chunk.value);
      i++;
    }
    return chunks[index7];
  }
  async function get_buffer(offset, length) {
    let start_chunk;
    let chunk_start = 0;
    let chunk_index;
    for (chunk_index = 0; ; chunk_index++) {
      const chunk = await get_chunk(chunk_index);
      if (!chunk) return null;
      const chunk_end = chunk_start + chunk.byteLength;
      if (offset >= chunk_start && offset < chunk_end) {
        start_chunk = chunk;
        break;
      }
      chunk_start = chunk_end;
    }
    if (offset + length <= chunk_start + start_chunk.byteLength) return start_chunk.subarray(offset - chunk_start, offset + length - chunk_start);
    const chunks2 = [start_chunk.subarray(offset - chunk_start)];
    let cursor = start_chunk.byteLength - offset + chunk_start;
    while (cursor < length) {
      chunk_index++;
      let chunk = await get_chunk(chunk_index);
      if (!chunk) return null;
      if (chunk.byteLength > length - cursor) chunk = chunk.subarray(0, length - cursor);
      chunks2.push(chunk);
      cursor += chunk.byteLength;
    }
    const buffer2 = new Uint8Array(length);
    cursor = 0;
    for (const chunk of chunks2) {
      buffer2.set(chunk, cursor);
      cursor += chunk.byteLength;
    }
    return buffer2;
  }
  const header = await get_buffer(0, HEADER_BYTES);
  if (!header) throw deserialize_error("too short");
  if (header[0] !== BINARY_FORM_VERSION) throw deserialize_error(`got version ${header[0]}, expected version ${BINARY_FORM_VERSION}`);
  const header_view = new DataView(header.buffer, header.byteOffset, header.byteLength);
  const data_length = header_view.getUint32(1, true);
  const file_offsets_length = header_view.getUint16(5, true);
  const data_buffer = await get_buffer(HEADER_BYTES, data_length);
  if (!data_buffer) throw deserialize_error("data too short");
  let file_offsets;
  let files_start_offset;
  if (file_offsets_length > 0) {
    const file_offsets_buffer = await get_buffer(HEADER_BYTES + data_length, file_offsets_length);
    if (!file_offsets_buffer) throw deserialize_error("file offset table too short");
    const parsed_offsets = JSON.parse(decoder.decode(file_offsets_buffer));
    if (!Array.isArray(parsed_offsets) || parsed_offsets.some((n) => typeof n !== "number" || !Number.isInteger(n) || n < 0)) throw deserialize_error("invalid file offset table");
    file_offsets = parsed_offsets;
    files_start_offset = HEADER_BYTES + data_length + file_offsets_length;
  }
  const file_spans = [];
  const [data, meta] = devalue3.parse(decoder.decode(data_buffer), { File: ([name, type, size, last_modified, index7]) => {
    if (typeof name !== "string" || typeof type !== "string" || typeof size !== "number" || typeof last_modified !== "number" || typeof index7 !== "number") throw deserialize_error("invalid file metadata");
    let offset = file_offsets[index7];
    if (offset === void 0) throw deserialize_error("duplicate file offset table index");
    file_offsets[index7] = void 0;
    offset += files_start_offset;
    file_spans.push({
      offset,
      size
    });
    return new Proxy(new LazyFile(name, type, size, last_modified, get_chunk, offset), { getPrototypeOf() {
      return File.prototype;
    } });
  } });
  file_spans.sort((a, b) => a.offset - b.offset || a.size - b.size);
  for (let i = 1; i < file_spans.length; i++) {
    const previous = file_spans[i - 1];
    const current2 = file_spans[i];
    const previous_end = previous.offset + previous.size;
    if (previous_end < current2.offset) throw deserialize_error("gaps in file data");
    if (previous_end > current2.offset) throw deserialize_error("overlapping file data");
  }
  (async () => {
    let has_more = true;
    while (has_more) has_more = !!await get_chunk(chunks.length);
  })().catch(noop2);
  return {
    data,
    meta,
    form_data: null
  };
}
function deserialize_error(message) {
  return new SvelteKitError2(400, "Bad Request", `Could not deserialize binary form: ${message}`);
}
var LazyFile = class LazyFile2 {
  /** @type {(index: number) => Promise<Uint8Array<ArrayBuffer> | undefined>} */
  #get_chunk;
  /** @type {number} */
  #offset;
  /**
  * @param {string} name
  * @param {string} type
  * @param {number} size
  * @param {number} last_modified
  * @param {(index: number) => Promise<Uint8Array<ArrayBuffer> | undefined>} get_chunk
  * @param {number} offset
  */
  constructor(name, type, size, last_modified, get_chunk, offset) {
    this.name = name;
    this.type = type;
    this.size = size;
    this.lastModified = last_modified;
    this.webkitRelativePath = "";
    this.#get_chunk = get_chunk;
    this.#offset = offset;
    this.arrayBuffer = this.arrayBuffer.bind(this);
    this.bytes = this.bytes.bind(this);
    this.slice = this.slice.bind(this);
    this.stream = this.stream.bind(this);
    this.text = this.text.bind(this);
  }
  /** @type {ArrayBuffer | undefined} */
  #buffer;
  async arrayBuffer() {
    this.#buffer ??= await new Response(this.stream()).arrayBuffer();
    return this.#buffer;
  }
  async bytes() {
    return new Uint8Array(await this.arrayBuffer());
  }
  /**
  * @param {number=} start
  * @param {number=} end
  * @param {string=} contentType
  */
  slice(start = 0, end = this.size, contentType = this.type) {
    if (start < 0) start = Math.max(this.size + start, 0);
    else start = Math.min(start, this.size);
    if (end < 0) end = Math.max(this.size + end, 0);
    else end = Math.min(end, this.size);
    const size = Math.max(end - start, 0);
    return new LazyFile2(this.name, contentType, size, this.lastModified, this.#get_chunk, this.#offset + start);
  }
  stream() {
    let cursor = 0;
    let chunk_index = 0;
    return new ReadableStream({
      start: async (controller) => {
        let chunk_start = 0;
        let start_chunk;
        for (chunk_index = 0; ; chunk_index++) {
          const chunk = await this.#get_chunk(chunk_index);
          if (!chunk) return null;
          const chunk_end = chunk_start + chunk.byteLength;
          if (this.#offset >= chunk_start && this.#offset < chunk_end) {
            start_chunk = chunk;
            break;
          }
          chunk_start = chunk_end;
        }
        if (this.#offset + this.size <= chunk_start + start_chunk.byteLength) {
          controller.enqueue(start_chunk.subarray(this.#offset - chunk_start, this.#offset + this.size - chunk_start));
          controller.close();
        } else {
          controller.enqueue(start_chunk.subarray(this.#offset - chunk_start));
          cursor = start_chunk.byteLength - this.#offset + chunk_start;
        }
      },
      pull: async (controller) => {
        chunk_index++;
        let chunk = await this.#get_chunk(chunk_index);
        if (!chunk) {
          controller.error("incomplete file data");
          controller.close();
          return;
        }
        if (chunk.byteLength > this.size - cursor) chunk = chunk.subarray(0, this.size - cursor);
        controller.enqueue(chunk);
        cursor += chunk.byteLength;
        if (cursor >= this.size) controller.close();
      }
    });
  }
  async text() {
    return decoder.decode(await this.arrayBuffer());
  }
};
var path_regex = /^[a-zA-Z_$]\w*(\.[a-zA-Z_$]\w*|\[\d+\])*$/;
function split_path(path) {
  if (!path_regex.test(path)) throw new Error(`Invalid path ${path}`);
  return path.split(/\.|\[|\]/).filter(Boolean);
}
function check_prototype_pollution(key2) {
  if (key2 === "__proto__" || key2 === "constructor" || key2 === "prototype") throw new Error(`Invalid key "${key2}"`);
}
function deep_set(object, keys, value) {
  let current2 = object;
  for (let i = 0; i < keys.length - 1; i += 1) {
    const key2 = keys[i];
    check_prototype_pollution(key2);
    const is_array2 = /^\d+$/.test(keys[i + 1]);
    const inner = Object.hasOwn(current2, key2) ? current2[key2] : void 0;
    const exists = inner != null;
    if (exists && is_array2 !== Array.isArray(inner)) throw new Error(`Invalid array key ${keys[i + 1]}`);
    if (!exists) {
      if (value === DELETE_KEY) return;
      current2[key2] = is_array2 ? [] : {};
    }
    current2 = current2[key2];
  }
  const final_key = keys[keys.length - 1];
  check_prototype_pollution(final_key);
  if (value === DELETE_KEY) delete current2[final_key];
  else current2[final_key] = value;
}
function negotiate(accept, types) {
  const parts = [];
  accept.split(",").forEach((str, i) => {
    const match = /^[ \t]*([^/ \t]+)\/([^; \t]+)[ \t]*(?:;[ \t]*q=([0-9.]+))?/.exec(str);
    if (match) {
      const [, type, subtype, q = "1"] = match;
      parts.push({
        type,
        subtype,
        q: +q,
        i
      });
    }
  });
  parts.sort((a, b) => {
    if (a.q !== b.q) return b.q - a.q;
    if (a.subtype === "*" !== (b.subtype === "*")) return a.subtype === "*" ? 1 : -1;
    if (a.type === "*" !== (b.type === "*")) return a.type === "*" ? 1 : -1;
    return a.i - b.i;
  });
  let accepted;
  let min_priority = Infinity;
  for (const mimetype of types) {
    const [type, subtype] = mimetype.split("/");
    const priority = parts.findIndex((part) => (part.type === type || part.type === "*") && (part.subtype === subtype || part.subtype === "*"));
    if (priority !== -1 && priority < min_priority) {
      accepted = mimetype;
      min_priority = priority;
    }
  }
  return accepted;
}
function get_set_cookies(headers2) {
  if (typeof headers2.getSetCookie === "function") return headers2.getSetCookie();
  const set_cookie = headers2.get("set-cookie");
  return set_cookie ? set_cookie_parser.splitCookiesString(set_cookie) : [];
}
function is_content_type(request, ...types) {
  const type = request.headers.get("content-type")?.split(";", 1)[0].trim() ?? "";
  return types.includes(type.toLowerCase());
}
function is_form_content_type(request) {
  return is_content_type(request, "application/x-www-form-urlencoded", "multipart/form-data", "text/plain", BINARY_FORM_CONTENT_TYPE);
}
var escape_html_attr_dict = {
  "&": "&amp;",
  '"': "&quot;"
};
var escape_html_dict = {
  "&": "&amp;",
  "<": "&lt;"
};
var escape_html_attr_regex = new RegExp(`[${Object.keys(escape_html_attr_dict).join("")}]|[\\ud800-\\udbff](?![\\udc00-\\udfff])|[\\ud800-\\udbff][\\udc00-\\udfff]|[\\udc00-\\udfff]`, "g");
var escape_html_regex = new RegExp(`[${Object.keys(escape_html_dict).join("")}]|[\\ud800-\\udbff](?![\\udc00-\\udfff])|[\\ud800-\\udbff][\\udc00-\\udfff]|[\\udc00-\\udfff]`, "g");
function escape_html2(str, is_attr) {
  const dict = is_attr ? escape_html_attr_dict : escape_html_dict;
  return str.replace(is_attr ? escape_html_attr_regex : escape_html_regex, (match) => {
    if (match.length === 2) return match;
    return dict[match] ?? `&#${match.charCodeAt(0)};`;
  });
}
function method_not_allowed(mod, method) {
  return text(`${method} method not allowed`, {
    status: 405,
    headers: { allow: allowed_methods(mod).join(", ") }
  });
}
function allowed_methods(mod) {
  const allowed = ENDPOINT_METHODS.filter((method) => method in mod);
  if ("GET" in mod && !("HEAD" in mod)) allowed.push("HEAD");
  return allowed;
}
function get_global_name(options2) {
  return `__sveltekit_${options2.version_hash}`;
}
function static_error_page(options2, status, message) {
  let page2 = options2.templates.error({
    status,
    message: escape_html2(message)
  });
  return text(page2, {
    headers: { "content-type": "text/html; charset=utf-8" },
    status
  });
}
async function handle_fatal_error(event, state2, options2, error2) {
  error2 = error2 instanceof HttpError2 ? error2 : coalesce_to_error(error2);
  const status = get_status(error2);
  const body = await handle_error_and_jsonify(event, state2, options2, error2);
  const type = negotiate(event.request.headers.get("accept") || "text/html", ["application/json", "text/html"]);
  if (event.isDataRequest || type === "application/json") return json(body, { status });
  return static_error_page(options2, status, body.message);
}
async function handle_error_and_jsonify(event, state2, options2, error2) {
  if (error2 instanceof HttpError2) return {
    message: "Unknown Error",
    ...error2.body
  };
  const status = get_status(error2);
  const message = get_message(error2);
  return await with_request_store({
    event,
    state: state2
  }, () => options2.hooks.handleError({
    error: error2,
    event,
    status,
    message
  })) ?? { message };
}
function redirect_response(status, location) {
  return new Response(void 0, {
    status,
    headers: { location }
  });
}
function clarify_devalue_error(event, error2) {
  if (error2.path) return `Data returned from \`load\` while rendering ${event.route.id} is not serializable: ${error2.message} (${error2.path}). If you need to serialize/deserialize custom types, use transport hooks: https://svelte.dev/docs/kit/hooks#transport.`;
  if (error2.path === "") return `Data returned from \`load\` while rendering ${event.route.id} is not a plain object`;
  return error2.message;
}
function serialize_uses(node) {
  const uses = {};
  if (node.uses && node.uses.dependencies.size > 0) uses.dependencies = Array.from(node.uses.dependencies);
  if (node.uses && node.uses.search_params.size > 0) uses.search_params = Array.from(node.uses.search_params);
  if (node.uses && node.uses.params.size > 0) uses.params = Array.from(node.uses.params);
  if (node.uses?.parent) uses.parent = 1;
  if (node.uses?.route) uses.route = 1;
  if (node.uses?.url) uses.url = 1;
  return uses;
}
function has_prerendered_path(manifest, pathname) {
  return manifest._.prerendered_routes.has(pathname) || pathname.at(-1) === "/" && manifest._.prerendered_routes.has(pathname.slice(0, -1));
}
function format_server_error(status, error2, event) {
  const formatted_text = `
\x1B[1;31m[${status}] ${event.request.method} ${event.url.pathname}\x1B[0m`;
  if (status === 404) return formatted_text;
  return `${formatted_text}
${error2.stack}`;
}
function get_node_type(node_id) {
  const filename = node_id?.split("/")?.at(-1);
  if (!filename) return "unknown";
  return filename.split(".").slice(0, -1).join(".");
}
function create_replacer(transport) {
  const replacer = (thing) => {
    for (const key2 in transport) {
      const encoded = transport[key2].encode(thing);
      if (encoded) return `app.decode('${key2}', ${devalue3.uneval(encoded, replacer)})`;
    }
  };
  return replacer;
}

// .netlify/server/index.js
init_internal2();
init_exports();
import { error, isRedirect, json as json2, text as text2 } from "@sveltejs/kit";
import { ActionFailure, HttpError as HttpError3, Redirect, SvelteKitError as SvelteKitError3 } from "@sveltejs/kit/internal";
import { merge_tracing, with_request_store as with_request_store2 } from "@sveltejs/kit/internal/server";
import * as set_cookie_parser2 from "set-cookie-parser";
import * as devalue4 from "devalue";
import { parse as parse$1, serialize } from "cookie";
function with_resolvers() {
  let resolve2;
  let reject;
  return {
    promise: new Promise((res, rej) => {
      resolve2 = res;
      reject = rej;
    }),
    resolve: resolve2,
    reject
  };
}
var NULL_BODY_STATUS = [
  101,
  103,
  204,
  205,
  304
];
var IN_WEBCONTAINER = !!globalThis.process?.versions?.webcontainer;
var s = JSON.stringify;
async function render_endpoint(event, event_state, mod, state2) {
  const method = event.request.method;
  let handler = mod[method] || mod.fallback;
  if (method === "HEAD" && !mod.HEAD && mod.GET) handler = mod.GET;
  if (!handler) return method_not_allowed(mod, method);
  const prerender = mod.prerender ?? state2.prerender_default;
  if (prerender && (mod.POST || mod.PATCH || mod.PUT || mod.DELETE)) throw new Error("Cannot prerender endpoints that have mutative methods");
  if (state2.prerendering && !state2.prerendering.inside_reroute && !prerender) {
    if (state2.depth > 0) throw new Error(`${event.route.id} is not prerenderable`);
    else return new Response(void 0, { status: 204 });
  }
  try {
    const response = await with_request_store2({
      event,
      state: event_state
    }, () => handler(event));
    if (!(response instanceof Response)) throw new Error(`Invalid response from route ${event.url.pathname}: handler should return a Response object`);
    if (state2.prerendering && (!state2.prerendering.inside_reroute || prerender)) {
      const cloned = new Response(response.clone().body, {
        status: response.status,
        statusText: response.statusText,
        headers: new Headers(response.headers)
      });
      cloned.headers.set("x-sveltekit-prerender", String(prerender));
      if (state2.prerendering.inside_reroute && prerender) {
        cloned.headers.set("x-sveltekit-routeid", encodeURI(event.route.id));
        state2.prerendering.dependencies.set(event.url.pathname, {
          response: cloned,
          body: null
        });
      } else return cloned;
    }
    return response;
  } catch (e) {
    if (e instanceof Redirect) return new Response(void 0, {
      status: e.status,
      headers: { location: e.location }
    });
    throw e;
  }
}
function is_endpoint_request(event) {
  const { method, headers: headers2 } = event.request;
  if (ENDPOINT_METHODS.includes(method) && !PAGE_METHODS.includes(method)) return true;
  if (method === "POST" && headers2.get("x-sveltekit-action") === "true") return false;
  const accept = event.request.headers.get("accept") ?? "*/*";
  return negotiate(accept, ["*", "text/html"]) !== "text/html";
}
function compact(arr) {
  return arr.filter(
    /** @returns {val is NonNullable<T>} */
    (val) => val != null
  );
}
var DATA_SUFFIX = "/__data.json";
var HTML_DATA_SUFFIX = ".html__data.json";
function has_data_suffix(pathname) {
  return pathname.endsWith(DATA_SUFFIX) || pathname.endsWith(HTML_DATA_SUFFIX);
}
function add_data_suffix(pathname) {
  if (pathname.endsWith(".html")) return pathname.replace(/\.html$/, HTML_DATA_SUFFIX);
  return pathname.replace(/\/$/, "") + DATA_SUFFIX;
}
function strip_data_suffix(pathname) {
  if (pathname.endsWith(HTML_DATA_SUFFIX)) return pathname.slice(0, -16) + ".html";
  return pathname.slice(0, -12);
}
var ROUTE_SUFFIX = "/__route.js";
function has_resolution_suffix(pathname) {
  return pathname.endsWith(ROUTE_SUFFIX);
}
function add_resolution_suffix(pathname) {
  return pathname.replace(/\/$/, "") + ROUTE_SUFFIX;
}
function strip_resolution_suffix(pathname) {
  return pathname.slice(0, -11);
}
var noop_span = {
  spanContext() {
    return noop_span_context;
  },
  setAttribute() {
    return this;
  },
  setAttributes() {
    return this;
  },
  addEvent() {
    return this;
  },
  setStatus() {
    return this;
  },
  updateName() {
    return this;
  },
  end() {
    return this;
  },
  isRecording() {
    return false;
  },
  recordException() {
    return this;
  },
  addLink() {
    return this;
  },
  addLinks() {
    return this;
  }
};
var noop_span_context = {
  traceId: "",
  spanId: "",
  traceFlags: 0
};
async function record_span({ name, attributes: attributes2, fn }) {
  return fn(noop_span);
}
function is_action_json_request(event) {
  return negotiate(event.request.headers.get("accept") ?? "*/*", ["application/json", "text/html"]) === "application/json" && event.request.method === "POST";
}
async function handle_action_json_request(event, event_state, options2, server) {
  const actions = server?.actions;
  if (!actions) {
    const no_actions_error = new SvelteKitError3(405, "Method Not Allowed", `POST method not allowed. No form actions exist for this page`);
    return action_json({
      type: "error",
      error: await handle_error_and_jsonify(event, event_state, options2, no_actions_error)
    }, {
      status: no_actions_error.status,
      headers: { allow: "GET" }
    });
  }
  check_named_default_separate(actions);
  try {
    const data = await call_action(event, event_state, actions);
    if (data instanceof ActionFailure) return action_json({
      type: "failure",
      status: data.status,
      data: stringify_action_response(data.data, event.route.id, options2.hooks.transport)
    });
    else return action_json({
      type: "success",
      status: data ? 200 : 204,
      data: stringify_action_response(data, event.route.id, options2.hooks.transport)
    });
  } catch (e) {
    const err = normalize_error(e);
    if (err instanceof Redirect) return action_json_redirect(err);
    return action_json({
      type: "error",
      error: await handle_error_and_jsonify(event, event_state, options2, check_incorrect_fail_use(err))
    }, { status: get_status(err) });
  }
}
function check_incorrect_fail_use(error2) {
  return error2 instanceof ActionFailure ? /* @__PURE__ */ new Error('Cannot "throw fail()". Use "return fail()"') : error2;
}
function action_json_redirect(redirect2) {
  return action_json({
    type: "redirect",
    status: redirect2.status,
    location: redirect2.location
  });
}
function action_json(data, init3) {
  return json2(data, init3);
}
function is_action_request(event) {
  return event.request.method === "POST";
}
async function handle_action_request(event, event_state, server) {
  const actions = server?.actions;
  if (!actions) {
    event.setHeaders({ allow: "GET" });
    return {
      type: "error",
      error: new SvelteKitError3(405, "Method Not Allowed", `POST method not allowed. No form actions exist for this page`)
    };
  }
  check_named_default_separate(actions);
  try {
    const data = await call_action(event, event_state, actions);
    if (data instanceof ActionFailure) return {
      type: "failure",
      status: data.status,
      data: data.data
    };
    else return {
      type: "success",
      status: 200,
      data
    };
  } catch (e) {
    const err = normalize_error(e);
    if (err instanceof Redirect) return {
      type: "redirect",
      status: err.status,
      location: err.location
    };
    return {
      type: "error",
      error: check_incorrect_fail_use(err)
    };
  }
}
function check_named_default_separate(actions) {
  if (actions.default && Object.keys(actions).length > 1) throw new Error("When using named actions, the default action cannot be used. See the docs for more info: https://svelte.dev/docs/kit/form-actions#named-actions");
}
async function call_action(event, event_state, actions) {
  const url = new URL(event.request.url);
  let name = "default";
  for (const param of url.searchParams) if (param[0].startsWith("/")) {
    name = param[0].slice(1);
    if (name === "default") throw new Error('Cannot use reserved action name "default"');
    break;
  }
  const action = actions[name];
  if (!action) throw new SvelteKitError3(404, "Not Found", `No action with name '${name}' found`);
  if (!is_form_content_type(event.request)) throw new SvelteKitError3(415, "Unsupported Media Type", `Form actions expect form-encoded data \u2014 received ${event.request.headers.get("content-type")}`);
  return record_span({
    name: "sveltekit.form_action",
    attributes: {
      "sveltekit.form_action.name": name,
      "http.route": event.route.id || "unknown"
    },
    fn: async (current2) => {
      const traced_event = merge_tracing(event, current2);
      const result = await with_request_store2({
        event: traced_event,
        state: event_state
      }, () => action(traced_event));
      if (result instanceof ActionFailure) current2.setAttributes({
        "sveltekit.form_action.result.type": "failure",
        "sveltekit.form_action.result.status": result.status
      });
      return result;
    }
  });
}
function uneval_action_response(data, route_id, transport) {
  const replacer = create_replacer(transport);
  return try_serialize(data, (value) => devalue4.uneval(value, replacer), route_id);
}
function stringify_action_response(data, route_id, transport) {
  const encoders = Object.fromEntries(Object.entries(transport).map(([key2, value]) => [key2, value.encode]));
  return try_serialize(data, (value) => devalue4.stringify(value, encoders), route_id);
}
function try_serialize(data, fn, route_id) {
  try {
    return fn(data);
  } catch (e) {
    const error2 = e;
    if (data instanceof Response) throw new Error(`Data returned from action inside ${route_id} is not serializable. Form actions need to return plain objects or fail(). E.g. return { success: true } or return fail(400, { message: "invalid" });`, { cause: e });
    if ("path" in error2) {
      let message = `Data returned from action inside ${route_id} is not serializable: ${error2.message}`;
      if (error2.path !== "") message += ` (data.${error2.path})`;
      throw new Error(message, { cause: e });
    }
    throw error2;
  }
}
function create_async_iterator() {
  let resolved = -1;
  let returned = -1;
  const deferred2 = [];
  return {
    iterate: (transform = (x) => x) => {
      return { [Symbol.asyncIterator]() {
        return { next: async () => {
          const next2 = deferred2[++returned];
          if (!next2) return {
            value: null,
            done: true
          };
          return {
            value: transform(await next2.promise),
            done: false
          };
        } };
      } };
    },
    add: (promise) => {
      const next2 = with_resolvers();
      next2.promise.catch(noop2);
      deferred2.push(next2);
      promise.then((value) => {
        deferred2[++resolved].resolve(value);
      }, (error2) => {
        deferred2[++resolved].reject(error2);
      });
    }
  };
}
function server_data_serializer(event, event_state, options2) {
  let promise_id = 1;
  let max_nodes = -1;
  const iterator = create_async_iterator();
  const global = get_global_name(options2);
  function get_replacer(index7) {
    return function replacer(thing) {
      if (typeof thing?.then === "function") {
        const id = promise_id++;
        const promise = thing.then(
          /** @param {any} data */
          (data) => ({ data })
        ).catch(
          /** @param {any} error */
          async (error2) => ({ error: await handle_error_and_jsonify(event, event_state, options2, error2) })
        ).then(
          /**
          * @param {{data: any; error: any}} result
          */
          async ({ data, error: error2 }) => {
            let str;
            try {
              str = devalue4.uneval(error2 ? [, error2] : [data], replacer);
            } catch {
              error2 = await handle_error_and_jsonify(event, event_state, options2, /* @__PURE__ */ new Error(`Failed to serialize promise while rendering ${event.route.id}`));
              str = devalue4.uneval([, error2], replacer);
            }
            return {
              index: index7,
              str: `${global}.resolve(${id}, ${str.includes("app.decode") ? `(app) => ${str}` : `() => ${str}`})`
            };
          }
        );
        iterator.add(promise);
        return `${global}.defer(${id})`;
      } else for (const key2 in options2.hooks.transport) {
        const encoded = options2.hooks.transport[key2].encode(thing);
        if (encoded) return `app.decode('${key2}', ${devalue4.uneval(encoded, replacer)})`;
      }
    };
  }
  const strings = [];
  return {
    set_max_nodes(i) {
      max_nodes = i;
    },
    add_node(i, node) {
      try {
        if (!node) {
          strings[i] = "null";
          return;
        }
        const payload2 = {
          type: "data",
          data: node.data,
          uses: serialize_uses(node)
        };
        if (node.slash) payload2.slash = node.slash;
        strings[i] = devalue4.uneval(payload2, get_replacer(i));
      } catch (e) {
        e.path = e.path.slice(1);
        throw new Error(clarify_devalue_error(event, e), { cause: e });
      }
    },
    get_data(csp) {
      const open = `<script${csp.script_needs_nonce ? ` nonce="${csp.nonce}"` : ""}>`;
      const close = `</script>
`;
      return {
        data: `[${compact(max_nodes > -1 ? strings.slice(0, max_nodes) : strings).join(",")}]`,
        chunks: promise_id > 1 ? iterator.iterate(({ index: index7, str }) => {
          if (max_nodes > -1 && index7 >= max_nodes) return "";
          return open + str + close;
        }) : null
      };
    }
  };
}
function server_data_serializer_json(event, event_state, options2) {
  let promise_id = 1;
  const iterator = create_async_iterator();
  const reducers = {
    ...Object.fromEntries(Object.entries(options2.hooks.transport).map(([key2, value]) => [key2, value.encode])),
    /** @param {any} thing */
    Promise: (thing) => {
      if (typeof thing?.then !== "function") return;
      const id = promise_id++;
      let key2 = "data";
      const promise = thing.catch(
        /** @param {any} e */
        async (e) => {
          key2 = "error";
          return handle_error_and_jsonify(event, event_state, options2, e);
        }
      ).then(
        /** @param {any} value */
        async (value) => {
          let str;
          try {
            str = devalue4.stringify(value, reducers);
          } catch {
            const error2 = await handle_error_and_jsonify(event, event_state, options2, /* @__PURE__ */ new Error(`Failed to serialize promise while rendering ${event.route.id}`));
            key2 = "error";
            str = devalue4.stringify(error2, reducers);
          }
          return `{"type":"chunk","id":${id},"${key2}":${str}}
`;
        }
      );
      iterator.add(promise);
      return id;
    }
  };
  const strings = [];
  return {
    add_node(i, node) {
      try {
        if (!node) {
          strings[i] = "null";
          return;
        }
        if (node.type === "error" || node.type === "skip") {
          strings[i] = JSON.stringify(node);
          return;
        }
        strings[i] = `{"type":"data","data":${devalue4.stringify(node.data, reducers)},"uses":${JSON.stringify(serialize_uses(node))}${node.slash ? `,"slash":${JSON.stringify(node.slash)}` : ""}}`;
      } catch (e) {
        e.path = "data" + e.path;
        throw new Error(clarify_devalue_error(event, e), { cause: e });
      }
    },
    get_data() {
      return {
        data: `{"type":"data","nodes":[${strings.join(",")}]}
`,
        chunks: promise_id > 1 ? iterator.iterate() : null
      };
    }
  };
}
async function load_server_data({ event, event_state, state: state2, node, parent }) {
  if (!node?.server) return null;
  let is_tracking = true;
  const uses = {
    dependencies: /* @__PURE__ */ new Set(),
    params: /* @__PURE__ */ new Set(),
    parent: false,
    route: false,
    url: false,
    search_params: /* @__PURE__ */ new Set()
  };
  const load = node.server.load;
  const slash = node.server.trailingSlash;
  if (!load) return {
    type: "data",
    data: null,
    uses,
    slash
  };
  const url = make_trackable(event.url, () => {
    if (is_tracking) uses.url = true;
  }, (param) => {
    if (is_tracking) uses.search_params.add(param);
  });
  if (state2.prerendering) disable_search(url);
  return {
    type: "data",
    data: await record_span({
      name: "sveltekit.load",
      attributes: {
        "sveltekit.load.node_id": node.server_id || "unknown",
        "sveltekit.load.node_type": get_node_type(node.server_id),
        "sveltekit.load.environment": "server",
        "http.route": event.route.id || "unknown"
      },
      fn: async (current2) => {
        const traced_event = merge_tracing(event, current2);
        return await with_request_store2({
          event: traced_event,
          state: event_state
        }, () => load.call(null, {
          ...traced_event,
          fetch: (info, init3) => {
            new URL(info instanceof Request ? info.url : info, event.url);
            return event.fetch(info, init3);
          },
          /** @param {string[]} deps */
          depends: (...deps) => {
            for (const dep of deps) {
              const { href } = new URL(dep, event.url);
              uses.dependencies.add(href);
            }
          },
          params: new Proxy(event.params, { get: (target, key2) => {
            if (is_tracking) uses.params.add(key2);
            return target[key2];
          } }),
          parent: async () => {
            if (is_tracking) uses.parent = true;
            return parent();
          },
          route: new Proxy(event.route, { get: (target, key2) => {
            if (is_tracking) uses.route = true;
            return target[key2];
          } }),
          url,
          untrack(fn) {
            is_tracking = false;
            try {
              return fn();
            } finally {
              is_tracking = true;
            }
          }
        }));
      }
    }) ?? null,
    uses,
    slash
  };
}
async function load_data({ event, event_state, fetched, node, parent, server_data_promise, state: state2, resolve_opts, csr }) {
  const server_data_node = await server_data_promise;
  const load = node?.universal?.load;
  if (!load) return server_data_node?.data ?? null;
  return await record_span({
    name: "sveltekit.load",
    attributes: {
      "sveltekit.load.node_id": node.universal_id || "unknown",
      "sveltekit.load.node_type": get_node_type(node.universal_id),
      "sveltekit.load.environment": "server",
      "http.route": event.route.id || "unknown"
    },
    fn: async (current2) => {
      const traced_event = merge_tracing(event, current2);
      const child_state = {
        ...event_state,
        is_in_universal_load: true
      };
      return await with_request_store2({
        event: traced_event,
        state: child_state
      }, () => load.call(null, {
        url: event.url,
        params: event.params,
        data: server_data_node?.data ?? null,
        route: event.route,
        fetch: create_universal_fetch(event, state2, fetched, csr, resolve_opts),
        setHeaders: event.setHeaders,
        depends: noop2,
        parent,
        untrack: (fn) => fn(),
        tracing: traced_event.tracing
      }));
    }
  }) ?? null;
}
function create_universal_fetch(event, state2, fetched, csr, resolve_opts) {
  const universal_fetch = async (input, init3) => {
    const cloned_body = input instanceof Request && input.body ? input.clone().body : null;
    const cloned_headers = input instanceof Request && [...input.headers].length ? new Headers(input.headers) : init3?.headers;
    let response = await event.fetch(input, init3);
    const url = new URL(input instanceof Request ? input.url : input, event.url);
    const same_origin = url.origin === event.url.origin;
    let dependency;
    if (same_origin) {
      if (state2.prerendering) {
        dependency = {
          response,
          body: null
        };
        state2.prerendering.dependencies.set(url.pathname, dependency);
      }
    } else if (url.protocol === "https:" || url.protocol === "http:") {
      if ((input instanceof Request ? input.mode : init3?.mode ?? "cors") === "no-cors") response = new Response("", {
        status: response.status,
        statusText: response.statusText,
        headers: response.headers
      });
      else {
        const acao = response.headers.get("access-control-allow-origin");
        if (!acao || acao !== event.url.origin && acao !== "*") throw new Error(`CORS error: ${acao ? "Incorrect" : "No"} 'Access-Control-Allow-Origin' header is present on the requested resource`);
      }
    }
    let teed_body;
    const proxy2 = new Proxy(response, { get(response2, key2, receiver) {
      async function push_fetched(body, is_b64) {
        const status_number = Number(response2.status);
        if (isNaN(status_number)) throw new Error(`response.status is not a number. value: "${response2.status}" type: ${typeof response2.status}`);
        fetched.push({
          url: same_origin ? url.href.slice(event.url.origin.length) : url.href,
          method: event.request.method,
          request_body: input instanceof Request && cloned_body ? await stream_to_string(cloned_body) : init3?.body,
          request_headers: cloned_headers,
          response_body: body,
          response: response2,
          is_b64
        });
      }
      if (key2 === "body") {
        if (response2.body === null) return null;
        if (teed_body) return teed_body;
        const [a, b] = response2.body.tee();
        (async () => {
          let result = /* @__PURE__ */ new Uint8Array();
          for await (const chunk of a) {
            const combined = new Uint8Array(result.length + chunk.length);
            combined.set(result, 0);
            combined.set(chunk, result.length);
            result = combined;
          }
          if (dependency) dependency.body = new Uint8Array(result);
          push_fetched(base64_encode2(result), true);
        })().catch(noop2);
        return teed_body = b;
      }
      if (key2 === "arrayBuffer") return async () => {
        const buffer2 = await response2.arrayBuffer();
        const bytes = new Uint8Array(buffer2);
        if (dependency) dependency.body = bytes;
        if (buffer2 instanceof ArrayBuffer) await push_fetched(base64_encode2(bytes), true);
        return buffer2;
      };
      async function text3() {
        const body = await response2.text();
        if (body === "" && NULL_BODY_STATUS.includes(response2.status)) {
          await push_fetched(void 0, false);
          return;
        }
        if (!body || typeof body === "string") await push_fetched(body, false);
        if (dependency) dependency.body = body;
        return body;
      }
      if (key2 === "text") return text3;
      if (key2 === "json") return async () => {
        const body = await text3();
        return body ? JSON.parse(body) : void 0;
      };
      const value = Reflect.get(response2, key2, response2);
      if (value instanceof Function) return Object.defineProperties(
        /**
        * @this {any}
        */
        function() {
          return Reflect.apply(value, this === receiver ? response2 : this, arguments);
        },
        {
          name: { value: value.name },
          length: { value: value.length }
        }
      );
      return value;
    } });
    if (csr) {
      const get2 = response.headers.get;
      response.headers.get = (key2) => {
        const lower = key2.toLowerCase();
        const value = get2.call(response.headers, lower);
        if (value && !lower.startsWith("x-sveltekit-")) {
          if (!resolve_opts.filterSerializedResponseHeaders(lower, value)) throw new Error(`Failed to get response header "${lower}" \u2014 it must be included by the \`filterSerializedResponseHeaders\` option: https://svelte.dev/docs/kit/hooks#handle (at ${event.route.id})`);
        }
        return value;
      };
    }
    return proxy2;
  };
  return (input, init3) => {
    const response = universal_fetch(input, init3);
    response.catch(noop2);
    return response;
  };
}
async function stream_to_string(stream) {
  let result = "";
  const reader = stream.getReader();
  const decoder2 = new TextDecoder();
  while (true) {
    const { done, value } = await reader.read();
    if (done) {
      result += decoder2.decode();
      break;
    }
    result += decoder2.decode(value, { stream: true });
  }
  return result;
}
var replacements2 = {
  "<": "\\u003C",
  "\u2028": "\\u2028",
  "\u2029": "\\u2029"
};
var pattern = new RegExp(`[${Object.keys(replacements2).join("")}]`, "g");
function serialize_data(fetched, filter, prerendering = false) {
  const headers2 = {};
  let cache_control = null;
  let age = null;
  let varyAny = false;
  for (const [key2, value] of fetched.response.headers) {
    if (filter(key2, value)) headers2[key2] = value;
    if (key2 === "cache-control") cache_control = value;
    else if (key2 === "age") age = value;
    else if (key2 === "vary" && value.trim() === "*") varyAny = true;
  }
  const payload2 = {
    status: fetched.response.status,
    statusText: fetched.response.statusText,
    headers: headers2,
    body: fetched.response_body
  };
  const safe_payload = JSON.stringify(payload2).replace(pattern, (match) => replacements2[match]);
  const attrs = [
    'type="application/json"',
    "data-sveltekit-fetched",
    `data-url="${escape_html2(fetched.url, true)}"`
  ];
  if (fetched.is_b64) attrs.push("data-b64");
  if (fetched.request_headers || fetched.request_body) {
    const values = [];
    if (fetched.request_headers) values.push([...new Headers(fetched.request_headers)].join(","));
    if (fetched.request_body) values.push(fetched.request_body);
    attrs.push(`data-hash="${hash(...values)}"`);
  }
  if (!prerendering && fetched.method === "GET" && cache_control && !varyAny) {
    const match = /s-maxage=(\d+)/g.exec(cache_control) ?? /max-age=(\d+)/g.exec(cache_control);
    if (match) {
      const ttl = +match[1] - +(age ?? "0");
      attrs.push(`data-ttl="${ttl}"`);
    }
  }
  return `<script ${attrs.join(" ")}>${safe_payload}</script>`;
}
function sha2562(data) {
  if (!key[0]) precompute();
  const out = init.slice(0);
  const array2 = encode2(data);
  for (let i = 0; i < array2.length; i += 16) {
    const w = array2.subarray(i, i + 16);
    let tmp;
    let a;
    let b;
    let out0 = out[0];
    let out1 = out[1];
    let out2 = out[2];
    let out3 = out[3];
    let out4 = out[4];
    let out5 = out[5];
    let out6 = out[6];
    let out7 = out[7];
    for (let i2 = 0; i2 < 64; i2++) {
      if (i2 < 16) tmp = w[i2];
      else {
        a = w[i2 + 1 & 15];
        b = w[i2 + 14 & 15];
        tmp = w[i2 & 15] = (a >>> 7 ^ a >>> 18 ^ a >>> 3 ^ a << 25 ^ a << 14) + (b >>> 17 ^ b >>> 19 ^ b >>> 10 ^ b << 15 ^ b << 13) + w[i2 & 15] + w[i2 + 9 & 15] | 0;
      }
      tmp = tmp + out7 + (out4 >>> 6 ^ out4 >>> 11 ^ out4 >>> 25 ^ out4 << 26 ^ out4 << 21 ^ out4 << 7) + (out6 ^ out4 & (out5 ^ out6)) + key[i2];
      out7 = out6;
      out6 = out5;
      out5 = out4;
      out4 = out3 + tmp | 0;
      out3 = out2;
      out2 = out1;
      out1 = out0;
      out0 = tmp + (out1 & out2 ^ out3 & (out1 ^ out2)) + (out1 >>> 2 ^ out1 >>> 13 ^ out1 >>> 22 ^ out1 << 30 ^ out1 << 19 ^ out1 << 10) | 0;
    }
    out[0] = out[0] + out0 | 0;
    out[1] = out[1] + out1 | 0;
    out[2] = out[2] + out2 | 0;
    out[3] = out[3] + out3 | 0;
    out[4] = out[4] + out4 | 0;
    out[5] = out[5] + out5 | 0;
    out[6] = out[6] + out6 | 0;
    out[7] = out[7] + out7 | 0;
  }
  const bytes = new Uint8Array(out.buffer);
  reverse_endianness(bytes);
  return btoa(String.fromCharCode(...bytes));
}
var init = /* @__PURE__ */ new Uint32Array(8);
var key = /* @__PURE__ */ new Uint32Array(64);
function precompute() {
  function frac(x) {
    return (x - Math.floor(x)) * 4294967296;
  }
  let prime = 2;
  for (let i = 0; i < 64; prime++) {
    let is_prime = true;
    for (let factor = 2; factor * factor <= prime; factor++) if (prime % factor === 0) {
      is_prime = false;
      break;
    }
    if (is_prime) {
      if (i < 8) init[i] = frac(prime ** (1 / 2));
      key[i] = frac(prime ** (1 / 3));
      i++;
    }
  }
}
function reverse_endianness(bytes) {
  for (let i = 0; i < bytes.length; i += 4) {
    const a = bytes[i + 0];
    const b = bytes[i + 1];
    const c = bytes[i + 2];
    const d = bytes[i + 3];
    bytes[i + 0] = d;
    bytes[i + 1] = c;
    bytes[i + 2] = b;
    bytes[i + 3] = a;
  }
}
function encode2(str) {
  const encoded = text_encoder2.encode(str);
  const length = encoded.length * 8;
  const size = 512 * Math.ceil((length + 65) / 512);
  const bytes = new Uint8Array(size / 8);
  bytes.set(encoded);
  bytes[encoded.length] = 128;
  reverse_endianness(bytes);
  const words = new Uint32Array(bytes.buffer);
  words[words.length - 2] = Math.floor(length / 4294967296);
  words[words.length - 1] = length;
  return words;
}
var array = /* @__PURE__ */ new Uint8Array(16);
function generate_nonce() {
  crypto.getRandomValues(array);
  return btoa(String.fromCharCode(...array));
}
var quoted = /* @__PURE__ */ new Set([
  "self",
  "unsafe-eval",
  "unsafe-hashes",
  "unsafe-inline",
  "none",
  "strict-dynamic",
  "report-sample",
  "wasm-unsafe-eval",
  "script"
]);
var crypto_pattern = /^(nonce|sha\d\d\d)-/;
var BaseProvider = class {
  /** @type {boolean} */
  #use_hashes;
  /** @type {boolean} */
  #script_needs_csp;
  /** @type {boolean} */
  #script_src_needs_csp;
  /** @type {boolean} */
  #script_src_elem_needs_csp;
  /** @type {boolean} */
  #style_needs_csp;
  /** @type {boolean} */
  #style_src_needs_csp;
  /** @type {boolean} */
  #style_src_attr_needs_csp;
  /** @type {boolean} */
  #style_src_elem_needs_csp;
  /** @type {import('types').CspDirectives} */
  #directives;
  /** @type {Set<import('types').Csp.Source>} */
  #script_src;
  /** @type {Set<import('types').Csp.Source>} */
  #script_src_elem;
  /** @type {Set<import('types').Csp.Source>} */
  #style_src;
  /** @type {Set<import('types').Csp.Source>} */
  #style_src_attr;
  /** @type {Set<import('types').Csp.Source>} */
  #style_src_elem;
  /** @type {boolean} */
  script_needs_nonce;
  /** @type {boolean} */
  style_needs_nonce;
  /** @type {boolean} */
  script_needs_hash;
  /** @type {string} */
  #nonce;
  /**
  * @param {boolean} use_hashes
  * @param {import('types').CspDirectives} directives
  * @param {string} nonce
  */
  constructor(use_hashes, directives, nonce) {
    this.#use_hashes = use_hashes;
    this.#directives = directives;
    const d = this.#directives;
    this.#script_src = /* @__PURE__ */ new Set();
    this.#script_src_elem = /* @__PURE__ */ new Set();
    this.#style_src = /* @__PURE__ */ new Set();
    this.#style_src_attr = /* @__PURE__ */ new Set();
    this.#style_src_elem = /* @__PURE__ */ new Set();
    const effective_script_src = d["script-src"] || d["default-src"];
    const script_src_elem = d["script-src-elem"];
    const effective_style_src = d["style-src"] || d["default-src"];
    const style_src_attr = d["style-src-attr"];
    const style_src_elem = d["style-src-elem"];
    const style_needs_csp = (directive) => !!directive && !directive.some((value) => value === "unsafe-inline");
    const script_needs_csp = (directive) => !!directive && (!directive.some((value) => value === "unsafe-inline") || directive.some((value) => value === "strict-dynamic"));
    this.#script_src_needs_csp = script_needs_csp(effective_script_src);
    this.#script_src_elem_needs_csp = script_needs_csp(script_src_elem);
    this.#style_src_needs_csp = style_needs_csp(effective_style_src);
    this.#style_src_attr_needs_csp = style_needs_csp(style_src_attr);
    this.#style_src_elem_needs_csp = style_needs_csp(style_src_elem);
    this.#script_needs_csp = this.#script_src_needs_csp || this.#script_src_elem_needs_csp;
    this.#style_needs_csp = this.#style_src_needs_csp || this.#style_src_attr_needs_csp || this.#style_src_elem_needs_csp;
    this.script_needs_nonce = this.#script_needs_csp && !this.#use_hashes;
    this.style_needs_nonce = this.#style_needs_csp && !this.#use_hashes;
    this.script_needs_hash = this.#script_needs_csp && this.#use_hashes;
    this.#nonce = nonce;
  }
  /** @param {string} content */
  add_script(content) {
    if (!this.#script_needs_csp) return;
    const source2 = this.#use_hashes ? `sha256-${sha2562(content)}` : `nonce-${this.#nonce}`;
    if (this.#script_src_needs_csp) this.#script_src.add(source2);
    if (this.#script_src_elem_needs_csp) this.#script_src_elem.add(source2);
  }
  /** @param {`sha256-${string}`[]} hashes */
  add_script_hashes(hashes) {
    for (const hash2 of hashes) {
      if (this.#script_src_needs_csp) this.#script_src.add(hash2);
      if (this.#script_src_elem_needs_csp) this.#script_src_elem.add(hash2);
    }
  }
  /** @param {string} content */
  add_style(content) {
    if (!this.#style_needs_csp) return;
    const source2 = this.#use_hashes ? `sha256-${sha2562(content)}` : `nonce-${this.#nonce}`;
    if (this.#style_src_needs_csp) this.#style_src.add(source2);
    if (this.#style_src_attr_needs_csp) this.#style_src_attr.add(source2);
    if (this.#style_src_elem_needs_csp) {
      const sha256_empty_comment_hash = "sha256-9OlNO0DNEeaVzHL4RZwCLsBHA8WBQ8toBp/4F5XV2nc=";
      const d = this.#directives;
      if (d["style-src-elem"] && !d["style-src-elem"].includes(sha256_empty_comment_hash) && !this.#style_src_elem.has(sha256_empty_comment_hash)) this.#style_src_elem.add(sha256_empty_comment_hash);
      if (source2 !== sha256_empty_comment_hash) this.#style_src_elem.add(source2);
    }
  }
  /**
  * @param {boolean} [is_meta]
  */
  get_header(is_meta = false) {
    const header = [];
    const directives = { ...this.#directives };
    if (this.#style_src.size > 0) directives["style-src"] = [...directives["style-src"] || directives["default-src"] || [], ...this.#style_src];
    if (this.#style_src_attr.size > 0) directives["style-src-attr"] = [...directives["style-src-attr"] || [], ...this.#style_src_attr];
    if (this.#style_src_elem.size > 0) directives["style-src-elem"] = [...directives["style-src-elem"] || [], ...this.#style_src_elem];
    if (this.#script_src.size > 0) directives["script-src"] = [...directives["script-src"] || directives["default-src"] || [], ...this.#script_src];
    if (this.#script_src_elem.size > 0) directives["script-src-elem"] = [...directives["script-src-elem"] || [], ...this.#script_src_elem];
    for (const key2 in directives) {
      if (is_meta && (key2 === "frame-ancestors" || key2 === "report-uri" || key2 === "sandbox")) continue;
      const value = directives[key2];
      if (!value) continue;
      const directive = [key2];
      if (Array.isArray(value)) value.forEach((value2) => {
        if (quoted.has(value2) || crypto_pattern.test(value2)) directive.push(`'${value2}'`);
        else directive.push(value2);
      });
      header.push(directive.join(" "));
    }
    return header.join("; ");
  }
};
var CspProvider = class extends BaseProvider {
  get_meta() {
    const content = this.get_header(true);
    if (!content) return;
    return `<meta http-equiv="content-security-policy" content="${escape_html2(content, true)}">`;
  }
};
var CspReportOnlyProvider = class extends BaseProvider {
  /**
  * @param {boolean} use_hashes
  * @param {import('types').CspDirectives} directives
  * @param {string} nonce
  */
  constructor(use_hashes, directives, nonce) {
    super(use_hashes, directives, nonce);
    if (Object.values(directives).filter((v) => !!v).length > 0) {
      const has_report_to = directives["report-to"]?.length ?? false;
      const has_report_uri = directives["report-uri"]?.length ?? false;
      if (!has_report_to && !has_report_uri) throw Error("`content-security-policy-report-only` must be specified with either the `report-to` or `report-uri` directives, or both");
    }
  }
};
var Csp = class {
  /** @readonly */
  nonce = generate_nonce();
  /** @type {CspProvider} */
  csp_provider;
  /** @type {CspReportOnlyProvider} */
  report_only_provider;
  /**
  * @param {import('./types.js').CspConfig} config
  * @param {import('./types.js').CspOpts} opts
  */
  constructor({ mode, directives, reportOnly }, { prerender }) {
    const use_hashes = mode === "hash" || mode === "auto" && prerender;
    this.csp_provider = new CspProvider(use_hashes, directives, this.nonce);
    this.report_only_provider = new CspReportOnlyProvider(use_hashes, reportOnly, this.nonce);
  }
  get script_needs_hash() {
    return this.csp_provider.script_needs_hash || this.report_only_provider.script_needs_hash;
  }
  get script_needs_nonce() {
    return this.csp_provider.script_needs_nonce || this.report_only_provider.script_needs_nonce;
  }
  get style_needs_nonce() {
    return this.csp_provider.style_needs_nonce || this.report_only_provider.style_needs_nonce;
  }
  /** @param {string} content */
  add_script(content) {
    this.csp_provider.add_script(content);
    this.report_only_provider.add_script(content);
  }
  /** @param {`sha256-${string}`[]} hashes */
  add_script_hashes(hashes) {
    this.csp_provider.add_script_hashes(hashes);
    this.report_only_provider.add_script_hashes(hashes);
  }
  /** @param {string} content */
  add_style(content) {
    this.csp_provider.add_style(content);
    this.report_only_provider.add_style(content);
  }
};
function generate_route_object(route, url, client) {
  const { errors, layouts, leaf } = route;
  const nodes = [
    ...errors,
    ...layouts.map((l) => l?.[1]),
    leaf[1]
  ].filter((n) => typeof n === "number").map((n) => `'${n}': () => ${create_client_import(client.nodes?.[n], url)}`).join(",\n		");
  return [
    `{
	id: ${s(route.id)}`,
    `errors: ${s(route.errors)}`,
    `layouts: ${s(route.layouts)}`,
    `leaf: ${s(route.leaf)}`,
    `nodes: {
		${nodes}
	}
}`
  ].join(",\n	");
}
function create_client_import(import_path, url) {
  if (!import_path) return "Promise.resolve({})";
  if (import_path[0] === "/") return `import('${import_path}')`;
  if (assets !== "") return `import('${assets}/${import_path}')`;
  let path = get_relative_path(url.pathname, `${base}/${import_path}`);
  if (path[0] !== ".") path = `./${path}`;
  return `import('${path}')`;
}
async function resolve_route(resolved_path, url, manifest) {
  if (!manifest._.client?.routes) return text2("Server-side route resolution disabled", { status: 400 });
  const matchers = await manifest._.matchers();
  const result = find_route(resolved_path, manifest._.client.routes, matchers);
  return create_server_routing_response(result?.route ?? null, result?.params ?? {}, url, manifest._.client).response;
}
function create_server_routing_response(route, params, url, client) {
  const headers2 = new Headers({ "content-type": "application/javascript; charset=utf-8" });
  if (route) {
    const csr_route = generate_route_object(route, url, client);
    const body = `${create_css_import(route, url, client)}
export const route = ${csr_route}; export const params = ${JSON.stringify(params)};`;
    return {
      response: text2(body, { headers: headers2 }),
      body
    };
  } else return {
    response: text2("", { headers: headers2 }),
    body: ""
  };
}
function create_css_import(route, url, client) {
  const { errors, layouts, leaf } = route;
  let css = "";
  for (const node of [
    ...errors,
    ...layouts.map((l) => l?.[1]),
    leaf[1]
  ]) {
    if (typeof node !== "number") continue;
    const node_css = client.css?.[node];
    for (const css_path of node_css ?? []) css += `'${assets || base}/${css_path}',`;
  }
  if (!css) return "";
  return `${create_client_import(client.start, url)}.then(x => x.load_css([${css}]));`;
}
async function handle_remote_call(event, state2, options2, manifest, id) {
  return record_span({
    name: "sveltekit.remote.call",
    attributes: { "sveltekit.remote.call.id": id },
    fn: (current2) => {
      const traced_event = merge_tracing(event, current2);
      return with_request_store2({
        event: traced_event,
        state: state2
      }, () => handle_remote_call_internal(traced_event, state2, options2, manifest, id));
    }
  });
}
async function handle_remote_call_internal(event, state2, options2, manifest, id) {
  const [hash2, name, additional_args] = id.split("/");
  const remotes = manifest._.remotes;
  if (!remotes[hash2]) error(404);
  const fn = (await remotes[hash2]()).default[name];
  if (!fn) error(404);
  const internals = fn.__;
  const transport = options2.hooks.transport;
  event.tracing.current.setAttributes({
    "sveltekit.remote.call.type": internals.type,
    "sveltekit.remote.call.name": internals.name
  });
  const headers2 = state2.prerendering ? void 0 : { "cache-control": "private, no-store" };
  try {
    const data = {};
    switch (internals.type) {
      case "query_live": {
        let send2 = function(controller, payload3) {
          controller.enqueue(encoder.encode("data: " + JSON.stringify(payload3) + "\n\n"));
        };
        var send = send2;
        if (event.request.method !== "GET") throw new SvelteKitError3(405, "Method Not Allowed", `\`query.live\` functions must be invoked via GET request, not ${event.request.method}`);
        const payload2 = new URL(event.request.url).searchParams.get("payload");
        const generator = internals.run(event, state2, parse_remote_arg(payload2, transport));
        const encoder = new TextEncoder();
        let closed = false;
        let result = void 0;
        async function cancel() {
          if (closed) return;
          closed = true;
          await generator.return(void 0);
        }
        event.request.signal.addEventListener("abort", cancel, { once: true });
        return new Response(new ReadableStream({
          async pull(controller) {
            if (event.request.signal.aborted) {
              await cancel();
              controller.close();
              return;
            }
            try {
              while (true) {
                const { value, done } = await generator.next();
                if (done) {
                  await cancel();
                  controller.close();
                  return;
                }
                if (result !== (result = stringify3(value, transport))) {
                  send2(controller, {
                    type: "result",
                    result
                  });
                  return;
                }
              }
            } catch (error2) {
              if (!event.request.signal.aborted) {
                if (error2 instanceof Redirect) send2(controller, {
                  type: "redirect",
                  location: error2.location
                });
                else {
                  const status = error2 instanceof HttpError3 || error2 instanceof SvelteKitError3 ? error2.status : 500;
                  send2(controller, {
                    type: "error",
                    error: await handle_error_and_jsonify(event, state2, options2, error2),
                    status
                  });
                }
              }
              await cancel();
              controller.close();
            }
          },
          cancel
        }), { headers: {
          "cache-control": "private, no-store",
          "content-type": "text/event-stream"
        } });
      }
      case "query_batch": {
        if (event.request.method !== "POST") throw new SvelteKitError3(405, "Method Not Allowed", `\`query.batch\` functions must be invoked via POST request, not ${event.request.method}`);
        const { payloads } = await event.request.json();
        const args = await Promise.all(payloads.map((payload2) => parse_remote_arg(payload2, transport)));
        data._ = await with_request_store2({
          event,
          state: state2
        }, () => internals.run(args, options2));
        break;
      }
      case "form": {
        if (event.request.method !== "POST") throw new SvelteKitError3(405, "Method Not Allowed", `\`form\` functions must be invoked via POST request, not ${event.request.method}`);
        if (!is_form_content_type(event.request)) throw new SvelteKitError3(415, "Unsupported Media Type", `\`form\` functions expect form-encoded data \u2014 received ${event.request.headers.get("content-type")}`);
        const { data: input, meta, form_data } = await deserialize_binary_form(event.request);
        state2.remote.requested = create_requested_map(meta.remote_refreshes);
        if (additional_args && !("id" in input)) input.id = JSON.parse(decodeURIComponent(additional_args));
        const fn2 = internals.fn;
        data._ = await with_request_store2({
          event,
          state: {
            ...state2,
            is_in_remote_form_or_command: true
          }
        }, () => fn2(input, meta, form_data));
        if (data._.issues) return json2({
          type: "result",
          data: stringify3(data, transport)
        }, { headers: headers2 });
        break;
      }
      case "command": {
        const { payload: payload2, refreshes } = await event.request.json();
        state2.remote.requested = create_requested_map(refreshes);
        const arg = parse_remote_arg(payload2, transport);
        data._ = await with_request_store2({
          event,
          state: {
            ...state2,
            is_in_remote_form_or_command: true
          }
        }, () => fn(arg));
        break;
      }
      case "prerender":
        data._ = await with_request_store2({
          event,
          state: state2
        }, () => fn(parse_remote_arg(additional_args, transport)));
        break;
      case "query": {
        const payload2 = new URL(event.request.url).searchParams.get("payload");
        data._ = await with_request_store2({
          event,
          state: state2
        }, () => fn(parse_remote_arg(payload2, transport)));
        break;
      }
    }
    await collect_remote_data(data, event, state2, options2);
    return json2({
      type: "result",
      data: stringify3(data, transport)
    }, { headers: headers2 });
  } catch (error2) {
    if (error2 instanceof Redirect) {
      const data = await collect_remote_data({ redirect: error2.location }, event, state2, options2);
      return json2({
        type: "result",
        data: stringify3(data, transport)
      }, { headers: headers2 });
    }
    const status = error2 instanceof HttpError3 || error2 instanceof SvelteKitError3 ? error2.status : 500;
    return json2({
      type: "error",
      error: await handle_error_and_jsonify(event, state2, options2, error2),
      status
    }, {
      status: state2.prerendering ? status : void 0,
      headers: { "cache-control": "private, no-store" }
    });
  }
}
async function collect_remote_data(data, event, state2, options2) {
  async function convert_error(error2) {
    return [error2 instanceof HttpError3 || error2 instanceof SvelteKitError3 ? error2.status : 500, await handle_error_and_jsonify(event, state2, options2, error2)];
  }
  const promises = [];
  if (state2.remote.explicit) for (const [remote_key, { internals, promise }] of state2.remote.explicit) {
    data.r = true;
    const type = internals.type === "query_live" ? "l" : internals.type[0];
    await promise.then((v) => {
      ((data[type] ??= {})[remote_key] ??= {}).v = v;
    }, async (e) => {
      if (e instanceof Redirect) return;
      ((data[type] ??= {})[remote_key] ??= {}).e = await convert_error(e);
    });
  }
  await Promise.all(promises);
  if (state2.remote.implicit) for (const [internals, record] of state2.remote.implicit) {
    if (!internals.id) continue;
    for (const key2 in record) {
      const remote_key = internals.type === "form" ? key2 : create_remote_key(internals.id, key2);
      const type = internals.type === "query_live" ? "l" : internals.type[0];
      const promise = state2.remote.data?.get(internals)?.[key2] ?? record[key2]();
      let resolved = true;
      await Promise.race([Promise.resolve(promise).then((v) => {
        if (resolved) ((data[type] ??= {})[remote_key] ??= {}).v = v;
      }, (e) => {
        if (e instanceof Redirect) return;
        if (resolved) promises.push(convert_error(e).then((e2) => {
          ((data[type] ??= {})[remote_key] ??= {}).e = e2;
        }));
      }), Promise.resolve().then(() => resolved = false)]);
    }
  }
  await Promise.all(promises);
  return data;
}
function create_requested_map(refreshes) {
  const requested = /* @__PURE__ */ new Map();
  for (const key2 of refreshes ?? []) {
    const parts = split_remote_key(key2);
    const existing = requested.get(parts.id);
    if (existing) existing.push(parts.payload);
    else requested.set(parts.id, [parts.payload]);
  }
  return requested;
}
async function handle_remote_form_post(event, state2, manifest, id) {
  return record_span({
    name: "sveltekit.remote.form.post",
    attributes: { "sveltekit.remote.form.post.id": id },
    fn: (current2) => {
      const traced_event = merge_tracing(event, current2);
      return with_request_store2({
        event: traced_event,
        state: state2
      }, () => handle_remote_form_post_internal(traced_event, state2, manifest, id));
    }
  });
}
async function handle_remote_form_post_internal(event, state2, manifest, id) {
  const [hash2, name, ...rest] = id.split("/");
  const action_id = rest.join("/");
  let form = (await manifest._.remotes[hash2]?.())?.default[name];
  if (!form) {
    event.setHeaders({ allow: "GET" });
    return {
      type: "error",
      error: new SvelteKitError3(405, "Method Not Allowed", `POST method not allowed. No form actions exist for this page`)
    };
  }
  if (action_id) form = with_request_store2({
    event,
    state: state2
  }, () => form.for(JSON.parse(action_id)));
  try {
    const fn = form.__.fn;
    const { data, meta, form_data } = await deserialize_binary_form(event.request);
    if (action_id && !("id" in data)) data.id = JSON.parse(decodeURIComponent(action_id));
    await with_request_store2({
      event,
      state: {
        ...state2,
        is_in_remote_form_or_command: true
      }
    }, () => fn(data, meta, form_data));
    return {
      type: "success",
      status: 200
    };
  } catch (e) {
    const err = normalize_error(e);
    if (err instanceof Redirect) return {
      type: "redirect",
      status: err.status,
      location: err.location
    };
    return {
      type: "error",
      error: check_incorrect_fail_use(err)
    };
  }
}
function get_remote_id(url) {
  return url.pathname.startsWith(`${base}/_app/remote/`) && url.pathname.replace(`${base}/_app/remote/`, "");
}
function get_remote_action(url) {
  return url.searchParams.get("/remote");
}
var updated = {
  ...readable(false),
  check: () => false
};
async function render_response({ branch: branch2, fetched, options: options2, manifest, state: state2, page_config, status, error: error2 = null, event, event_state, resolve_opts, action_result, data_serializer, error_components }) {
  if (state2.prerendering) {
    if (options2.csp.mode === "nonce") throw new Error('Cannot use prerendering if config.kit.csp.mode === "nonce"');
    if (options2.app_template_contains_nonce) throw new Error("Cannot use prerendering if page template contains %sveltekit.nonce%");
  }
  const { client } = manifest._;
  const modulepreloads = new Set(client?.imports);
  const stylesheets7 = new Set(client?.stylesheets);
  const fonts7 = new Set(client?.fonts);
  const link_headers = /* @__PURE__ */ new Set();
  const inline_styles = /* @__PURE__ */ new Map();
  let rendered;
  const form_value = action_result?.type === "success" || action_result?.type === "failure" ? action_result.data ?? null : null;
  let base$1 = base;
  let assets$1 = assets;
  let base_expression = s(base);
  const csp = new Csp(options2.csp, { prerender: !!state2.prerendering });
  if (!state2.prerendering?.fallback) {
    base$1 = (event.isDataRequest ? add_data_suffix(event.url.pathname) : event.url.pathname).slice(base.length).split("/").slice(2).map(() => "..").join("/") || ".";
    base_expression = `new URL(${s(base$1)}, location).pathname.slice(0, -1)`;
    if (!assets || assets[0] === "/" && assets !== "/_svelte_kit_assets") assets$1 = base$1;
  } else if (options2.hash_routing) base_expression = "new URL('.', location).pathname.slice(0, -1)";
  if (page_config.ssr) {
    const props = {
      stores: {
        page: writable(null),
        navigating: writable(null),
        updated
      },
      constructors: await Promise.all(branch2.map(({ node }) => {
        if (!node.component) throw new Error(`Missing +page.svelte component for route ${event.route.id}`);
        return node.component();
      })),
      form: form_value
    };
    if (error_components) {
      if (error2) props.error = error2;
      props.errors = error_components;
    }
    let data2 = {};
    for (let i = 0; i < branch2.length; i += 1) {
      data2 = {
        ...data2,
        ...branch2[i].data
      };
      props[`data_${i}`] = data2;
    }
    props.page = {
      error: error2,
      params: event.params,
      route: event.route,
      status,
      url: event.url,
      data: data2,
      form: form_value,
      state: {}
    };
    const render_opts = {
      context: /* @__PURE__ */ new Map([["__request__", { page: props.page }]]),
      csp: csp.script_needs_nonce ? { nonce: csp.nonce } : { hash: csp.script_needs_hash },
      transformError: error_components ? async (e) => {
        if (isRedirect(e)) throw e;
        const transformed2 = await handle_error_and_jsonify(event, event_state, options2, e);
        props.page.error = props.error = error2 = transformed2;
        props.page.status = status = get_status(e);
        return transformed2;
      } : void 0
    };
    globalThis.fetch;
    try {
      const state3 = {
        ...event_state,
        is_in_render: true
      };
      rendered = await with_request_store2({
        event,
        state: state3
      }, async () => {
        override({
          base: base$1,
          assets: assets$1
        });
        const maybe_promise = options2.root.render(props, render_opts);
        const rendered2 = options2.async && "then" in maybe_promise ? maybe_promise.then((r) => r) : maybe_promise;
        if (options2.async) reset();
        const { head: head3, html: html3, css, hashes } = options2.async ? await rendered2 : rendered2;
        if (hashes) csp.add_script_hashes(hashes.script);
        return {
          head: head3,
          html: html3,
          css,
          hashes
        };
      });
    } finally {
      reset();
    }
  } else rendered = {
    head: "",
    html: "",
    css: {
      code: "",
      map: null
    },
    hashes: { script: [] }
  };
  for (const { node } of branch2) {
    for (const url of node.imports) modulepreloads.add(url);
    for (const url of node.stylesheets) stylesheets7.add(url);
    for (const url of node.fonts) fonts7.add(url);
    if (node.inline_styles && !client?.inline) Object.entries(await node.inline_styles()).forEach(([filename, css]) => {
      if (typeof css === "string") {
        inline_styles.set(filename, css);
        return;
      }
      inline_styles.set(filename, css(`${assets$1}/${app_dir}/immutable/assets`, assets$1));
    });
  }
  const head2 = new Head(rendered.head, !!state2.prerendering);
  let body = rendered.html;
  const prefixed = (path) => {
    if (path.startsWith("/")) return base + path;
    return `${assets$1}/${path}`;
  };
  const style = client?.inline ? client.inline?.style : Array.from(inline_styles.values()).join("\n");
  if (style) {
    const attributes2 = [];
    if (csp.style_needs_nonce) attributes2.push(`nonce="${csp.nonce}"`);
    csp.add_style(style);
    head2.add_style(style, attributes2);
  }
  for (const dep of stylesheets7) {
    const path = prefixed(dep);
    const attributes2 = ['rel="stylesheet"'];
    if (inline_styles.has(dep)) attributes2.push("disabled", 'media="(max-width: 0)"');
    else if (resolve_opts.preload({
      type: "css",
      path
    })) link_headers.add(`<${encodeURI(path)}>; rel="preload"; as="style"; nopush`);
    head2.add_stylesheet(path, attributes2);
  }
  for (const dep of fonts7) {
    const path = prefixed(dep);
    if (resolve_opts.preload({
      type: "font",
      path
    })) {
      const ext = dep.slice(dep.lastIndexOf(".") + 1);
      head2.add_link_tag(path, [
        'rel="preload"',
        'as="font"',
        `type="font/${ext}"`,
        "crossorigin"
      ]);
      link_headers.add(`<${encodeURI(path)}>; rel="preload"; as="font"; type="font/${ext}"; crossorigin; nopush`);
    }
  }
  const global = get_global_name(options2);
  const { data, chunks } = data_serializer.get_data(csp);
  if (page_config.ssr && page_config.csr) body += `
			${fetched.map((item) => serialize_data(item, resolve_opts.filterSerializedResponseHeaders, !!state2.prerendering)).join("\n			")}`;
  if (page_config.csr && client) {
    const route = client.routes?.find((r) => r.id === event.route.id) ?? null;
    const load_env_eagerly = client.uses_env_dynamic_public && !!state2.prerendering;
    if (load_env_eagerly) modulepreloads.add(`${app_dir}/env.js`);
    if (!client.inline) {
      const included_modulepreloads = Array.from(modulepreloads, (dep) => prefixed(dep)).filter((path) => resolve_opts.preload({
        type: "js",
        path
      }));
      for (const path of included_modulepreloads) {
        link_headers.add(`<${encodeURI(path)}>; rel="modulepreload"; nopush`);
        if (options2.preload_strategy !== "modulepreload") head2.add_script_preload(path);
        else head2.add_link_tag(path, ['rel="modulepreload"']);
      }
    }
    if (client.routes && state2.prerendering && !state2.prerendering.fallback) {
      const pathname = add_resolution_suffix(event.url.pathname);
      state2.prerendering.dependencies.set(pathname, create_server_routing_response(route, event.params, new URL(pathname, event.url), client));
    }
    const blocks = [];
    const properties = [`base: ${base_expression}`];
    if (assets) properties.push(`assets: ${s(assets)}`);
    if (client.uses_env_dynamic_public) properties.push(`env: ${load_env_eagerly ? "null" : s(public_env)}`);
    if (chunks) {
      blocks.push("const deferred = new Map();");
      properties.push(`defer: (id) => new Promise((fulfil, reject) => {
							deferred.set(id, { fulfil, reject });
						})`);
      let app_declaration = "";
      if (Object.keys(options2.hooks.transport).length > 0) {
        if (client.inline) app_declaration = `const app = ${global}.app.app;`;
        else if (client.app) app_declaration = `const app = await import(${s(prefixed(client.app))});`;
        else app_declaration = `const { app } = await import(${s(prefixed(client.start))});`;
      }
      const prelude = app_declaration ? `${app_declaration}
							const [data, error] = fn(app);` : `const [data, error] = fn();`;
      properties.push(`resolve: async (id, fn) => {
							${prelude}

							const try_to_resolve = () => {
								if (!deferred.has(id)) {
									setTimeout(try_to_resolve, 0);
									return;
								}
								const { fulfil, reject } = deferred.get(id);
								deferred.delete(id);
								if (error) reject(error);
								else fulfil(data);
							}
							try_to_resolve();
						}`);
    }
    blocks.push(`${global} = {
						${properties.join(",\n						")}
					};`);
    const args = ["element"];
    blocks.push("const element = document.currentScript.parentElement;");
    if (page_config.ssr) {
      const serialized = {
        form: "null",
        error: "null"
      };
      if (form_value) serialized.form = uneval_action_response(form_value, event.route.id, options2.hooks.transport);
      if (error2) serialized.error = devalue4.uneval(error2);
      const hydrate3 = [
        `node_ids: [${branch2.map(({ node }) => node.index).join(", ")}]`,
        `data: ${data}`,
        `form: ${serialized.form}`,
        `error: ${serialized.error}`
      ];
      if (status !== 200) hydrate3.push(`status: ${status}`);
      if (client.routes) {
        if (route) {
          const stringified = generate_route_object(route, event.url, client).replaceAll("\n", "\n							");
          hydrate3.push(`params: ${devalue4.uneval(event.params)}`, `server_route: ${stringified}`);
        }
      } else if (options2.embedded) hydrate3.push(`params: ${devalue4.uneval(event.params)}`, `route: ${s(event.route)}`);
      const indent = "	".repeat(load_env_eagerly ? 7 : 6);
      args.push(`{
${indent}	${hydrate3.join(`,
${indent}	`)}
${indent}}`);
    }
    const remote_data = await collect_remote_data({}, event, event_state, options2);
    const serialized_data = Object.keys(remote_data).length > 0 ? `${global}.data = ${devalue4.uneval(remote_data, create_replacer(options2.hooks.transport))};

						` : "";
    const boot = client.inline ? `${client.inline.script}

					${serialized_data}${global}.app.start(${args.join(", ")});` : client.app ? `Promise.all([
						import(${s(prefixed(client.start))}),
						import(${s(prefixed(client.app))})
					]).then(([kit, app]) => {
						${serialized_data}kit.start(app, ${args.join(", ")});
					});` : `import(${s(prefixed(client.start))}).then((app) => {
						${serialized_data}app.start(${args.join(", ")})
					});`;
    if (load_env_eagerly) blocks.push(`import(${s(`${base$1}/${app_dir}/env.js`)}).then(({ env }) => {
						${global}.env = env;

						${boot.replace(/\n/g, "\n	")}
					});`);
    else blocks.push(boot);
    if (options2.service_worker) {
      let opts = "";
      if (options2.service_worker_options != null) opts = `, ${s({ ...options2.service_worker_options })}`;
      blocks.push(`if ('serviceWorker' in navigator) {
						const script_url = '${prefixed("service-worker.js")}';
						const policy = globalThis?.window?.trustedTypes?.createPolicy(
							'sveltekit-trusted-url',
							{ createScriptURL(url) { return url; } }
						);
						const sanitised = policy?.createScriptURL(script_url) ?? script_url;
						addEventListener('load', function () {
							navigator.serviceWorker.register(sanitised${opts});
						});
					}`);
    }
    const init_app = `
				{
					${blocks.join("\n\n					")}
				}
			`;
    csp.add_script(init_app);
    body += `
			<script${csp.script_needs_nonce ? ` nonce="${csp.nonce}"` : ""}>${init_app}</script>
		`;
  }
  const headers2 = new Headers({
    "x-sveltekit-page": "true",
    "content-type": "text/html"
  });
  if (state2.prerendering) {
    const csp_headers = csp.csp_provider.get_meta();
    if (csp_headers) head2.add_http_equiv(csp_headers);
    if (state2.prerendering.cache) head2.add_http_equiv(`<meta http-equiv="cache-control" content="${state2.prerendering.cache}">`);
  } else {
    const csp_header = csp.csp_provider.get_header();
    if (csp_header) headers2.set("content-security-policy", csp_header);
    const report_only_header = csp.report_only_provider.get_header();
    if (report_only_header) headers2.set("content-security-policy-report-only", report_only_header);
    if (link_headers.size) headers2.set("link", Array.from(link_headers).join(", "));
  }
  const html2 = options2.templates.app({
    head: head2.build(),
    body,
    assets: assets$1,
    nonce: csp.nonce,
    env: public_env
  });
  const transformed = await resolve_opts.transformPageChunk({
    html: html2,
    done: true
  }) || "";
  if (!chunks) headers2.set("etag", `"${hash(transformed)}"`);
  return !chunks ? text2(transformed, {
    status,
    headers: headers2
  }) : new Response(new ReadableStream({
    async start(controller) {
      controller.enqueue(text_encoder2.encode(transformed + "\n"));
      for await (const chunk of chunks) if (chunk.length) controller.enqueue(text_encoder2.encode(chunk));
      controller.close();
    },
    type: "bytes"
  }), { headers: headers2 });
}
var Head = class {
  #rendered;
  #prerendering;
  /** @type {string[]} */
  #http_equiv = [];
  /** @type {string[]} */
  #link_tags = [];
  /** @type {string[]} */
  #script_preloads = [];
  /** @type {string[]} */
  #style_tags = [];
  /** @type {string[]} */
  #stylesheet_links = [];
  /**
  * @param {string} rendered
  * @param {boolean} prerendering
  */
  constructor(rendered, prerendering) {
    this.#rendered = rendered;
    this.#prerendering = prerendering;
  }
  build() {
    return [
      ...this.#http_equiv,
      ...this.#link_tags,
      ...this.#script_preloads,
      this.#rendered,
      ...this.#style_tags,
      ...this.#stylesheet_links
    ].join("\n		");
  }
  /**
  * @param {string} style
  * @param {string[]} attributes
  */
  add_style(style, attributes2) {
    this.#style_tags.push(`<style${attributes2.length ? " " + attributes2.join(" ") : ""}>${style}</style>`);
  }
  /**
  * @param {string} href
  * @param {string[]} attributes
  */
  add_stylesheet(href, attributes2) {
    this.#stylesheet_links.push(`<link href="${href}" ${attributes2.join(" ")}>`);
  }
  /** @param {string} href */
  add_script_preload(href) {
    this.#script_preloads.push(`<link rel="preload" as="script" crossorigin="anonymous" href="${href}">`);
  }
  /**
  * @param {string} href
  * @param {string[]} attributes
  */
  add_link_tag(href, attributes2) {
    if (!this.#prerendering) return;
    this.#link_tags.push(`<link href="${href}" ${attributes2.join(" ")}>`);
  }
  /** @param {string} tag */
  add_http_equiv(tag) {
    if (!this.#prerendering) return;
    this.#http_equiv.push(tag);
  }
};
var PageNodes = class {
  /** All layout nodes and the page node, if any */
  data;
  /**
  * @param {Array<import('types').SSRNode | undefined>} nodes
  */
  constructor(nodes) {
    this.data = nodes;
  }
  layouts() {
    return this.data.slice(0, -1);
  }
  page() {
    return this.data.at(-1);
  }
  validate() {
    for (const layout of this.layouts()) if (layout) {
      validate_layout_server_exports(layout.server, layout.server_id);
      validate_layout_exports(layout.universal, layout.universal_id);
    }
    const page2 = this.page();
    if (page2) {
      validate_page_server_exports(page2.server, page2.server_id);
      validate_page_exports(page2.universal, page2.universal_id);
    }
  }
  /**
  * @template {'prerender' | 'ssr' | 'csr' | 'trailingSlash'} Option
  * @param {Option} option
  * @returns {Value | undefined}
  */
  #get_option(option) {
    return this.data.reduce((value, node) => {
      return node?.universal?.[option] ?? node?.server?.[option] ?? value;
    }, void 0);
  }
  csr() {
    return this.#get_option("csr") ?? true;
  }
  ssr() {
    return this.#get_option("ssr") ?? true;
  }
  prerender() {
    return this.#get_option("prerender") ?? false;
  }
  trailing_slash() {
    return this.#get_option("trailingSlash") ?? "never";
  }
  get_config() {
    let current2 = {};
    for (const node of this.data) {
      if (!node?.universal?.config && !node?.server?.config) continue;
      current2 = {
        ...current2,
        ...node?.universal?.config,
        ...node?.server?.config
      };
    }
    return Object.keys(current2).length ? current2 : void 0;
  }
  should_prerender_data() {
    return this.data.some((node) => node?.server?.load || node?.server?.trailingSlash !== void 0);
  }
};
async function respond_with_error({ event, event_state, options: options2, manifest, state: state2, status, error: error2, resolve_opts }) {
  if (event.request.headers.get("x-sveltekit-error")) return static_error_page(
    options2,
    status,
    /** @type {Error} */
    error2.message
  );
  const fetched = [];
  try {
    const branch2 = [];
    const default_layout = await manifest._.nodes[0]();
    const nodes = new PageNodes([default_layout]);
    const ssr = nodes.ssr();
    const csr = nodes.csr();
    const data_serializer = server_data_serializer(event, event_state, options2);
    if (ssr) {
      state2.error = true;
      const server_data_promise = load_server_data({
        event,
        event_state,
        state: state2,
        node: default_layout,
        parent: async () => ({})
      });
      const server_data = await server_data_promise;
      data_serializer.add_node(0, server_data);
      const data = await load_data({
        event,
        event_state,
        fetched,
        node: default_layout,
        parent: async () => ({}),
        resolve_opts,
        server_data_promise,
        state: state2,
        csr
      });
      branch2.push({
        node: default_layout,
        server_data,
        data
      }, {
        node: await manifest._.nodes[1](),
        data: null,
        server_data: null
      });
    }
    return await render_response({
      options: options2,
      manifest,
      state: state2,
      page_config: {
        ssr,
        csr
      },
      status,
      error: await handle_error_and_jsonify(event, event_state, options2, error2),
      branch: branch2,
      error_components: [],
      fetched,
      event,
      event_state,
      resolve_opts,
      data_serializer
    });
  } catch (e) {
    if (e instanceof Redirect) return redirect_response(e.status, e.location);
    return static_error_page(options2, get_status(e), (await handle_error_and_jsonify(event, event_state, options2, e)).message);
  }
}
var MAX_DEPTH = 10;
async function render_page(event, event_state, page2, options2, manifest, state2, nodes, resolve_opts) {
  if (state2.depth > MAX_DEPTH) return text2(`Not found: ${event.url.pathname}`, { status: 404 });
  if (is_action_json_request(event)) return handle_action_json_request(event, event_state, options2, (await manifest._.nodes[page2.leaf]())?.server);
  try {
    const leaf_node = nodes.page();
    let status = 200;
    let action_result = void 0;
    if (is_action_request(event)) {
      const remote_id = get_remote_action(event.url);
      if (remote_id) action_result = await handle_remote_form_post(event, event_state, manifest, remote_id);
      else action_result = await handle_action_request(event, event_state, leaf_node.server);
      if (action_result?.type === "redirect") return redirect_response(action_result.status, action_result.location);
      if (action_result?.type === "error") status = get_status(action_result.error);
      if (action_result?.type === "failure") status = action_result.status;
    }
    const should_prerender = nodes.prerender();
    if (should_prerender) {
      if (leaf_node.server?.actions) throw new Error("Cannot prerender pages with actions");
    } else if (state2.prerendering) return new Response(void 0, { status: 204 });
    state2.prerender_default = should_prerender;
    const should_prerender_data = nodes.should_prerender_data();
    const data_pathname = add_data_suffix(event.url.pathname);
    const fetched = [];
    const ssr = nodes.ssr();
    const csr = nodes.csr();
    if (ssr === false && !(state2.prerendering && should_prerender_data)) return await render_response({
      branch: compact(nodes.data).map((node) => {
        return {
          node,
          data: null,
          server_data: null
        };
      }),
      fetched,
      page_config: {
        ssr: false,
        csr
      },
      status,
      error: null,
      event,
      event_state,
      options: options2,
      manifest,
      state: state2,
      resolve_opts,
      data_serializer: server_data_serializer(event, event_state, options2)
    });
    const branch2 = [];
    let load_error = null;
    const data_serializer = server_data_serializer(event, event_state, options2);
    const data_serializer_json = state2.prerendering && should_prerender_data ? server_data_serializer_json(event, event_state, options2) : null;
    const server_promises = nodes.data.map((node, i) => {
      if (load_error) throw load_error;
      return Promise.resolve().then(async () => {
        try {
          if (node === leaf_node && action_result?.type === "error") throw action_result.error;
          const server_data = await load_server_data({
            event,
            event_state,
            state: state2,
            node,
            parent: async () => {
              const data = {};
              for (let j = 0; j < i; j += 1) {
                const parent = await server_promises[j];
                if (parent) Object.assign(data, parent.data);
              }
              return data;
            }
          });
          if (node) data_serializer.add_node(i, server_data);
          data_serializer_json?.add_node(i, server_data);
          return server_data;
        } catch (e) {
          load_error = e;
          throw load_error;
        }
      });
    });
    const load_promises = nodes.data.map((node, i) => {
      if (load_error) throw load_error;
      return Promise.resolve().then(async () => {
        try {
          return await load_data({
            event,
            event_state,
            fetched,
            node,
            parent: async () => {
              const data = {};
              for (let j = 0; j < i; j += 1) Object.assign(data, await load_promises[j]);
              return data;
            },
            resolve_opts,
            server_data_promise: server_promises[i],
            state: state2,
            csr
          });
        } catch (e) {
          load_error = e;
          throw load_error;
        }
      });
    });
    for (const p of server_promises) p.catch(noop2);
    for (const p of load_promises) p.catch(noop2);
    for (let i = 0; i < nodes.data.length; i += 1) {
      const node = nodes.data[i];
      if (node) try {
        const server_data = await server_promises[i];
        const data = await load_promises[i];
        branch2.push({
          node,
          server_data,
          data
        });
      } catch (e) {
        const err = normalize_error(e);
        if (err instanceof Redirect) {
          if (state2.prerendering && should_prerender_data) {
            const body = JSON.stringify({
              type: "redirect",
              location: err.location
            });
            state2.prerendering.dependencies.set(data_pathname, {
              response: text2(body),
              body
            });
          }
          return redirect_response(err.status, err.location);
        }
        const status2 = get_status(err);
        const error2 = await handle_error_and_jsonify(event, event_state, options2, err);
        while (i--) if (page2.errors[i]) {
          const index7 = page2.errors[i];
          const node2 = await manifest._.nodes[index7]();
          let j = i;
          while (!branch2[j]) j -= 1;
          data_serializer.set_max_nodes(j + 1);
          const layouts = compact(branch2.slice(0, j + 1));
          const nodes2 = new PageNodes(layouts.map((layout) => layout.node));
          const error_branch = layouts.concat({
            node: node2,
            data: null,
            server_data: null
          });
          return await render_response({
            event,
            event_state,
            options: options2,
            manifest,
            state: state2,
            resolve_opts,
            page_config: {
              ssr: nodes2.ssr(),
              csr: nodes2.csr()
            },
            status: status2,
            error: error2,
            error_components: await load_error_components(options2, ssr, error_branch, page2, manifest),
            branch: error_branch,
            fetched,
            data_serializer
          });
        }
        return static_error_page(options2, status2, error2.message);
      }
      else branch2.push(null);
    }
    if (state2.prerendering && data_serializer_json) {
      let { data, chunks } = data_serializer_json.get_data();
      if (chunks) for await (const chunk of chunks) data += chunk;
      state2.prerendering.dependencies.set(data_pathname, {
        response: text2(data),
        body: data
      });
    }
    return await render_response({
      event,
      event_state,
      options: options2,
      manifest,
      state: state2,
      resolve_opts,
      page_config: {
        csr,
        ssr
      },
      status,
      error: null,
      branch: compact(branch2),
      action_result,
      fetched,
      data_serializer: !ssr ? server_data_serializer(event, event_state, options2) : data_serializer,
      error_components: await load_error_components(options2, ssr, branch2, page2, manifest)
    });
  } catch (e) {
    if (e instanceof Redirect) return redirect_response(e.status, e.location);
    return await respond_with_error({
      event,
      event_state,
      options: options2,
      manifest,
      state: state2,
      status: e instanceof HttpError3 ? e.status : 500,
      error: e,
      resolve_opts
    });
  }
}
async function load_error_components(options2, ssr, branch2, page2, manifest) {
  let error_components;
  if (options2.server_error_boundaries && ssr) {
    let last_idx = -1;
    error_components = await Promise.all(branch2.map((b, i) => {
      if (i === 0) return void 0;
      if (!b) return null;
      i--;
      while (i > last_idx + 1 && page2.errors[i] === void 0) i -= 1;
      last_idx = i;
      const idx = page2.errors[i];
      if (idx == null) return void 0;
      return manifest._.nodes[idx]?.().then((e) => e.component?.()).catch(() => void 0);
    }).filter((e) => e !== null));
  }
  return error_components;
}
async function render_data(event, event_state, route, options2, manifest, state2, invalidated_data_nodes, trailing_slash) {
  if (!route.page) return new Response(void 0, { status: 404 });
  try {
    const node_ids = [...route.page.layouts, route.page.leaf];
    const invalidated = invalidated_data_nodes ?? node_ids.map(() => true);
    let aborted = false;
    const url = new URL(event.url);
    url.pathname = normalize_path(url.pathname, trailing_slash);
    const new_event = {
      ...event,
      url
    };
    const functions = node_ids.map((n, i) => {
      return once2(async () => {
        try {
          if (aborted) return { type: "skip" };
          const node = n == void 0 ? n : await manifest._.nodes[n]();
          return load_server_data({
            event: new_event,
            event_state,
            state: state2,
            node,
            parent: async () => {
              const data2 = {};
              for (let j = 0; j < i; j += 1) {
                const parent = await functions[j]();
                if (parent) Object.assign(data2, parent.data);
              }
              return data2;
            }
          });
        } catch (e) {
          aborted = true;
          throw e;
        }
      });
    });
    const promises = functions.map(async (fn, i) => {
      if (!invalidated[i]) return { type: "skip" };
      return fn();
    });
    let length = promises.length;
    const nodes = await Promise.all(promises.map((p, i) => p.catch(async (error2) => {
      if (error2 instanceof Redirect) throw error2;
      length = Math.min(length, i + 1);
      return {
        type: "error",
        error: await handle_error_and_jsonify(event, event_state, options2, error2),
        status: error2 instanceof HttpError3 || error2 instanceof SvelteKitError3 ? error2.status : void 0
      };
    })));
    const data_serializer = server_data_serializer_json(event, event_state, options2);
    for (let i = 0; i < nodes.length; i++) data_serializer.add_node(i, nodes[i]);
    const { data, chunks } = data_serializer.get_data();
    if (!chunks) return json_response(data);
    return new Response(new ReadableStream({
      async start(controller) {
        controller.enqueue(text_encoder2.encode(data));
        for await (const chunk of chunks) controller.enqueue(text_encoder2.encode(chunk));
        controller.close();
      },
      type: "bytes"
    }), { headers: {
      "content-type": "text/sveltekit-data",
      "cache-control": "private, no-store"
    } });
  } catch (e) {
    const error2 = normalize_error(e);
    if (error2 instanceof Redirect) return redirect_json_response(error2);
    else return json_response(await handle_error_and_jsonify(event, event_state, options2, error2), 500);
  }
}
function json_response(json3, status = 200) {
  return text2(typeof json3 === "string" ? json3 : JSON.stringify(json3), {
    status,
    headers: {
      "content-type": "application/json",
      "cache-control": "private, no-store"
    }
  });
}
function redirect_json_response(redirect2) {
  return json_response({
    type: "redirect",
    location: redirect2.location
  });
}
var INVALID_COOKIE_CHARACTER_REGEX = /[\x00-\x1F\x7F()<>@,;:"/[\]?={} \t]/;
function validate_options(options2) {
  if (options2?.path === void 0) throw new Error("You must specify a `path` when setting, deleting or serializing cookies");
}
function generate_cookie_key(domain, path, name) {
  return `${domain || ""}${path}?${encodeURIComponent(name)}`;
}
function get_cookies(request, url) {
  const header = request.headers.get("cookie") ?? "";
  const initial_cookies = parse$1(header, { decode: (value) => value });
  let normalized_url;
  const new_cookies = /* @__PURE__ */ new Map();
  const defaults = {
    httpOnly: true,
    sameSite: "lax",
    secure: url.hostname === "localhost" && url.protocol === "http:" ? false : true
  };
  const cookies = {
    /**
    * @param {string} name
    * @param {import('cookie').CookieParseOptions} [opts]
    */
    get(name, opts) {
      const best_match = Array.from(new_cookies.values()).filter((c) => {
        return c.name === name && domain_matches(url.hostname, c.options.domain) && path_matches(url.pathname, c.options.path);
      }).sort((a, b) => b.options.path.length - a.options.path.length)[0];
      if (best_match) return best_match.options.maxAge === 0 ? void 0 : best_match.value;
      return parse$1(header, { decode: opts?.decode })[name];
    },
    /**
    * @param {import('cookie').CookieParseOptions} [opts]
    */
    getAll(opts) {
      const cookies2 = parse$1(header, { decode: opts?.decode });
      const lookup = /* @__PURE__ */ new Map();
      for (const c of new_cookies.values()) if (domain_matches(url.hostname, c.options.domain) && path_matches(url.pathname, c.options.path)) {
        const existing = lookup.get(c.name);
        if (!existing || c.options.path.length > existing.options.path.length) lookup.set(c.name, c);
      }
      for (const c of lookup.values()) cookies2[c.name] = c.value;
      return Object.entries(cookies2).map(([name, value]) => ({
        name,
        value
      }));
    },
    /**
    * @param {string} name
    * @param {string} value
    * @param {import('./page/types.js').Cookie['options']} options
    */
    set(name, value, options2) {
      const illegal_characters = name.match(INVALID_COOKIE_CHARACTER_REGEX);
      if (illegal_characters) console.warn(`The cookie name "${name}" will be invalid in SvelteKit 3.0 as it contains ${illegal_characters.join(" and ")}. See RFC 2616 for more details https://datatracker.ietf.org/doc/html/rfc2616#section-2.2`);
      validate_options(options2);
      set_internal(name, value, {
        ...defaults,
        ...options2
      });
    },
    /**
    * @param {string} name
    *  @param {import('./page/types.js').Cookie['options']} options
    */
    delete(name, options2) {
      validate_options(options2);
      cookies.set(name, "", {
        ...options2,
        maxAge: 0
      });
    },
    /**
    * @param {string} name
    * @param {string} value
    *  @param {import('./page/types.js').Cookie['options']} options
    */
    serialize(name, value, options2) {
      validate_options(options2);
      let path = options2.path;
      if (!options2.domain || options2.domain === url.hostname) {
        if (!normalized_url) throw new Error("Cannot serialize cookies until after the route is determined");
        path = resolve(normalized_url, path);
      }
      return serialize(name, value, {
        ...defaults,
        ...options2,
        path
      });
    }
  };
  function get_cookie_header(destination, header2) {
    const combined_cookies = { ...initial_cookies };
    for (const cookie of new_cookies.values()) {
      if (!domain_matches(destination.hostname, cookie.options.domain)) continue;
      if (!path_matches(destination.pathname, cookie.options.path)) continue;
      const encoder = cookie.options.encode || encodeURIComponent;
      combined_cookies[cookie.name] = encoder(cookie.value);
    }
    if (header2) {
      const parsed = parse$1(header2, { decode: (value) => value });
      for (const name in parsed) combined_cookies[name] = parsed[name];
    }
    return Object.entries(combined_cookies).map(([name, value]) => `${name}=${value}`).join("; ");
  }
  const internal_queue = [];
  function set_internal(name, value, options2) {
    if (!normalized_url) {
      internal_queue.push(() => set_internal(name, value, options2));
      return;
    }
    let path = options2.path;
    if (!options2.domain || options2.domain === url.hostname) path = resolve(normalized_url, path);
    const cookie_key = generate_cookie_key(options2.domain, path, name);
    const cookie = {
      name,
      value,
      options: {
        ...options2,
        path
      }
    };
    new_cookies.set(cookie_key, cookie);
  }
  function set_trailing_slash(trailing_slash) {
    normalized_url = normalize_path(url.pathname, trailing_slash);
    internal_queue.forEach((fn) => fn());
  }
  return {
    cookies,
    new_cookies,
    get_cookie_header,
    set_internal,
    set_trailing_slash
  };
}
function domain_matches(hostname, constraint) {
  if (!constraint) return true;
  const normalized = constraint[0] === "." ? constraint.slice(1) : constraint;
  if (hostname === normalized) return true;
  return hostname.endsWith("." + normalized);
}
function path_matches(path, constraint) {
  if (!constraint) return true;
  const normalized = constraint.endsWith("/") ? constraint.slice(0, -1) : constraint;
  if (path === normalized) return true;
  return path.startsWith(normalized + "/");
}
function add_cookies_to_headers(headers2, cookies) {
  for (const new_cookie of cookies) {
    const { name, value, options: options2 } = new_cookie;
    headers2.append("set-cookie", serialize(name, value, options2));
    if (options2.path.endsWith(".html")) {
      const path = add_data_suffix(options2.path);
      headers2.append("set-cookie", serialize(name, value, {
        ...options2,
        path
      }));
    }
  }
}
function create_fetch({ event, options: options2, manifest, state: state2, get_cookie_header, set_internal }) {
  const server_fetch = async (info, init3) => {
    const original_request = normalize_fetch_input(info, init3, event.url);
    let mode = (info instanceof Request ? info.mode : init3?.mode) ?? "cors";
    let credentials2 = (info instanceof Request ? info.credentials : init3?.credentials) ?? "same-origin";
    return options2.hooks.handleFetch({
      event,
      request: original_request,
      fetch: async (info2, init4) => {
        const request = normalize_fetch_input(info2, init4, event.url);
        const url = new URL(request.url);
        if (!request.headers.has("origin")) request.headers.set("origin", event.url.origin);
        if (info2 !== original_request) {
          mode = (info2 instanceof Request ? info2.mode : init4?.mode) ?? "cors";
          credentials2 = (info2 instanceof Request ? info2.credentials : init4?.credentials) ?? "same-origin";
        }
        if ((request.method === "GET" || request.method === "HEAD") && (mode === "no-cors" && url.origin !== event.url.origin || url.origin === event.url.origin)) request.headers.delete("origin");
        const decoded = decodeURIComponent(url.pathname);
        if (url.origin !== event.url.origin || base && decoded !== base && !decoded.startsWith(`${base}/`)) {
          if (`.${url.hostname}`.endsWith(`.${event.url.hostname}`) && credentials2 !== "omit") {
            const cookie = get_cookie_header(url, request.headers.get("cookie"));
            if (cookie) request.headers.set("cookie", cookie);
          }
          return fetch(request);
        }
        const prefix = assets || base;
        const filename = (decoded.startsWith(prefix) ? decoded.slice(prefix.length) : decoded).slice(1);
        const filename_html = `${filename}/index.html`;
        const is_asset = manifest.assets.has(filename) || filename in manifest._.server_assets;
        const is_asset_html = manifest.assets.has(filename_html) || filename_html in manifest._.server_assets;
        if (is_asset || is_asset_html) {
          const file = is_asset ? filename : filename_html;
          if (state2.read) {
            const type = is_asset ? manifest.mimeTypes[filename.slice(filename.lastIndexOf("."))] : "text/html";
            return new Response(state2.read(file), { headers: type ? { "content-type": type } : {} });
          } else if (read_implementation && file in manifest._.server_assets) {
            const length = manifest._.server_assets[file];
            const type = manifest.mimeTypes[file.slice(file.lastIndexOf("."))];
            return new Response(read_implementation(file), { headers: {
              "Content-Length": "" + length,
              "Content-Type": type
            } });
          }
          return await fetch(request);
        }
        if (has_prerendered_path(manifest, base + decoded)) return await fetch(request);
        if (credentials2 !== "omit") {
          const cookie = get_cookie_header(url, request.headers.get("cookie"));
          if (cookie) request.headers.set("cookie", cookie);
          const authorization = event.request.headers.get("authorization");
          if (authorization && !request.headers.has("authorization")) request.headers.set("authorization", authorization);
        }
        if (!request.headers.has("accept")) request.headers.set("accept", "*/*");
        if (!request.headers.has("accept-language")) request.headers.set("accept-language", event.request.headers.get("accept-language"));
        const response = await internal_fetch(request, options2, manifest, state2);
        for (const str of get_set_cookies(response.headers)) {
          const { name, value, ...options3 } = set_cookie_parser2.parseString(str, { decodeValues: false });
          set_internal(name, value, {
            path: options3.path ?? (url.pathname.split("/").slice(0, -1).join("/") || "/"),
            encode: (value2) => value2,
            ...options3
          });
        }
        return response;
      }
    });
  };
  return (input, init3) => {
    const response = server_fetch(input, init3);
    response.catch(noop2);
    return response;
  };
}
function normalize_fetch_input(info, init3, url) {
  if (info instanceof Request) return info;
  return new Request(typeof info === "string" ? new URL(info, url) : info, init3);
}
async function internal_fetch(request, options2, manifest, state2) {
  if (request.signal) {
    if (request.signal.aborted) throw new DOMException("The operation was aborted.", "AbortError");
    let remove_abort_listener = noop2;
    const abort_promise = new Promise((_, reject) => {
      const on_abort = () => {
        reject(new DOMException("The operation was aborted.", "AbortError"));
      };
      request.signal.addEventListener("abort", on_abort, { once: true });
      remove_abort_listener = () => request.signal.removeEventListener("abort", on_abort);
    });
    const result = await Promise.race([respond(request, options2, manifest, {
      ...state2,
      depth: state2.depth + 1
    }), abort_promise]);
    remove_abort_listener();
    return result;
  } else return await respond(request, options2, manifest, {
    ...state2,
    depth: state2.depth + 1
  });
}
var payload;
var etag;
var headers;
function get_public_env(request) {
  const script = request.url.endsWith(".script.js");
  const env = public_env;
  payload ??= devalue4.uneval(env);
  etag ??= `W/${Date.now()}`;
  headers ??= new Headers({
    "content-type": "application/javascript; charset=utf-8",
    etag
  });
  if (request.headers.get("if-none-match") === etag) return new Response(void 0, {
    status: 304,
    headers
  });
  if (script) return new Response(`globalThis.__sveltekit_sw={env:${payload}}`, { headers });
  return new Response(`export const env=${payload}`, { headers });
}
var default_transform = ({ html: html2 }) => html2;
var default_filter = () => false;
var default_preload = ({ type }) => type === "js" || type === "css";
var page_methods = /* @__PURE__ */ new Set([
  "GET",
  "HEAD",
  "POST"
]);
var allowed_page_methods = /* @__PURE__ */ new Set([
  "GET",
  "HEAD",
  "OPTIONS"
]);
var respond = propagate_context(internal_respond);
async function internal_respond(request, options2, manifest, state2) {
  const url = new URL(request.url);
  const is_route_resolution_request = has_resolution_suffix(url.pathname);
  const is_data_request = has_data_suffix(url.pathname);
  const remote_id = get_remote_id(url);
  {
    const request_origin = request.headers.get("origin");
    if (remote_id) {
      if (request.method !== "GET" && request_origin !== url.origin) return json2({ message: "Cross-site remote requests are forbidden" }, { status: 403 });
    } else if (options2.csrf_check_origin) {
      if (is_form_content_type(request) && (request.method === "POST" || request.method === "PUT" || request.method === "PATCH" || request.method === "DELETE") && request_origin !== url.origin && (!request_origin || !options2.csrf_trusted_origins.includes(request_origin))) {
        const message = `Cross-site ${request.method} form submissions are forbidden`;
        const opts = { status: 403 };
        if (request.headers.get("accept") === "application/json") return json2({ message }, opts);
        return text2(message, opts);
      }
    }
  }
  if (options2.hash_routing && url.pathname !== base + "/" && url.pathname !== "/[fallback]") return text2("Not found", { status: 404 });
  let invalidated_data_nodes;
  if (is_route_resolution_request)
    url.pathname = strip_resolution_suffix(url.pathname);
  else if (is_data_request) {
    url.pathname = strip_data_suffix(url.pathname) + (url.searchParams.get("x-sveltekit-trailing-slash") === "1" ? "/" : "") || "/";
    url.searchParams.delete(TRAILING_SLASH_PARAM);
    invalidated_data_nodes = url.searchParams.get(INVALIDATED_PARAM)?.split("").map((node) => node === "1");
    url.searchParams.delete(INVALIDATED_PARAM);
  } else if (remote_id) {
    url.pathname = request.headers.get("x-sveltekit-pathname") ?? base;
    url.search = request.headers.get("x-sveltekit-search") ?? "";
  }
  const headers2 = {};
  const { cookies, new_cookies, get_cookie_header, set_internal, set_trailing_slash } = get_cookies(request, url);
  const event_state = {
    prerendering: state2.prerendering,
    transport: options2.hooks.transport,
    handleValidationError: options2.hooks.handleValidationError,
    tracing: { record_span },
    remote: {
      data: null,
      explicit: null,
      implicit: null,
      forms: null,
      requested: null,
      batches: null,
      live_iterators: null
    },
    is_in_remote_function: false,
    is_in_remote_form_or_command: false,
    is_in_remote_query: false,
    is_in_render: false,
    is_in_universal_load: false
  };
  const event = {
    cookies,
    fetch: null,
    getClientAddress: state2.getClientAddress || (() => {
      throw new Error(`@sveltejs/adapter-netlify does not specify getClientAddress. Please raise an issue`);
    }),
    locals: {},
    params: {},
    platform: state2.platform,
    request,
    route: { id: null },
    setHeaders: (new_headers) => {
      for (const key2 in new_headers) {
        const lower = key2.toLowerCase();
        const value = new_headers[key2];
        if (lower === "set-cookie") throw new Error("Use `event.cookies.set(name, value, options)` instead of `event.setHeaders` to set cookies");
        else if (lower in headers2) {
          if (lower === "server-timing") headers2[lower] += ", " + value;
          else throw new Error(`"${key2}" header is already set`);
        } else {
          headers2[lower] = value;
          if (state2.prerendering && lower === "cache-control") state2.prerendering.cache = value;
        }
      }
    },
    url,
    isDataRequest: is_data_request,
    isSubRequest: state2.depth > 0,
    isRemoteRequest: !!remote_id
  };
  event.fetch = create_fetch({
    event,
    options: options2,
    manifest,
    state: state2,
    get_cookie_header,
    set_internal
  });
  if (state2.emulator?.platform) event.platform = await state2.emulator.platform({
    config: {},
    prerender: !!state2.prerendering?.fallback
  });
  let resolved_path = url.pathname;
  if (!remote_id) {
    const prerendering_reroute_state = state2.prerendering?.inside_reroute;
    try {
      if (state2.prerendering) state2.prerendering.inside_reroute = true;
      resolved_path = await options2.hooks.reroute({
        url: new URL(url),
        fetch: event.fetch
      }) ?? url.pathname;
    } catch {
      return text2("Internal Server Error", { status: 500 });
    } finally {
      if (state2.prerendering) state2.prerendering.inside_reroute = prerendering_reroute_state;
    }
  }
  let resolve_opts = {
    transformPageChunk: default_transform,
    filterSerializedResponseHeaders: default_filter,
    preload: default_preload
  };
  let trailing_slash = "never";
  let page_nodes;
  try {
    resolved_path = decode_pathname(resolved_path);
  } catch {
    resolved_path = null;
    return await handle2();
  }
  if (resolved_path !== decode_pathname(url.pathname) && !state2.prerendering?.fallback && has_prerendered_path(manifest, resolved_path)) {
    const url2 = new URL(request.url);
    url2.pathname = is_data_request ? add_data_suffix(resolved_path) : is_route_resolution_request ? add_resolution_suffix(resolved_path) : resolved_path;
    try {
      const response = await fetch(url2, request);
      const headers3 = new Headers(response.headers);
      if (headers3.has("content-encoding")) {
        headers3.delete("content-encoding");
        headers3.delete("content-length");
      }
      return new Response(response.body, {
        headers: headers3,
        status: response.status,
        statusText: response.statusText
      });
    } catch (error2) {
      return await handle_fatal_error(event, event_state, options2, error2);
    }
  }
  let route = null;
  if (base && !state2.prerendering?.fallback) {
    if (!resolved_path.startsWith(base)) return text2("Not found", { status: 404 });
    resolved_path = resolved_path.slice(base.length) || "/";
  }
  if (is_route_resolution_request) return resolve_route(resolved_path, new URL(request.url), manifest);
  if (resolved_path === `/_app/env.js` || resolved_path === `/_app/env.script.js`) return get_public_env(request);
  if (!remote_id && resolved_path.startsWith(`/_app`)) {
    const headers3 = new Headers();
    headers3.set("cache-control", "public, max-age=0, must-revalidate");
    return text2("Not found", {
      status: 404,
      headers: headers3
    });
  }
  if (!state2.prerendering?.fallback) {
    const matchers = await manifest._.matchers();
    const result = find_route(resolved_path, manifest._.routes, matchers);
    if (result) {
      route = result.route;
      event.route = { id: route.id };
      event.params = result.params;
    }
  }
  try {
    page_nodes = route?.page ? new PageNodes(await load_page_nodes(route.page, manifest)) : void 0;
    if (route && !remote_id) {
      if (url.pathname === base || url.pathname === base + "/") trailing_slash = "always";
      else if (page_nodes) trailing_slash = page_nodes.trailing_slash();
      else if (route.endpoint) trailing_slash = (await route.endpoint()).trailingSlash ?? "never";
      if (!is_data_request) {
        const normalized = normalize_path(url.pathname, trailing_slash);
        if (normalized !== url.pathname && !state2.prerendering?.fallback) return new Response(void 0, {
          status: 308,
          headers: {
            "x-sveltekit-normalize": "1",
            location: (normalized.startsWith("//") ? url.origin + normalized : normalized) + (url.search === "?" ? "" : url.search)
          }
        });
      }
      if (state2.before_handle || state2.emulator?.platform) {
        let config2 = {};
        let prerender = false;
        if (route.endpoint) {
          const node = await route.endpoint();
          config2 = node.config ?? config2;
          prerender = node.prerender ?? prerender;
        } else if (page_nodes) {
          config2 = page_nodes.get_config() ?? config2;
          prerender = page_nodes.prerender();
        }
        if (state2.emulator?.platform) event.platform = await state2.emulator.platform({
          config: config2,
          prerender
        });
        if (state2.before_handle) return await state2.before_handle(event, config2, prerender, handle2);
      }
    }
    return await handle2();
  } catch (e) {
    if (e instanceof Redirect) try {
      const response = is_data_request || remote_id ? redirect_json_response(e) : route?.page && is_action_json_request(event) ? action_json_redirect(e) : redirect_response(e.status, e.location);
      add_cookies_to_headers(response.headers, new_cookies.values());
      return response;
    } catch (err) {
      return await handle_fatal_error(event, event_state, options2, err);
    }
    return await handle_fatal_error(event, event_state, options2, e);
  }
  async function handle2() {
    set_trailing_slash(trailing_slash);
    if (state2.prerendering && !state2.prerendering.fallback && !state2.prerendering.inside_reroute) disable_search(url);
    const response = await record_span({
      name: "sveltekit.handle.root",
      attributes: {
        "http.route": event.route.id || "unknown",
        "http.method": event.request.method,
        "http.url": event.url.href,
        "sveltekit.is_data_request": is_data_request,
        "sveltekit.is_sub_request": event.isSubRequest
      },
      fn: async (root_span) => {
        const traced_event = {
          ...event,
          tracing: {
            enabled: false,
            root: root_span,
            current: root_span
          }
        };
        return await with_request_store2({
          event: traced_event,
          state: event_state
        }, () => options2.hooks.handle({
          event: traced_event,
          resolve: (event2, opts) => {
            return record_span({
              name: "sveltekit.resolve",
              attributes: { "http.route": event2.route.id || "unknown" },
              fn: (resolve_span) => {
                return with_request_store2(null, () => resolve2(merge_tracing(event2, resolve_span), page_nodes, opts).then((response2) => {
                  for (const key2 in headers2) {
                    const value = headers2[key2];
                    response2.headers.set(key2, value);
                  }
                  add_cookies_to_headers(response2.headers, new_cookies.values());
                  if (state2.prerendering && event2.route.id !== null) response2.headers.set("x-sveltekit-routeid", encodeURI(event2.route.id));
                  resolve_span.setAttributes({
                    "http.response.status_code": response2.status,
                    "http.response.body.size": response2.headers.get("content-length") || "unknown"
                  });
                  return response2;
                }));
              }
            });
          }
        }));
      }
    });
    if (response.status === 200 && response.headers.has("etag")) {
      let if_none_match_value = request.headers.get("if-none-match");
      if (if_none_match_value?.startsWith('W/"')) if_none_match_value = if_none_match_value.substring(2);
      const etag2 = response.headers.get("etag");
      if (if_none_match_value === etag2) {
        const headers3 = new Headers({ etag: etag2 });
        for (const key2 of [
          "cache-control",
          "content-location",
          "date",
          "expires",
          "vary"
        ]) {
          const value = response.headers.get(key2);
          if (value) headers3.set(key2, value);
        }
        for (const cookie of get_set_cookies(response.headers)) headers3.append("set-cookie", cookie);
        return new Response(void 0, {
          status: 304,
          headers: headers3
        });
      }
    }
    if (is_data_request && response.status >= 300 && response.status <= 308) {
      const location = response.headers.get("location");
      if (location) return redirect_json_response(new Redirect(response.status, location));
    }
    return response;
  }
  async function resolve2(event2, page_nodes2, opts) {
    try {
      if (opts) resolve_opts = {
        transformPageChunk: opts.transformPageChunk || default_transform,
        filterSerializedResponseHeaders: opts.filterSerializedResponseHeaders || default_filter,
        preload: opts.preload || default_preload
      };
      if (resolved_path === null) return await respond_with_error({
        event: event2,
        event_state,
        options: options2,
        manifest,
        state: state2,
        status: 400,
        error: new SvelteKitError3(400, "Malformed URI", `Failed to decode URI: ${event2.url.pathname}`),
        resolve_opts
      });
      if (options2.hash_routing || state2.prerendering?.fallback) return await render_response({
        event: event2,
        event_state,
        options: options2,
        manifest,
        state: state2,
        page_config: {
          ssr: false,
          csr: true
        },
        status: 200,
        error: null,
        branch: [{
          node: await manifest._.nodes[0](),
          data: null,
          server_data: null
        }],
        fetched: [],
        resolve_opts,
        data_serializer: server_data_serializer(event2, event_state, options2)
      });
      if (remote_id) return await handle_remote_call(event2, event_state, options2, manifest, remote_id);
      if (route) {
        const method = event2.request.method;
        let response2;
        if (is_data_request) response2 = await render_data(event2, event_state, route, options2, manifest, state2, invalidated_data_nodes, trailing_slash);
        else if (route.endpoint && (!route.page || !state2.prerendering && is_endpoint_request(event2))) response2 = await render_endpoint(event2, event_state, await route.endpoint(), state2);
        else if (route.page) {
          if (!page_nodes2) throw new Error("page_nodes not found. This should never happen");
          else if (page_methods.has(method)) response2 = await render_page(event2, event_state, route.page, options2, manifest, state2, page_nodes2, resolve_opts);
          else {
            const allowed_methods2 = new Set(allowed_page_methods);
            if ((await manifest._.nodes[route.page.leaf]())?.server?.actions) allowed_methods2.add("POST");
            if (method === "OPTIONS") response2 = new Response(null, {
              status: 204,
              headers: { allow: Array.from(allowed_methods2.values()).join(", ") }
            });
            else {
              const mod = [...allowed_methods2].reduce((acc, curr) => {
                acc[curr] = true;
                return acc;
              }, {});
              response2 = method_not_allowed(mod, method);
            }
          }
        } else throw new Error("Route is neither page nor endpoint. This should never happen");
        if (request.method === "GET" && route.page && route.endpoint) {
          const vary = response2.headers.get("vary")?.split(",")?.map((v) => v.trim().toLowerCase());
          if (!(vary?.includes("accept") || vary?.includes("*"))) {
            response2 = new Response(response2.body, {
              status: response2.status,
              statusText: response2.statusText,
              headers: new Headers(response2.headers)
            });
            response2.headers.append("Vary", "Accept");
          }
        }
        return response2;
      }
      if (state2.error && event2.isSubRequest) {
        const headers3 = new Headers(request.headers);
        headers3.set("x-sveltekit-error", "true");
        return await fetch(request, { headers: headers3 });
      }
      if (state2.error) return text2("Internal Server Error", { status: 500 });
      if (state2.depth === 0) return await respond_with_error({
        event: event2,
        event_state,
        options: options2,
        manifest,
        state: state2,
        status: 404,
        error: new SvelteKitError3(404, "Not Found", `Not found: ${event2.url.pathname}`),
        resolve_opts
      });
      if (state2.prerendering) return text2("not found", { status: 404 });
      const response = await fetch(request);
      return new Response(response.body, response);
    } catch (e) {
      return await handle_fatal_error(event2, event_state, options2, e);
    } finally {
      event2.cookies.set = () => {
        throw new Error("Cannot use `cookies.set(...)` after the response has been generated");
      };
      event2.setHeaders = () => {
        throw new Error("Cannot use `setHeaders(...)` after the response has been generated");
      };
    }
  }
}
function load_page_nodes(page2, manifest) {
  return Promise.all([...page2.layouts.map((n) => n == void 0 ? n : manifest._.nodes[n]()), manifest._.nodes[page2.leaf]()]);
}
function propagate_context(fn) {
  return async (req, ...rest) => {
    return fn(req, ...rest);
  };
}
function filter_env(env, allowed, disallowed) {
  return Object.fromEntries(Object.entries(env).filter(([k]) => k.startsWith(allowed) && (disallowed === "" || !k.startsWith(disallowed))));
}
var init_promise;
var current = null;
var Server = class {
  /** @type {import('types').SSROptions} */
  #options;
  /** @type {import('@sveltejs/kit').SSRManifest} */
  #manifest;
  /** @param {import('@sveltejs/kit').SSRManifest} manifest */
  constructor(manifest) {
    this.#options = options;
    this.#manifest = manifest;
    if (IN_WEBCONTAINER) {
      const respond2 = this.respond.bind(this);
      this.respond = async (...args) => {
        const { promise, resolve: resolve2 } = with_resolvers();
        const previous = current;
        current = promise;
        await previous;
        return respond2(...args).finally(resolve2);
      };
    }
    set_manifest(manifest);
  }
  /**
  * @param {import('@sveltejs/kit').ServerInitOptions} opts
  */
  async init({ env, read }) {
    const { env_public_prefix, env_private_prefix } = this.#options;
    set_private_env(filter_env(env, env_private_prefix, env_public_prefix));
    set_public_env(filter_env(env, env_public_prefix, env_private_prefix));
    if (read) {
      const wrapped_read = (file) => {
        const result = read(file);
        if (result instanceof ReadableStream) return result;
        else return new ReadableStream({ async start(controller) {
          try {
            const stream = await Promise.resolve(result);
            if (!stream) {
              controller.close();
              return;
            }
            const reader = stream.getReader();
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              controller.enqueue(value);
            }
            controller.close();
          } catch (error2) {
            controller.error(error2);
          }
        } });
      };
      set_read_implementation(wrapped_read);
    }
    await (init_promise ??= (async () => {
      try {
        const module = await get_hooks();
        this.#options.hooks = {
          handle: module.handle || (({ event, resolve: resolve2 }) => resolve2(event)),
          handleError: module.handleError || (({ status, error: error2, event }) => {
            const error_message = format_server_error(status, error2, event);
            console.error(error_message);
          }),
          handleFetch: module.handleFetch || (({ request, fetch: fetch2 }) => fetch2(request)),
          handleValidationError: module.handleValidationError || (({ issues }) => {
            console.error("Remote function schema validation failed:", issues);
            return { message: "Bad Request" };
          }),
          reroute: module.reroute || noop2,
          transport: module.transport || {}
        };
        module.transport && Object.fromEntries(Object.entries(module.transport).map(([k, v]) => [k, v.decode]));
        if (module.init) await module.init();
      } catch (e) {
        throw e;
      }
    })());
  }
  /**
  * @param {Request} request
  * @param {import('types').RequestOptions} options
  */
  async respond(request, options2) {
    return respond(request, this.#options, this.#manifest, {
      ...options2,
      error: false,
      depth: 0
    });
  }
};

// .netlify/serverless.js
import { createReadStream } from "node:fs";
import { Readable } from "node:stream";
import process from "node:process";
function createReadableStream(file) {
  return (
    /** @type {ReadableStream} */
    Readable.toWeb(createReadStream(file))
  );
}
function init2(manifest) {
  const server = new Server(manifest);
  let init_promise2 = server.init({
    env: (
      /** @type {Record<string, string>} */
      process.env
    ),
    read: (file) => createReadableStream(`.netlify/server/${file}`)
  });
  return async (request, context2) => {
    if (init_promise2 !== null) {
      await init_promise2;
      init_promise2 = null;
    }
    return server.respond(request, {
      platform: { context: context2 },
      getClientAddress() {
        return context2.ip;
      }
    });
  };
}

// .netlify/functions-internal/sveltekit-render.mjs
var sveltekit_render_default = init2((() => {
  function __memo(fn) {
    let value;
    return () => value ??= value = fn();
  }
  return {
    appDir: "_app",
    appPath: "_app",
    assets: /* @__PURE__ */ new Set(["abhishek-kumar-resume.pdf", "favicon.ico", "favicon.png", "images/casestudies/bill-reader-system.svg", "images/casestudies/visajobs-extension.webp", "images/casestudies/visajobs-product-1200.webp", "images/casestudies/visajobs-product-720.webp", "images/casestudies/visajobs-product.webp", "images/casestudies/wfp-evidence-map.svg", "images/headshot-480.webp", "images/headshot-800.webp", "images/headshot.webp", "images/social/bill-reader.png", "images/social/bill-reader.svg", "images/social/home.png", "images/social/home.svg", "images/social/platform-delivery.png", "images/social/platform-delivery.svg", "images/social/visajobs.png", "images/social/visajobs.svg", "robots.txt", "sitemap.xml"]),
    mimeTypes: { ".pdf": "application/pdf", ".png": "image/png", ".svg": "image/svg+xml", ".webp": "image/webp", ".txt": "text/plain", ".xml": "text/xml" },
    _: {
      client: { start: "_app/immutable/entry/start.9OuQfHOc.js", app: "_app/immutable/entry/app.lpn46-mS.js", imports: ["_app/immutable/entry/start.9OuQfHOc.js", "_app/immutable/chunks/DXtUsCh-.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/entry/app.lpn46-mS.js", "_app/immutable/chunks/BqlqCaOA.js", "_app/immutable/chunks/xihTtKlq.js"], stylesheets: [], fonts: [], uses_env_dynamic_public: false },
      nodes: [
        __memo(() => Promise.resolve().then(() => (init__(), __exports))),
        __memo(() => Promise.resolve().then(() => (init__2(), __exports2))),
        __memo(() => Promise.resolve().then(() => (init__3(), __exports3))),
        __memo(() => Promise.resolve().then(() => (init__4(), __exports4))),
        __memo(() => Promise.resolve().then(() => (init__5(), __exports5))),
        __memo(() => Promise.resolve().then(() => (init__6(), __exports6)))
      ],
      remotes: {},
      routes: [
        {
          id: "/",
          pattern: /^\/$/,
          params: [],
          page: { layouts: [0], errors: [1], leaf: 2 },
          endpoint: null
        },
        {
          id: "/work/bill-reader",
          pattern: /^\/work\/bill-reader\/?$/,
          params: [],
          page: { layouts: [0], errors: [1], leaf: 3 },
          endpoint: null
        },
        {
          id: "/work/platform-delivery",
          pattern: /^\/work\/platform-delivery\/?$/,
          params: [],
          page: { layouts: [0], errors: [1], leaf: 4 },
          endpoint: null
        },
        {
          id: "/work/visajobs",
          pattern: /^\/work\/visajobs\/?$/,
          params: [],
          page: { layouts: [0], errors: [1], leaf: 5 },
          endpoint: null
        }
      ],
      prerendered_routes: /* @__PURE__ */ new Set([]),
      matchers: async () => {
        return {};
      },
      server_assets: {}
    }
  };
})());
var config = {
  path: ["/*"],
  excludedPath: ["/.netlify/*"],
  preferStatic: true
};
export {
  config,
  sveltekit_render_default as default
};
